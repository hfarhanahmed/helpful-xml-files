package com.bwf.hiit.workout.abs.challenge.home.fitness.utils;

import com.bwf.hiit.workout.abs.challenge.home.fitness.dto.APINutrientsDTO;
import com.bwf.hiit.workout.abs.challenge.home.fitness.dto.APISearchDTO;
import com.bwf.hiit.workout.abs.challenge.home.fitness.dto.FoodGroupJsonDTO;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class USDAJsonParser {

    public List<APISearchDTO> searchAPIParser(String result) {
        JSONObject topLevel;
        try {
            topLevel = new JSONObject(result);
            JSONObject list = topLevel.getJSONObject("list");
            JSONArray main = list.getJSONArray("item");
            return new Gson().fromJson(main.toString(), new TypeToken<List<APISearchDTO>>() {
            }.getType());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }



    public List<APINutrientsDTO> nutrientsAPIParser(String result) {
        JSONObject topLevel;
        try {
            topLevel = new JSONObject(result);
            JSONObject list = topLevel.getJSONObject("report");
            JSONArray main = list.getJSONArray("foods");
            JSONArray nutrients = main.getJSONObject(0).getJSONArray("nutrients");
            return new Gson().fromJson(nutrients.toString(), new TypeToken<List<APINutrientsDTO>>() {
            }.getType());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }


    public List<FoodGroupJsonDTO> listFoodGroupJSONParser(String result) {
        JSONObject topLevel;
        try {
            topLevel = new JSONObject(result);
            JSONObject list = topLevel.getJSONObject("list");
            JSONArray main = list.getJSONArray("item");
            return new Gson().fromJson(main.toString(), new TypeToken<List<FoodGroupJsonDTO>>() {
            }.getType());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }


}
