package com.bwf.hiit.workout.abs.challenge.home.fitness.interfaces;


import com.bwf.hiit.workout.abs.challenge.home.fitness.models.EventDay;

public interface OnDayClickListener {
    void onDayClick(EventDay eventDay);
}
