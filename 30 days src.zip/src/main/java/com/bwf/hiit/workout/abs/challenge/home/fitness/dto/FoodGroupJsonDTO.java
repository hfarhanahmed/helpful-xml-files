package com.bwf.hiit.workout.abs.challenge.home.fitness.dto;

import com.google.gson.annotations.SerializedName;

public class FoodGroupJsonDTO {

    @SerializedName("offset")
    private int offset;

    @SerializedName("name")
    private String name;

    @SerializedName("id")
    private String id;

    public FoodGroupJsonDTO(int offset, String name, String id) {
        this.offset = offset;
        this.name = name;
        this.id = id;
    }

    public int getOffset() {
        return offset;
    }

    public void setOffset(int offset) {
        this.offset = offset;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
