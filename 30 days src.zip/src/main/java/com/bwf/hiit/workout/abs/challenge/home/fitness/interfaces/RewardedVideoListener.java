package com.bwf.hiit.workout.abs.challenge.home.fitness.interfaces;

public interface RewardedVideoListener {

    void onRewardedVideoLoaded();

    void onRewardedVideoStarted();

    void onRewardedVideoCompleted();

    void onGotReward();

    void onRewardedVideoClosed();

}
