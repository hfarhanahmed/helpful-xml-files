package com.bwf.hiit.workout.abs.challenge.home.fitness;

public class AppStateManager {

    public static final String ACTION_TYPE = "action_type";
    public static final String IS_ADS_DISABLED = "IS_ADS_DISABLED";
    public static final String IS_FIVE_MIN_PLANK_ACTIVE = "IS_FIVE_MIN_PLANK_ACTIVE";
    public static final String IS_TWO_MIN_ABS_ACTIVE = "IS_TWO_MIN_ABS_ACTIVE";
    public static final String TOOLS_DASHBOAD_BMI_VALUE = "TOOLS_DASHBOAD_BMI_VALUE";
    public static final String TOOLS_DASHBOAD_BODY_FAT_VALUE = "TOOLS_DASHBOAD_BODY_FAT_VALUE";
    public static final String TOOLS_DASHBOAD_CALORIES_REQ_VALUE = "TOOLS_DASHBOAD_CALORIES_REQ_VALUE";
    public static final String TOOLS_DASHBOAD_PROTEINS_REQ_VALUE = "TOOLS_DASHBOAD_PROTEINS_REQ_VALUE";
}
