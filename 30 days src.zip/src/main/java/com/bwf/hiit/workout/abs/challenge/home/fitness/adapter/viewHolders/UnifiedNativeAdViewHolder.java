package com.bwf.hiit.workout.abs.challenge.home.fitness.adapter.viewHolders;


import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.bwf.hiit.workout.abs.challenge.home.fitness.R;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;

public class UnifiedNativeAdViewHolder extends RecyclerView.ViewHolder {

    public UnifiedNativeAdView adView;

    public UnifiedNativeAdView getAdView() {
        return adView;
    }

    public UnifiedNativeAdViewHolder(View view) {
        super(view);
        adView = (UnifiedNativeAdView) view.findViewById(R.id.ad_unified_layout);

    }
}
