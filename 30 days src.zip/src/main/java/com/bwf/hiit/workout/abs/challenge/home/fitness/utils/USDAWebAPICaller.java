package com.bwf.hiit.workout.abs.challenge.home.fitness.utils;

import android.annotation.SuppressLint;
import android.os.AsyncTask;


import com.bwf.hiit.workout.abs.challenge.home.fitness.interfaces.APIResponseAsync;

import org.json.JSONException;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;


@SuppressLint("StaticFieldLeak")
public class USDAWebAPICaller extends AsyncTask<String, Void, String> {

    private APIResponseAsync responseCaller  =   null;
    private int id=0;

    public USDAWebAPICaller(int id, APIResponseAsync responseCallback) {
        responseCaller  =   responseCallback;
        this.id=id;
    }

    @Override
    protected String doInBackground(String... strings) {
        String result = "UNDEFINED";
        try {
            URL url = new URL(strings[0]);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

            InputStream stream = new BufferedInputStream(urlConnection.getInputStream());
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(stream));
            StringBuilder builder = new StringBuilder();

            String inputString;
            while ((inputString = bufferedReader.readLine()) != null) {
                builder.append(inputString);
            }
            result=builder.toString();

            urlConnection.disconnect();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    protected void onPostExecute(String result) {

        if (this.responseCaller != null)
            try {
                this.responseCaller.onApiResponse(id,result);
            } catch (JSONException e) {
                e.printStackTrace();
            }

    }
}