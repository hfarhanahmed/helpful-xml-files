package com.bwf.hiit.workout.abs.challenge.home.fitness.managers;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bwf.hiit.workout.abs.challenge.home.fitness.AppStateManager;
import com.bwf.hiit.workout.abs.challenge.home.fitness.Application;
import com.bwf.hiit.workout.abs.challenge.home.fitness.R;
import com.bwf.hiit.workout.abs.challenge.home.fitness.helpers.SharedPrefHelper;
import com.bwf.hiit.workout.abs.challenge.home.fitness.interfaces.RewardedVideoListener;
import com.bwf.hiit.workout.abs.challenge.home.fitness.utils.Utils;
import com.bwf.hiit.workout.abs.challenge.home.fitness.view.MainActivity;
//import com.facebook.ads.AbstractAdListener;
//import com.facebook.ads.Ad;
//import com.facebook.ads.AdError;

import com.google.ads.consent.ConsentInformation;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.MediaView;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.android.gms.ads.reward.RewardItem;
import com.google.android.gms.ads.reward.RewardedVideoAd;
import com.google.android.gms.ads.reward.RewardedVideoAdListener;

import java.security.PrivilegedAction;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class AdsManager {

    private static AdsManager manager;
    private final String TAG = AdsManager.class.getName();

    private Map<String, InterstitialAd> adMobAdsList;
//    private Map<String, com.facebook.ads.InterstitialAd> fbAdsList;
    private RewardedVideoAd rewardedVideoAd;

    private Context context;

    private  RewardedVideoListener customListener = null;

    private AdsManager() {
        if (Utils.isNetworkAvailable(Application.getContext()) && !SharedPrefHelper.readBoolean(Application.getContext(), AppStateManager.IS_ADS_DISABLED)) {

            context = Application.getContext();

            MobileAds.initialize(context,context.getString(R.string.app_id));

//            fbAdsList = new HashMap<>();
            adMobAdsList = new HashMap<>();

            //Adding All Admob Ads To Our Hashmap//
            InterstitialAd interstitialAd = new InterstitialAd(context);
            interstitialAd.setAdUnitId(context.getString(R.string.AM_Int_Main_Menu));
            adMobAdsList.put(context.getString(R.string.AM_Int_Main_Menu), interstitialAd);

            interstitialAd = new InterstitialAd(context);
            interstitialAd.setAdUnitId(context.getString(R.string.AM_Int_Workout_End));
            adMobAdsList.put(context.getString(R.string.AM_Int_Workout_End), interstitialAd);

            interstitialAd = new InterstitialAd(context);
            interstitialAd.setAdUnitId(context.getString(R.string.AM_Int_Calculator));
            adMobAdsList.put(context.getString(R.string.AM_Int_Calculator), interstitialAd);

            //Adding All Admob Ads To Our Hashmap//
            //initialise this ad fb ad instance and put it in our dictionary//
//            com.facebook.ads.InterstitialAd fbInterstitialAd = new com.facebook.ads.InterstitialAd(context, context.getString(R.string.FB_Int_Exercise_List));
//            fbAdsList.put(context.getString(R.string.FB_Int_Exercise_List), fbInterstitialAd);

            // load the ads and cache them for later use
            loadAllAdMobInterstitialAd();
//            loadAllFacebookInterstitialAds();

            Log.d(TAG, "Loading Rewarded Video Ad");

            loadRewardedVideo(Application.getContext(), new RewardedVideoListener() {
                @Override
                public void onRewardedVideoLoaded() {
                    Log.d(TAG, "Rewarded Video Ad Loaded");
                }

                @Override
                public void onRewardedVideoStarted() {
                }

                @Override
                public void onRewardedVideoCompleted() {
                    if(customListener != null)
                    {
                        Log.d(TAG, "Rewarded Video Ad Completed");
                        customListener.onRewardedVideoCompleted();
                    }
                }

                @Override
                public void onGotReward() {
                    if(customListener != null)
                    {
                        Log.d(TAG, "Rewarded Video Ad Rewarded");
                        customListener.onGotReward();
                    }
                }

                @Override
                public void onRewardedVideoClosed() {
                    customListener.onRewardedVideoClosed();
                    Log.d(TAG, "Rewarded Video Ad Rewarded Closed");
                }
            });
        }
    }

    public static AdsManager getInstance() {
        if (manager == null) {
            manager = new AdsManager();
        }
        return manager;
    }

    private AdRequest prepareAdRequest() {
        AdRequest adRequest;
        Context context = Application.getContext();
        if (SharedPrefHelper.readBoolean(context, context.getString(R.string.npa))) {
            Bundle bundle = new Bundle();
            bundle.putString(context.getString(R.string.npa), "1");
            Log.d(TAG, "consent status: npa");
            adRequest = new AdRequest.Builder().addNetworkExtrasBundle(AdMobAdapter.class, bundle).build();
        } else {
            Log.d(TAG, "consent status: pa");
//            ConsentInformation.getInstance(context).addTestDevice("9A0006CA1B2DA703211D6AB43BDE24A1");
            adRequest = new AdRequest.Builder().build();
        }
        return adRequest;
    }

    // **********  INTERSITITAL ADS ************ //

    private void loadAllAdMobInterstitialAd() {
        if (adMobAdsList != null && adMobAdsList.size() > 0) {
            for (InterstitialAd ad : adMobAdsList.values()) {
                if (Utils.isNetworkAvailable(Application.getContext()) && !SharedPrefHelper.readBoolean(Application.getContext(), AppStateManager.IS_ADS_DISABLED)) {

                    AdListener adListener = new AdListener() {
                        @Override
                        public void onAdClosed() {
                            super.onAdClosed();

                            Log.d(TAG, "AdMob InterstitialAd -> onAdClosed");
                            ad.loadAd(prepareAdRequest());
                        }

                        @Override
                        public void onAdLoaded() {
                            super.onAdLoaded();
                            Log.d(TAG, "AdMob InterstitialAd -> onAdLoaded");
                        }

                        @Override
                        public void onAdFailedToLoad(int i) {
                            super.onAdFailedToLoad(i);
                            Log.d(TAG, "AdMob InterstitialAd -> onAdFailedToLoad");
                        }
                    };

                    if (ad != null) {
                        ad.setAdListener(adListener);
                        ad.loadAd(prepareAdRequest());
                    }
                }
            }
        }
    }

//    private void loadAllFacebookInterstitialAds() {
//        AbstractAdListener AdListener = new AbstractAdListener() {
//            @Override
//            public void onError(Ad ad, AdError adError) {
//                // Ad error callback
//                Log.e(TAG, "Facebook ad failed to load: " + ad.getPlacementId() + " " + adError.getErrorMessage());
//            }
//
//            @Override
//            public void onAdLoaded(Ad ad) {
//                super.onAdLoaded(ad);
//                Log.d(TAG, "Facebook InterstitialAd -> onAdLoaded " + ad.getPlacementId());
//            }
//
//            @Override
//            public void onInterstitialDisplayed(Ad ad) {
//                super.onInterstitialDisplayed(ad);
//                Log.d(TAG, "Facebook InterstitialAd -> Ad Displayed " + ad.getPlacementId());
//            }
//
//            @Override
//            public void onInterstitialDismissed(Ad ad) {
//                super.onInterstitialDismissed(ad);
//
//                if (Utils.isNetworkAvailable(Application.getContext()) && !SharedPrefHelper.readBoolean(Application.getContext(), AppStateManager.IS_ADS_DISABLED)) {
//                    if (fbAdsList.containsKey((ad.getPlacementId()))) {
//                        com.facebook.ads.InterstitialAd temp = fbAdsList.get(ad.getPlacementId());
//                        Log.d(TAG, "Facebook InterstitialAd Shown -> Going to Load " + ad.getPlacementId());
//                        temp.loadAd();
//                    }
//                }
//            }
//        };
//
//        if (fbAdsList != null && fbAdsList.size() > 0) {
//            for (com.facebook.ads.InterstitialAd ad : fbAdsList.values()) {
//                if (ad != null) {
//                    if (Utils.isNetworkAvailable(Application.getContext()) && !SharedPrefHelper.readBoolean(Application.getContext(), AppStateManager.IS_ADS_DISABLED)) {
//                        Log.d(TAG, "Loading Facebook Ads " + ad.getPlacementId());
//                        ad.setAdListener(AdListener);
//                        ad.loadAd();
//                    }
//                }
//            }
//        }
//    }

    public void showInterstitialAd(String adId) {
        if (adMobAdsList != null) {
            if (adMobAdsList.containsKey(adId)) {
                if (Utils.isNetworkAvailable(Application.getContext()) && !SharedPrefHelper.readBoolean(Application.getContext(), AppStateManager.IS_ADS_DISABLED)) {
                    InterstitialAd myAdMobAd = adMobAdsList.get(adId);
                    if (myAdMobAd != null) {
                        if (myAdMobAd.isLoaded()) {
                            myAdMobAd.show();
                        } else {
                            myAdMobAd.loadAd(prepareAdRequest());
                        }
                    }
                }
            }
        }
    }

//    public void showFacebookInterstitial(String adId, boolean withBackup) {
//        if (fbAdsList != null) {
//            if (fbAdsList.containsKey((adId))) {
//                com.facebook.ads.InterstitialAd myFbAd = fbAdsList.get(adId);
//                if (myFbAd != null) {
//                    if (Utils.isNetworkAvailable(Application.getContext()) && !SharedPrefHelper.readBoolean(Application.getContext(), AppStateManager.IS_ADS_DISABLED)) {
//                        if (myFbAd.isAdLoaded()) {
//                            Log.d(TAG, "Ad is Loadded , showing " + myFbAd.getPlacementId());
//                            myFbAd.show();
//                        } else if (withBackup) {
//                            //now show admob here//
//                            //the question is which ad mob to show here//
//                            for (InterstitialAd ad : adMobAdsList.values()) {
//                                //show the first one which has a loaded ad here//
//                                if (ad.isLoaded()) {
//                                    Log.d(TAG, "Ad is Loadded , showing back Up" + myFbAd.getPlacementId());
//                                    ad.show();
//                                    break;
//                                }
//                            }
//                            myFbAd.loadAd();
//                        } else {
//                            myFbAd.loadAd();
//                        }
//                    }
//                }
//            }
//        }
//    }

    // ********* BANNER ADS ***********//

    public void showBanner(final AdView banner) {
        if (Utils.isNetworkAvailable(Application.getContext()) && !SharedPrefHelper.readBoolean(Application.getContext(), AppStateManager.IS_ADS_DISABLED)) {
            if (banner != null) {
                banner.loadAd(prepareAdRequest());
                banner.setAdListener(new AdListener() {

                    @Override
                    public void onAdFailedToLoad(int i) {
                        super.onAdFailedToLoad(i);
                        Log.d(TAG, "AdMob BannerAd -> onAdFailedToLoad");
                    }

                    @Override
                    public void onAdLoaded() {
                        super.onAdLoaded();
                        Log.d(TAG, "AdMob BannerAd -> onAdLoaded");
                        if (banner.getVisibility() == View.GONE) {
                            banner.setVisibility(View.VISIBLE);
                        }
                    }
                });
            }
        }
    }


    //************ REWARDED VIDEO ADS *************//

    private void loadRewardedVideo(Context context, RewardedVideoListener listener) {
        if (Utils.isNetworkAvailable(context)) {

            rewardedVideoAd = MobileAds.getRewardedVideoAdInstance(context);

            rewardedVideoAd.setRewardedVideoAdListener(new RewardedVideoAdListener() {

                @Override
                public void onRewardedVideoAdLoaded() {
                    Log.d(TAG, "AdMob RewardedVideoAd -> onRewardedVideoAdLoaded");
                    if (listener != null) {
                        listener.onRewardedVideoLoaded();
                    }
                }

                @Override
                public void onRewardedVideoAdOpened() {
                }

                @Override
                public void onRewardedVideoStarted() {
                    Log.d(TAG, "AdMob RewardedVideoAd -> onRewardedVideoStarted");
                    if (listener != null) {
                        listener.onRewardedVideoStarted();
                    }
                }

                @Override
                public void onRewardedVideoAdClosed() {
                    Log.d(TAG, "AdMob RewardedVideoAd -> onRewardedVideoAdClosed");

                    if(customListener != null)
                    {
                        customListener.onRewardedVideoClosed();
                    }

                    loadRewardedVideo(context, listener);
                }

                @Override
                public void onRewarded(RewardItem rewardItem) {
                    if(listener != null)
                    {
                        listener.onGotReward();
                    }
                }

                @Override
                public void onRewardedVideoAdLeftApplication() {
                }

                @Override
                public void onRewardedVideoAdFailedToLoad(int i) {
                    Log.d(TAG, "AdMob RewardedVideoAd -> onRewardedVideoAdFailedToLoad, Error Code : " + i);
                }

                @Override
                public void onRewardedVideoCompleted() {
                    Log.d(TAG, "AdMob RewardedVideoAd -> onRewardedVideoCompleted");

                    if(listener != null)
                    {
                        listener.onRewardedVideoCompleted();
                    }
                }
            });

            //ca-app-pub-3940256099942544/5224354917 test id//
            //now load the ad//
            rewardedVideoAd.loadAd(context.getString(R.string.rewarded_ad_unit), prepareAdRequest());
//            rewardedVideoAd.loadAd("ca-app-pub-3940256099942544/5224354917", prepareAdRequest());//testing reward video
        }
    }

    public boolean isRewardedVideoAvailable()
    {
        if(rewardedVideoAd != null)
        {
            return  rewardedVideoAd.isLoaded();
        }

        return  false;
    }

    public void showRewardedVideo(RewardedVideoListener rewardedVideoListener) {

        customListener = null;

        Log.d(TAG, "Show Rewarded Video with Availability "+ rewardedVideoAd.isLoaded());

        if (rewardedVideoAd != null && rewardedVideoAd.isLoaded()) {
            customListener = rewardedVideoListener;
            rewardedVideoAd.show();
        }
    }

    // ********** NATIVE ADS *********//

    public void fetchAd(String adId,UnifiedNativeAd.OnUnifiedNativeAdLoadedListener listener) {

        if (context==null)
            context=Application.getContext();

        AdLoader.Builder builder = new AdLoader.Builder(context,adId);

        builder.forUnifiedNativeAd(listener);

        VideoOptions videoOptions = new VideoOptions.Builder()
                .setStartMuted(false)
                .build();

        NativeAdOptions adOptions = new NativeAdOptions.Builder()
                .setVideoOptions(videoOptions)
                .build();

        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(int errorCode) {
                Log.d(TAG, "onAdFailedToLoad: "+ errorCode);
            }
        }).build();

        adLoader.loadAd(new AdRequest.Builder().build());
    }

    public void populateUnifiedNativeAdView(UnifiedNativeAd nativeAd, UnifiedNativeAdView adView) {
        // Set the media view. Media content will be automatically populated in the media view once
        // adView.setNativeAd() is called.
        MediaView mediaView = adView.findViewById(R.id.ad_media);
        adView.setMediaView(mediaView);

        // Set other ad assets.
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_app_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));

        // The headline is guaranteed to be in every UnifiedNativeAd.
        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());

        // These assets aren't guaranteed to be in every UnifiedNativeAd, so it's important to
        // check before trying to display them.
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.GONE);
        } else {
            adView.getBodyView().setVisibility(View.GONE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.GONE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }

        if (nativeAd.getPrice() == null) {
            adView.getPriceView().setVisibility(View.GONE);
        } else {
            adView.getPriceView().setVisibility(View.VISIBLE);
            ((TextView) adView.getPriceView()).setText(nativeAd.getPrice());
        }

        if (nativeAd.getStore() == null) {
            adView.getStoreView().setVisibility(View.GONE);
        } else {
            adView.getStoreView().setVisibility(View.VISIBLE);
            ((TextView) adView.getStoreView()).setText(nativeAd.getStore());
        }

        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.GONE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        if (nativeAd.getAdvertiser() == null) {
            adView.getAdvertiserView().setVisibility(View.GONE);
        } else {
            ((TextView) adView.getAdvertiserView()).setText(nativeAd.getAdvertiser());
            adView.getAdvertiserView().setVisibility(View.VISIBLE);
        }

        adView.setNativeAd(nativeAd);

        VideoController vc = nativeAd.getVideoController();

        // Updates the UI to say whether or not this ad has a video asset.
        if (vc.hasVideoContent()) {
            //ad has video content
            vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                @Override
                public void onVideoEnd() {
                    super.onVideoEnd();
                }
            });
        }
        else {
        }
    }
}