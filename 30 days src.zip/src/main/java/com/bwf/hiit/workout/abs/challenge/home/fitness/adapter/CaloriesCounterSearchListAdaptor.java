package com.bwf.hiit.workout.abs.challenge.home.fitness.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.bwf.hiit.workout.abs.challenge.home.fitness.databinding.ItemWordBinding;
import com.bwf.hiit.workout.abs.challenge.home.fitness.dto.APISearchDTO;
import com.github.wrdlbrnft.sortedlistadapter.SortedListAdapter;

import java.util.Comparator;
import java.util.List;

public class CaloriesCounterSearchListAdaptor extends SortedListAdapter<APISearchDTO> {

    public interface Listener {
        void onSearchItemClicked(APISearchDTO model);
    }

    private final Listener mListener;

    public CaloriesCounterSearchListAdaptor(@NonNull Context context, @NonNull Comparator<APISearchDTO> comparator, Listener   listener) {
        super(context, APISearchDTO.class, comparator);
        mListener = listener;
    }

    @NonNull
    @Override
    protected ViewHolder<? extends APISearchDTO> onCreateViewHolder(@NonNull LayoutInflater inflater, @NonNull ViewGroup parent, int viewType) {
        final ItemWordBinding binding = ItemWordBinding.inflate(inflater, parent, false);
        return new SearchViewHolder(binding, mListener);
    }

    public class SearchViewHolder  extends SortedListAdapter.ViewHolder<APISearchDTO> {

        private final ItemWordBinding mBinding;

        SearchViewHolder(ItemWordBinding binding, CaloriesCounterSearchListAdaptor.Listener listener) {
            super(binding.getRoot());
            binding.setListener(listener);

            mBinding = binding;
        }

        @Override
        protected void performBind(@NonNull APISearchDTO item) {
            mBinding.setModel(item);
        }
    }

    public void updateList(List<APISearchDTO>    list){

    }
}
