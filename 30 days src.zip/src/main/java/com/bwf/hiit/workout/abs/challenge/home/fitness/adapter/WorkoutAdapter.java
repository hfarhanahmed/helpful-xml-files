package com.bwf.hiit.workout.abs.challenge.home.fitness.adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.util.Util;
import com.bwf.hiit.workout.abs.challenge.home.fitness.AppStateManager;
import com.bwf.hiit.workout.abs.challenge.home.fitness.R;
import com.bwf.hiit.workout.abs.challenge.home.fitness.adapter.viewHolders.UnifiedNativeAdViewHolder;
import com.bwf.hiit.workout.abs.challenge.home.fitness.helpers.SharedPrefHelper;
import com.bwf.hiit.workout.abs.challenge.home.fitness.inapp.MyBilling;
import com.bwf.hiit.workout.abs.challenge.home.fitness.interfaces.RewardedVideoListener;
import com.bwf.hiit.workout.abs.challenge.home.fitness.managers.AdsManager;
import com.bwf.hiit.workout.abs.challenge.home.fitness.managers.AnalyticsManager;
import com.bwf.hiit.workout.abs.challenge.home.fitness.utils.Utils;
import com.bwf.hiit.workout.abs.challenge.home.fitness.view.DailyExerciseInfo;
import com.bwf.hiit.workout.abs.challenge.home.fitness.view.HomeActivity;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;

import java.util.Objects;


public class WorkoutAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private String[] dayName;
    private String[] dayTime;
    private int currentPlan;
    private Activity    activity;
    private String  adId="";
    // A menu item view type.
    private static final int MENU_ITEM_VIEW_TYPE = 0;

    // The unified native ad view type.
    private static final int UNIFIED_NATIVE_AD_VIEW_TYPE = 1;

    public WorkoutAdapter(Context context,Activity  activity, int plan) {
        this.currentPlan = plan;
        this.dayName = context.getResources().getStringArray(R.array.exercise_list);
        this.dayTime = context.getResources().getStringArray(R.array.exercise_time_list);
        this.adId = context.getResources().getString(R.string.AM_Nat_Workouts);
        this.activity=activity;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        switch (viewType){
            case UNIFIED_NATIVE_AD_VIEW_TYPE:
                return new UnifiedNativeAdViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.ad_unified, parent, false));
            case    MENU_ITEM_VIEW_TYPE:
                default:
                    return new myHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_workout, parent, false));
        }
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, final int position) {
        int     viewType    =   getItemViewType(position);
        switch (viewType){
            case UNIFIED_NATIVE_AD_VIEW_TYPE:
                    Utils.setBigNativeAd(((UnifiedNativeAdViewHolder) holder).adView,adId);
                break;
            case    MENU_ITEM_VIEW_TYPE:
            default:
                myHolder    myHolder=(WorkoutAdapter.myHolder) holder;
                if (position == 0) {
                    myHolder.img.setImageResource(R.drawable.workout_screen_pre_workout_warm_up);
                    myHolder.rewardIcon.setVisibility(View.GONE);
                } else if (position == 1) {
                    myHolder.img.setImageResource(R.drawable.workout_screen_post_workout_cool_down);
                    myHolder.rewardIcon.setVisibility(View.GONE);
                } else if (position == 2    &&  (!Utils.isNetworkAvailable(activity)   ||  SharedPrefHelper.readBoolean(activity,AppStateManager.IS_ADS_DISABLED))) {
                    myHolder.img.setImageResource(R.drawable.workout_screen_5_min_plank_challenge_image);
                    myHolder.rewardIcon.setVisibility(View.VISIBLE);
                } else if (position == 3    &&  (!Utils.isNetworkAvailable(activity)   ||  SharedPrefHelper.readBoolean(activity,AppStateManager.IS_ADS_DISABLED))) {
                    myHolder.img.setImageResource(R.drawable.workout_screen_two_minute_abs_image);
                    myHolder.rewardIcon.setVisibility(View.VISIBLE);
                } else if (position == 3) {
                    myHolder.img.setImageResource(R.drawable.workout_screen_5_min_plank_challenge_image);
                    myHolder.rewardIcon.setVisibility(View.VISIBLE);
                } else if (position == 4) {
                    myHolder.img.setImageResource(R.drawable.workout_screen_two_minute_abs_image);
                    myHolder.rewardIcon.setVisibility(View.VISIBLE);
                }


                final int index;
                if (Utils.isNetworkAvailable(activity)   &&  !SharedPrefHelper.readBoolean(activity,AppStateManager.IS_ADS_DISABLED))
                    index=position>2?position-1:position;
                else
                    index   =   position;

                myHolder.tvDayName.setText(dayName[index]);
                myHolder.txtTime.setText(dayTime[index]);
                myHolder.itemView.setOnClickListener(view -> buttonPressed(view.getContext(),index));
                break;
        }
    }

    @Override
    public int getItemCount() {
        if (dayName == null)
            return 0;
        else    if (Utils.isNetworkAvailable(activity)   &&  !SharedPrefHelper.readBoolean(activity, AppStateManager.IS_ADS_DISABLED)){
            return dayName.length+1;
        }else{
            return dayName.length;
        }
    }

    class myHolder extends RecyclerView.ViewHolder {

        TextView tvDayName;
        TextView txtTime;
        ImageView img;
        ImageView   rewardIcon;

        myHolder(View itemView) {
            super(itemView);
            tvDayName = itemView.findViewById(R.id.tv_exerciseName);
            txtTime = itemView.findViewById(R.id.tv_min);
            img = itemView.findViewById(R.id.img);
            rewardIcon  =   itemView.findViewById(R.id.reward_video_icon);
        }
    }

    @Override
    public int getItemViewType(int position) {
        if (position==2 &&  Utils.isNetworkAvailable(activity)   &&  !SharedPrefHelper.readBoolean(activity, AppStateManager.IS_ADS_DISABLED)) {
            return UNIFIED_NATIVE_AD_VIEW_TYPE;
        }else{
            return MENU_ITEM_VIEW_TYPE;
        }
    }

    private void showVideoAd(Context context, int    position)
    {
        final boolean[] gotReward = {false};
        RewardedVideoListener adListener = new RewardedVideoListener() {
            @Override
            public void onRewardedVideoLoaded() {

            }

            @Override
            public void onRewardedVideoStarted() {

            }

            @Override
            public void onRewardedVideoCompleted() {

            }

            @Override
            public void onGotReward() {
                gotReward[0] =true;
                Log.d("Got Reward : ", gotReward[0]+"");
            }

            @Override
            public void onRewardedVideoClosed() {
                if (gotReward[0]){
                    updateAppStateRewardVideos(context,position);
                    goToNewActivity(context,position,false);
                }

            }
        };


        AdsManager.getInstance().showRewardedVideo(adListener);

//        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
//        alertDialogBuilder.setTitle(context.getString(R.string.app_name));
//        alertDialogBuilder
//                .setMessage("Do you want to open it see video?")
//                .setCancelable(false)
//                .setPositiveButton("YES", (dialog, id) -> {
//                    dialog.cancel();
//                    AdsManager.getInstance().showRewardedVideo(adListener);
//                }).setNegativeButton("NO", (dialog, id) -> dialog.cancel());
//        AlertDialog alertDialog = alertDialogBuilder.create();
//        alertDialog.show();

    }



    private void updateAppStateRewardVideos(Context context,int position) {
        switch(position){
            case 2:
                SharedPrefHelper.writeBoolean(context, AppStateManager.IS_FIVE_MIN_PLANK_ACTIVE,true);
                break;
            case 3:
                SharedPrefHelper.writeBoolean(context, AppStateManager.IS_TWO_MIN_ABS_ACTIVE,true);
                break;
        }
    }

    private void buttonPressed(Context context,int  position) {
        switch (position){
            case 0:
            case 1:
                goToNewActivity(context,position,true);
                break;
            case 2:
                if (SharedPrefHelper.readBoolean(context, AppStateManager.IS_FIVE_MIN_PLANK_ACTIVE) ||  SharedPrefHelper.readBoolean(context,AppStateManager.IS_ADS_DISABLED))
                    goToNewActivity(context,position,true);
                else
                    showRewardedVideoPopup(context,position);
                break;
            case 3:
                if (SharedPrefHelper.readBoolean(context,AppStateManager.IS_TWO_MIN_ABS_ACTIVE) ||  SharedPrefHelper.readBoolean(context,AppStateManager.IS_ADS_DISABLED))
                    goToNewActivity(context,position,true);
                else
                    showRewardedVideoPopup(context, position);
                break;
        }


    }

    private void showRewardedVideoPopup(Context context, int position){
        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.dialog_rewarded_video);
        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawableResource(android.R.color.transparent);
        ImageView   videoIcon   =   (ImageView) dialog.findViewById(R.id.rewarded_video_gif);
        Glide.with(context).load(R.drawable.downright_cautious_anglerfish_size_restricted).into(videoIcon);
        dialog.show();
        Button btnRewaredVideo = dialog.findViewById(R.id.rewarded_video_btn);
        Button btnRemoveAds = dialog.findViewById(R.id.remove_ads_btn);
        btnRewaredVideo.setOnClickListener(view -> {
            checkVideoAvailability(context,position);
            dialog.dismiss();
        });

        btnRemoveAds.setOnClickListener(view -> {
            dialog.dismiss();
            ((HomeActivity)activity).purchaseRemoveAds();
        });
        Log.d("Reward Video","available");
    }

    private void checkVideoAvailability(Context context, int position) {
        if (Utils.isNetworkAvailable(context)){
            if(AdsManager.getInstance().isRewardedVideoAvailable())
            {
                showVideoAd(context,position);
            }
            else
            {
//            goToNewActivity(context,position,true);
//            updateAppStateRewardVideos(context, position);
//            AdsManager.getInstance().showInterstitialAd(context.getString(R.string.AM_Int_Main_Menu));
                Log.d("Reward Video"," not available");
//                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
//                    alertDialogBuilder.setTitle(context.getString(R.string.app_name));
//
//                    alertDialogBuilder
//                            .setMessage("Sorry, No Rewarded Video Available.").setTitle("Check Network")
//                            .setCancelable(false)
//                            .setPositiveButton("Ok", (dialog, id) -> {
//                                dialog.cancel();
//                            });
//
//                    AlertDialog alertDialog = alertDialogBuilder.create();
//                    alertDialog.show();
                final Dialog dialog = new Dialog(context);
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog.setCancelable(true);
                dialog.setContentView(R.layout.dialog_rewarded_video_not_available);
                Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawableResource(android.R.color.transparent);
                ImageView   videoIcon   =   (ImageView) dialog.findViewById(R.id.rewarded_video_gif);
                Glide.with(context).load(R.drawable.downright_cautious_anglerfish_size_restricted).into(videoIcon);
                dialog.show();
                Button tryAgain = dialog.findViewById(R.id.try_again_btn);
                Button cancel = dialog.findViewById(R.id.cancel_btn);
                tryAgain.setOnClickListener(view -> {
                    dialog.dismiss();
                    showRewardedVideoPopup(context,position);
                });
                cancel.setOnClickListener(view -> {
                    dialog.dismiss();
                });
            }
        }else {
            Utils.showConnectionDialog(context);
        }
    }

    private void goToNewActivity(Context context, int position, boolean showAd) {
            Intent i = new Intent(context, DailyExerciseInfo.class);
            i.putExtra(context.getString(R.string.day_selected), position + 1);
            i.putExtra(context.getString(R.string.plan), currentPlan);
            i.putExtra("showAd", showAd);
            context.startActivity(i);
            String[] workoutTitle = {"PRE_WORKOUT_WAR_UP", "POST_WORKOUT_WAR_UP", "FIVE_MIN_PLANK_CHALLENGE", "TWO_MIN_ABS"};
            AnalyticsManager.getInstance().sendAnalytics(workoutTitle[position]+ "_Selected", workoutTitle[position] + "_Selected");
    }

}
