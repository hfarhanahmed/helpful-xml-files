package com.bwf.hiit.workout.abs.challenge.home.fitness.interfaces;

import org.json.JSONException;

public interface APIResponseAsync {
    void onApiResponse(int id, String response) throws JSONException;
}
