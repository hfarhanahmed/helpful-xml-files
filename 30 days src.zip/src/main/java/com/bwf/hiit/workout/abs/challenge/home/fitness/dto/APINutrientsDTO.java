package com.bwf.hiit.workout.abs.challenge.home.fitness.dto;

import com.google.gson.annotations.SerializedName;

public class APINutrientsDTO {

    @SerializedName("nutrient_id")
    private String  nutrientId;

    @SerializedName("unit")
    private String unit;

    @SerializedName("value")
    private String value;

    public APINutrientsDTO(String nutrientId, String unit, String value) {
        this.nutrientId = nutrientId;
        this.unit = unit;
        this.value = value;
    }

    public String getNutrientId() {
        return nutrientId;
    }

    public void setNutrientId(String nutrientId) {
        this.nutrientId = nutrientId;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
