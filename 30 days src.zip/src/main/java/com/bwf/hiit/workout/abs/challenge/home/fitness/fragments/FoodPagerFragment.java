package com.bwf.hiit.workout.abs.challenge.home.fitness.fragments;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioGroup;

import com.bwf.hiit.workout.abs.challenge.home.fitness.R;
import com.bwf.hiit.workout.abs.challenge.home.fitness.managers.AdsManager;
import com.bwf.hiit.workout.abs.challenge.home.fitness.models.Url;

import java.util.ArrayList;
import java.util.List;

public class FoodPagerFragment extends Fragment {

    RadioGroup btnGroup;
    Fragment    foodFragment    =   new FoodFragment();
    Fragment    calorieCalculatorFragment    =   new CalorieCounterFragment();
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ArrayList<Fragment> fragments   =   new ArrayList<>();
        // Inflate the layout for this fragment
//        return inflater.inflate(R.layout.fragment_food_pager, container, false);
        View result=inflater.inflate(R.layout.fragment_food_pager, container, false);
        selectSimpleFragment(foodFragment);
        btnGroup = result.findViewById(R.id.bottom_navigation);
        btnGroup.setOnCheckedChangeListener((radioGroup, i) -> {
            if (i == R.id.food) {
                selectSimpleFragment(foodFragment);
            } else if (i == R.id.calorie_calculator) {
                selectSimpleFragment(calorieCalculatorFragment);
            }
        });
        return result;
    }

    private void selectSimpleFragment(Fragment fragment) {
        FragmentTransaction ft;
        ft = getChildFragmentManager().beginTransaction();
        ft.replace(R.id.food_pager_main, fragment).commitAllowingStateLoss();
    }

    private FoodPagerAdapter buildAdapter(ArrayList<Fragment> fragments) {
        return(new FoodPagerAdapter(getActivity().getSupportFragmentManager(), fragments));
    }

    public class FoodPagerAdapter extends FragmentStatePagerAdapter {
        ArrayList<Fragment> list;
        FoodPagerAdapter(FragmentManager fm,    ArrayList<Fragment> fragments) {
            super(fm);
            list=fragments;
        }

        @Override
        public Fragment getItem(int position) {
            return list.get(position);
        }

        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            switch (position){
                case 0:
                    return "Food";
                case    1:
                    return "Calories Counter";
                    default:
                        return "";

            }
        }
    }
}
