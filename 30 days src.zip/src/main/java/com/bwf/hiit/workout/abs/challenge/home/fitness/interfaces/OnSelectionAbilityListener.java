package com.bwf.hiit.workout.abs.challenge.home.fitness.interfaces;


public interface OnSelectionAbilityListener {
    void onChange(boolean enabled);
}
