package com.bwf.hiit.workout.abs.challenge.home.fitness.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bwf.hiit.workout.abs.challenge.home.fitness.AppStateManager;
import com.bwf.hiit.workout.abs.challenge.home.fitness.R;
import com.bwf.hiit.workout.abs.challenge.home.fitness.adapter.viewHolders.UnifiedNativeAdViewHolder;
import com.bwf.hiit.workout.abs.challenge.home.fitness.helpers.SharedPrefHelper;
import com.bwf.hiit.workout.abs.challenge.home.fitness.models.Content;
import com.bwf.hiit.workout.abs.challenge.home.fitness.utils.Utils;

import java.util.List;

public class ContentAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private Context context;
    private List<Content> mList;

    // A menu item view type.
    private static final int MENU_ITEM_VIEW_TYPE = 0;

    // The unified native ad view type.
    private static final int UNIFIED_NATIVE_AD_VIEW_TYPE = 1;

    public ContentAdapter(Context context, List<Content> mList) {
        this.mList = mList;
        this.context = context;
    }

    @Override
    public int getItemViewType(int position) {
        if (Utils.isNetworkAvailable(context)   &&  !SharedPrefHelper.readBoolean(context, AppStateManager.IS_ADS_DISABLED)   &&  (position+1)%4==0) {
            return UNIFIED_NATIVE_AD_VIEW_TYPE;
        }else{
            return MENU_ITEM_VIEW_TYPE;
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        switch (viewType){
            case UNIFIED_NATIVE_AD_VIEW_TYPE:
                return new UnifiedNativeAdViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.ad_unified_food_list, parent, false));
            case    MENU_ITEM_VIEW_TYPE:
            default:
                return new myHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_food_content, parent, false));
        }
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder myHolder, final int position) {
        int     viewType    =   getItemViewType(position);
        switch (viewType) {
            case UNIFIED_NATIVE_AD_VIEW_TYPE:
                Utils.setBigNativeAd(((UnifiedNativeAdViewHolder) myHolder).adView,context.getResources().getString(R.string.AM_Nat_Food));
                break;
            case MENU_ITEM_VIEW_TYPE:
            default:
                myHolder holder = (myHolder) myHolder;

                final int index;
                if (Utils.isNetworkAvailable(context)   &&  !SharedPrefHelper.readBoolean(context,AppStateManager.IS_ADS_DISABLED))
                    index=position-(position+1)/4;
                else
                    index   =   position;

                holder.tvTitle.setText(mList.get(index).getText());

                if (SharedPrefHelper.readBoolean(context, context.getString(R.string.is_load))) {
                    String temp = context.getCacheDir().getAbsolutePath() + "/" + mList.get(index).getImage() + ".jpg";
                    Glide.with(context).load(temp).into(holder.imgMain);
                } else {
                    Glide.with(context).load(mList.get(index).getUrl()).into(holder.imgMain);
                }
        }
    }

    @Override
    public int getItemCount() {
        if (mList != null)
            if (Utils.isNetworkAvailable(context)   &&  !SharedPrefHelper.readBoolean(context, AppStateManager.IS_ADS_DISABLED)){
                return mList.size()+(mList.size()+1)/4;
            }else{
                return mList.size();
            }
        else
            return 0;
    }

    class myHolder extends RecyclerView.ViewHolder {

        TextView tvTitle;
        ImageView imgMain;

        myHolder(View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tileId);
            imgMain = itemView.findViewById(R.id.img_main);
        }
    }

}
