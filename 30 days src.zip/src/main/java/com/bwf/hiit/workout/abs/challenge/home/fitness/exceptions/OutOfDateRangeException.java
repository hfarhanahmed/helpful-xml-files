package com.bwf.hiit.workout.abs.challenge.home.fitness.exceptions;

public class OutOfDateRangeException extends Exception {
    public OutOfDateRangeException(String message) {
        super(message);
    }
}
