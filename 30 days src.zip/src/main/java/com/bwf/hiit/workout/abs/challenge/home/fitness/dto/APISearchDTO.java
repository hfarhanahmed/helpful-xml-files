package com.bwf.hiit.workout.abs.challenge.home.fitness.dto;

import android.support.annotation.NonNull;

import com.github.wrdlbrnft.sortedlistadapter.SortedListAdapter;
import com.google.gson.annotations.SerializedName;

public class APISearchDTO implements SortedListAdapter.ViewModel {

    @SerializedName("offset")
    private int offset;

    @SerializedName("name")
    private String name;

    @SerializedName("ndbno")
    private String ndbno;

    public APISearchDTO(int offset, String name, String ndbno) {
        this.offset =   offset;
        this.name = name;
        this.ndbno = ndbno;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNdbno() {
        return ndbno;
    }

    public void setNdbno(String ndbno) {
        this.ndbno = ndbno;
    }

    public int getOffset() {
        return offset;
    }

    public void setOffset(int offset) {
        this.offset = offset;
    }

    @Override
    public <T> boolean isSameModelAs(@NonNull T item) {
        if (item instanceof APISearchDTO) {
            final APISearchDTO wordModel = (APISearchDTO) item;
            return wordModel.ndbno == ndbno;
        }
        return false;
    }

    @Override
    public <T> boolean isContentTheSameAs(@NonNull T item) {
        if (item instanceof APISearchDTO) {
            final APISearchDTO other = (APISearchDTO) item;
            if (offset != other.offset) {
                return false;
            }
            return name != null ? name.equals(other.name) : other.name == null;
        }
        return false;
    }
}
