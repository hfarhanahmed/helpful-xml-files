package com.bwf.hiit.workout.abs.challenge.home.fitness.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bwf.hiit.workout.abs.challenge.home.fitness.AppStateManager;
import com.bwf.hiit.workout.abs.challenge.home.fitness.R;
import com.bwf.hiit.workout.abs.challenge.home.fitness.adapter.viewHolders.UnifiedNativeAdViewHolder;
import com.bwf.hiit.workout.abs.challenge.home.fitness.helpers.SharedPrefHelper;
import com.bwf.hiit.workout.abs.challenge.home.fitness.managers.AnalyticsManager;
import com.bwf.hiit.workout.abs.challenge.home.fitness.utils.Utils;
import com.bwf.hiit.workout.abs.challenge.home.fitness.view.FoodDetailActivity;

public class FoodAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private String[] foodName;

    // A menu item view type.
    private static final int MENU_ITEM_VIEW_TYPE = 0;

    // The unified native ad view type.
    private static final int UNIFIED_NATIVE_AD_VIEW_TYPE = 1;

    private String adId="";
    private Context context;

    public FoodAdapter(Context context) {
        this.foodName = context.getResources().getStringArray(R.array.food_list);
        this.adId = context.getResources().getString(R.string.AM_Nat_Food);
        this.context    =   context;
    }

    @Override
    public int getItemViewType(int position) {
        if (Utils.isNetworkAvailable(context)   &&  !SharedPrefHelper.readBoolean(context, AppStateManager.IS_ADS_DISABLED) &&  position==2) {
            Log.d("Native Ad","Yes it is");
            return UNIFIED_NATIVE_AD_VIEW_TYPE;
        }else{
            return MENU_ITEM_VIEW_TYPE;
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        switch (viewType){
        case UNIFIED_NATIVE_AD_VIEW_TYPE:
            return new UnifiedNativeAdViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.ad_unified, parent, false));
        case    MENU_ITEM_VIEW_TYPE:
        default:
            return new myHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_food, parent, false));
    }
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, final int position) {
        int     viewType    =   getItemViewType(position);
        switch (viewType) {
            case UNIFIED_NATIVE_AD_VIEW_TYPE:
                Utils.setBigNativeAd(((UnifiedNativeAdViewHolder) holder).adView,adId);
                break;
            case MENU_ITEM_VIEW_TYPE:
            default:
                myHolder myHolder=(myHolder) holder;
                if (position == 0) {
                    myHolder.itemView.setBackgroundResource(R.drawable.ic_orange_round_bar);
                    myHolder.img.setImageResource(R.drawable.food_screen_weight_loss_image);

                } else if (position == 1) {
                    myHolder.itemView.setBackgroundResource(R.drawable.ic_red_round_bar);
                    myHolder.img.setImageResource(R.drawable.food_screen_pre_workout_image);

                } else if (position == 2    &&  (!Utils.isNetworkAvailable(context)   ||  SharedPrefHelper.readBoolean(context,AppStateManager.IS_ADS_DISABLED))) {
                    myHolder.itemView.setBackgroundResource(R.drawable.ic_blue_round_bar);
                    myHolder.img.setImageResource(R.drawable.food_screen_post_workout_image);

                } else if (position == 3    &&  (!Utils.isNetworkAvailable(context)   ||  SharedPrefHelper.readBoolean(context,AppStateManager.IS_ADS_DISABLED))) {
                    myHolder.itemView.setBackgroundResource(R.drawable.ic_green_round_bar);
                    myHolder.img.setImageResource(R.drawable.food_screen_fat_burning_foods_image);

                } else if (position == 3) {
                    myHolder.itemView.setBackgroundResource(R.drawable.ic_blue_round_bar);
                    myHolder.img.setImageResource(R.drawable.food_screen_post_workout_image);

                } else if (position == 4) {
                    myHolder.itemView.setBackgroundResource(R.drawable.ic_green_round_bar);
                    myHolder.img.setImageResource(R.drawable.food_screen_fat_burning_foods_image);

                }
                final int index;
                if (Utils.isNetworkAvailable(context)   &&  !SharedPrefHelper.readBoolean(context,AppStateManager.IS_ADS_DISABLED))
                    index = position > 2 ? position - 1 : position;
                else
                    index   =   position;
                myHolder.tvDayName.setText(foodName[index]);
                myHolder.itemView.setOnClickListener(view -> goToNewActivity(view.getContext(), index));
        }
    }

    @Override
    public int getItemCount() {
        if (foodName == null)
            return 0;
        else if (Utils.isNetworkAvailable(context)   &&  !SharedPrefHelper.readBoolean(context, AppStateManager.IS_ADS_DISABLED)){
            return foodName.length+1;
        }else{
            return foodName.length;
        }
    }

    class myHolder extends RecyclerView.ViewHolder {

        TextView tvDayName;
        ImageView img;

        myHolder(View itemView) {
            super(itemView);
            tvDayName = itemView.findViewById(R.id.tv_exerciseName);
            img = itemView.findViewById(R.id.img);
        }
    }


    private void goToNewActivity(Context context, int pos) {
        String[] foodTitle = {"Weight_Loss_Selected","Pre_workout_nutrition_selected", "Post_workout_nutrition_selected", "Fat_burning_foods_selected"};
        Intent i = new Intent(context, FoodDetailActivity.class).putExtra("pos", pos);
        AnalyticsManager.getInstance().sendAnalytics(foodTitle[pos], foodTitle[pos]);
        context.startActivity(i);
    }

}
