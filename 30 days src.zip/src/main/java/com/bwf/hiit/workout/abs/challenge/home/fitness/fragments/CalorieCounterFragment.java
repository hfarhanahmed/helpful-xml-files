package com.bwf.hiit.workout.abs.challenge.home.fitness.fragments;


import android.animation.Animator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.bwf.hiit.workout.abs.challenge.home.fitness.R;
import com.bwf.hiit.workout.abs.challenge.home.fitness.adapter.CalorieCounterFoodGroupAdaptor;
import com.bwf.hiit.workout.abs.challenge.home.fitness.adapter.CaloriesCounterSearchListAdaptor;
import com.bwf.hiit.workout.abs.challenge.home.fitness.databinding.FragmentCalorieCounterBinding;
import com.bwf.hiit.workout.abs.challenge.home.fitness.dto.APINutrientsDTO;
import com.bwf.hiit.workout.abs.challenge.home.fitness.dto.APISearchDTO;
import com.bwf.hiit.workout.abs.challenge.home.fitness.dto.FoodGroupJsonDTO;
import com.bwf.hiit.workout.abs.challenge.home.fitness.interfaces.APIResponseAsync;
import com.bwf.hiit.workout.abs.challenge.home.fitness.utils.JsonUtils;
import com.bwf.hiit.workout.abs.challenge.home.fitness.utils.USDAJsonParser;
import com.bwf.hiit.workout.abs.challenge.home.fitness.utils.USDAWebAPICaller;
import com.github.wrdlbrnft.sortedlistadapter.SortedListAdapter;

import org.json.JSONException;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

import static android.support.constraint.Constraints.TAG;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link CalorieCounterFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class CalorieCounterFragment extends Fragment implements APIResponseAsync, SortedListAdapter.Callback  {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private static final int API_SEARCH_LIST_ID = 101;
    private static final int API_NUTRIENTS_ID = 102;

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private EditText searchAutoComplete;
    private List<APISearchDTO>   searchItems;
    private List<FoodGroupJsonDTO>   foodGroups;
//    private FilterWithSpaceAdapter<String> adapter;


    private static final Comparator<APISearchDTO> COMPARATOR = new SortedListAdapter.ComparatorBuilder<APISearchDTO>()
            .setOrderForModel(APISearchDTO.class, (a, b) -> Integer.signum(a.getOffset()) - b.getOffset())
            .build();

    private CalorieCounterFoodGroupAdaptor foodGroupAdaptor;
    private CaloriesCounterSearchListAdaptor caloriesCounterSearchListAdaptor;
    private FragmentCalorieCounterBinding mBinding;
    private Animator mAnimator;

    public CalorieCounterFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment CalorieCounterFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static CalorieCounterFragment newInstance(String param1, String param2) {
        CalorieCounterFragment fragment = new CalorieCounterFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }
    Context context;


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
//        View view    =   inflater.inflate(R.layout.fragment_calorie_counter, container, false);

        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_calorie_counter, container, false);
        View view = mBinding.getRoot();
        searchAutoComplete  = view.findViewById(R.id.auto_comp_search);
        searchAutoComplete.setBackgroundColor(getResources().getColor(R.color.white));
//        searchAutoComplete.setDropDownAnchor(R.id.action_search);
//        searchAutoComplete.setThreshold(0);
        context =  getContext();
        searchItems =   new ArrayList<>();
        foodGroups  =   new ArrayList<>();
//        adapter = new FilterWithSpaceAdapter<>(context, android.R.layout.simple_list_item_1, searchItems);
//        searchAutoComplete.setAdapter(adapter);


        String response="";
        try {
            response = JsonUtils.readJsonFromAssets(context, "foodgroups.json");
            USDAJsonParser parser   =   new USDAJsonParser();
            foodGroups  =   parser.listFoodGroupJSONParser(response);
        } catch (Exception e) {
            Log.e(TAG, "foodgroups: " + e.getLocalizedMessage());
        }

        foodGroupAdaptor    =   new CalorieCounterFoodGroupAdaptor(context,R.layout.item_textview,foodGroups);
        mBinding.foodGroups.setAdapter(foodGroupAdaptor);

        caloriesCounterSearchListAdaptor = new CaloriesCounterSearchListAdaptor(context, COMPARATOR, model -> {
            Log.d("click",model.getNdbno());
            searchAutoComplete.setText(model.getName());
            caloriesCounterSearchListAdaptor.edit()
                    .removeAll()
                    .commit();
            mBinding.searchResultRecyclerView.setVisibility(View.GONE);
            hideKeyboard(Objects.requireNonNull(getActivity()));
            updateMacros(model.getNdbno());
        });

        caloriesCounterSearchListAdaptor.addCallback(this);

        mBinding.searchResultRecyclerView.setLayoutManager(new LinearLayoutManager(context));
        mBinding.searchResultRecyclerView.setAdapter(caloriesCounterSearchListAdaptor);

//        final String[] words = getResources().getStringArray(R.array.words);
//        for (int i = 0; i < words.length; i++) {
//            searchItems.add(new APISearchDTO(i, name, words[i]));
//        }
        caloriesCounterSearchListAdaptor.edit()
                .replaceAll(searchItems)
                .commit();
        searchAutoComplete.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.length()>0 &&  charSequence.charAt(charSequence.length()-1)==' '){
                    updateSearchList(charSequence.toString()); //.subSequence(0,charSequence.length()-1).toString()
                }else{
                    caloriesCounterSearchListAdaptor.edit()
                            .removeAll()
                            .commit();
                    emptyMacrosView();
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });

        searchAutoComplete.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    hideKeyboard(Objects.requireNonNull(getActivity()));
                    updateSearchList(searchAutoComplete.getText().toString());
                    return true;
                }
                return false;
            }
        });

        mBinding.foodGroups.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                searchAutoComplete.setText("");
                caloriesCounterSearchListAdaptor.edit()
                        .removeAll()
                        .commit();
                emptyMacrosView();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        return view;
    }

    private void updateSearchList(String    query) {
        try {
            String groupId  =   foodGroups.get(mBinding.foodGroups.getSelectedItemPosition()).getId();
            String url = "https://api.nal.usda.gov/ndb/search/?format=json&q="+URLEncoder.encode(query,"UTF-8")+"&fg="+URLEncoder.encode(groupId,"UTF-8")+"&sort=n&max=10&offset=0&api_key=TBXPHpIfQDnzzBTa0tSQqzhHj09YUhxVhY9N7Dr1";
//            String encodedUrl = URLEncoder.encode(url,"UTF-8");
            new USDAWebAPICaller(API_SEARCH_LIST_ID, this).execute(url);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }


    private void updateMacros(String  ndbno) {
        try {
            String  url="https://api.nal.usda.gov/ndb/nutrients/?format=json&api_key=TBXPHpIfQDnzzBTa0tSQqzhHj09YUhxVhY9N7Dr1&nutrients=208&nutrients=291&nutrients=205&nutrients=203&nutrients=269&nutrients=204&nutrients=307&nutrients=601&ndbno="+URLEncoder.encode(ndbno,"UTF-8");
//            String encodedUrl = URLEncoder.encode(url,"UTF-8");
            new USDAWebAPICaller(API_NUTRIENTS_ID,this).execute(url);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onEditStarted() {

    }

    @Override
    public void onEditFinished() {

    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onApiResponse(int id, String response) throws JSONException {
        if (id==API_SEARCH_LIST_ID){
            Log.d("query result",response);
            USDAJsonParser parser   =   new USDAJsonParser();
            List<APISearchDTO> list = parser.searchAPIParser(response);
            if (list!=null){
                searchItems.clear();
                for (int a=0;a<list.size();a++){
                    searchItems.add(new APISearchDTO(list.get(a).getOffset(), list.get(a).getName().substring(0,list.get(a).getName().lastIndexOf(",")),list.get(a).getNdbno()));
                }
//                searchItems.addAll(list);
                mBinding.searchResultRecyclerView.setVisibility(View.VISIBLE);
                caloriesCounterSearchListAdaptor.edit()
                        .removeAll()
                        .replaceAll(searchItems)
                        .commit();
//            caloriesCounterSearchListAdaptor.notifyDataSetChanged();
//            adapter = new FilterWithSpaceAdapter<>(context, android.R.layout.simple_list_item_1, searchItems);
//            searchAutoComplete.setAdapter(adapter);
                Log.d("result size",list.size()+"");
            }else {
                caloriesCounterSearchListAdaptor.edit()
                        .removeAll()
                        .commit();
                Toast.makeText(context,"No Result Found",Toast.LENGTH_SHORT).show();
            }
        }else   if (id==API_NUTRIENTS_ID){
            Log.d("query result",response);
            USDAJsonParser parser   =   new USDAJsonParser();
            List<APINutrientsDTO> list = parser.nutrientsAPIParser(response);
            if (list!=null) {
                for (int a = 0; a < list.size(); a++) {
                    switch (list.get(a).getNutrientId()) {
                        case "208":
                            mBinding.calorieCounterKal.setText(list.get(a).getValue());
                            break;
                        case "291":
                            mBinding.fiberText.setText(list.get(a).getValue() + list.get(a).getUnit());
                            break;
                        case "205":
                            mBinding.carbsText.setText(list.get(a).getValue() + list.get(a).getUnit());
                            break;
                        case "203":
                            mBinding.proteinText.setText(list.get(a).getValue() + list.get(a).getUnit());
                            break;
                        case "269":
                            mBinding.sugerText.setText(list.get(a).getValue() + list.get(a).getUnit());
                            break;
                        case "204":
                            mBinding.fatText.setText(list.get(a).getValue() + list.get(a).getUnit());
                            break;
                        case "307":
                            mBinding.sodiumText.setText(list.get(a).getValue() + list.get(a).getUnit());
                            break;
                        case "601":
                            mBinding.cholestrolText.setText(list.get(a).getValue() + list.get(a).getUnit());
                            break;
                    }
                }
            }
        }
    }

    public static void hideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        //Find the currently focused view, so we can grab the correct window token from it.
        View view = activity.getCurrentFocus();
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    public void emptyMacrosView(){
        mBinding.calorieCounterKal.setText("0");
        mBinding.fiberText.setText("0g");
        mBinding.carbsText.setText("0g");
        mBinding.proteinText.setText("0g");
        mBinding.sugerText.setText("0g");
        mBinding.fatText.setText("0g");
        mBinding.sodiumText.setText("0mg");
        mBinding.cholestrolText.setText("0mg");
    }

}
