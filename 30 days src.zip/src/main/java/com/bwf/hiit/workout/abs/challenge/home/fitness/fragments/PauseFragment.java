package com.bwf.hiit.workout.abs.challenge.home.fitness.fragments;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bwf.hiit.workout.abs.challenge.home.fitness.AppStateManager;
import com.bwf.hiit.workout.abs.challenge.home.fitness.R;
import com.bwf.hiit.workout.abs.challenge.home.fitness.helpers.SharedPrefHelper;
import com.bwf.hiit.workout.abs.challenge.home.fitness.managers.AdsManager;
import com.bwf.hiit.workout.abs.challenge.home.fitness.managers.AnalyticsManager;
import com.bwf.hiit.workout.abs.challenge.home.fitness.utils.Utils;
import com.bwf.hiit.workout.abs.challenge.home.fitness.view.PlayingExercise;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;

import java.util.Objects;


public class PauseFragment extends Fragment {

    View rootView;
    TextView tvExName;
    TextView tvExercise;
    ImageView btnResume;
    ImageView imgAnimate;
    PlayingExercise mActivity;
    UnifiedNativeAdView adView;
    UnifiedNativeAd nativeAd;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_pause, container, false);

//        AdView adView = rootView.findViewById(R.id.baner_Admob);
//        AdsManager.getInstance().showBanner(adView);

        adView = rootView.findViewById(R.id.ad_unified_layout);

        findReferences();
        return rootView;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (Utils.isNetworkAvailable(Objects.requireNonNull(getContext()))   &&  !SharedPrefHelper.readBoolean(getContext(), AppStateManager.IS_ADS_DISABLED)) {
            nativeAd=Utils.setBigNativeAd(adView,getResources().getString(R.string.AM_Nat_Exercise_Rest));
        }else{
            adView.setVisibility(View.GONE);
        }
    }

    @Override
    public void onDestroyView() {
        if (nativeAd!=null)nativeAd.destroy();
        super.onDestroyView();
    }

    @SuppressLint("SetTextI18n")
    private void findReferences() {
        mActivity = (PlayingExercise) getActivity();
        btnResume = rootView.findViewById(R.id.pauseResume);
        tvExName = rootView.findViewById(R.id.tv_pauseHeadline);
        imgAnimate = rootView.findViewById(R.id.pf_exerciseImage);
        tvExercise = rootView.findViewById(R.id.pf_exerciseText);

        if ((mActivity.currentEx + 1) != mActivity.totalExercises) {
            if (mActivity.nextExerciseName!=null)tvExName.setText(mActivity.nextExerciseName);

            int id = mActivity.getResources().getIdentifier(mActivity.nextExerciseImage, "drawable", mActivity.getPackageName());
            if (id != 0) {
                String path = "android.resource://" + mActivity.getPackageName() + "/" + id;
                Glide.with(this).load(mActivity.nextExerciseUrl).thumbnail(Glide.with(this).load(path)).into(imgAnimate);
            }
        }

        btnResume.setOnClickListener(view -> onResumeExercise());

        if (mActivity.currentEx <= (mActivity.totalExercises - 1))
            tvExercise.setText("Exercise " + (mActivity.currentEx + 1) + " of " + mActivity.totalExercises);
        else
            tvExercise.setText("Exercise " + mActivity.totalExercises + " of " + mActivity.totalExercises);
    }

    private void onResumeExercise() {
        mActivity.onResumeFragment();
    }

}
