package com.bwf.hiit.workout.abs.challenge.home.fitness.helpers;


public interface IMyWheelPicker {

    void setValue(int month);

    int getValue();

}
