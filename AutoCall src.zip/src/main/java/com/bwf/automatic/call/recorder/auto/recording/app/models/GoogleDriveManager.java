package com.bwf.automatic.call.recorder.auto.recording.app.models;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.IntentSender;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.drive.DriveApi;
import com.google.android.gms.drive.DriveClient;
import com.google.android.gms.drive.DriveContents;
import com.google.android.gms.drive.DriveFolder;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.DriveResourceClient;
import com.google.android.gms.drive.Metadata;
import com.google.android.gms.drive.MetadataChangeSet;
import com.google.android.gms.drive.OpenFileActivityOptions;
import com.google.android.gms.drive.query.Filters;
import com.google.android.gms.drive.query.Query;
import com.google.android.gms.drive.query.SearchableField;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.extensions.java6.auth.oauth2.AuthorizationCodeInstalledApp;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.googleapis.util.Utils;
import com.google.api.client.http.FileContent;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.util.store.FileDataStoreFactory;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.DriveScopes;
import com.google.api.services.drive.model.File;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.GeneralSecurityException;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.bwf.automatic.call.recorder.auto.recording.app.R;
import com.bwf.automatic.call.recorder.auto.recording.app.activities.RecordingDetailsActivity;
import com.bwf.automatic.call.recorder.auto.recording.app.database.LocalDatabase;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.AppConstant;


public class GoogleDriveManager implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener {

//    private GoogleApiClient mGoogleApiClient;
    private static final String TAG = "<<DRIVE>>";
    public static final int REQUEST_CODE_RESOLUTION = 1337;
    public static final int RC_SIGN_IN = 2231;
    public static final int RC_REQUEST_PERMISSION_SUCCESS_CONTINUE_FILE_CREATION = 2113;
    private String FOLDER_NAME = "CallRecordings";

    AppCompatActivity activity;
    Drive service;
    GoogleSignInClient  mGoogleSignInClient;
    private DriveClient mDriveClient;

    /**
     * Handle access to Drive resources/files.
     */
    private DriveResourceClient mDriveResourceClient;

    private static final String APPLICATION_NAME = "Automatic Call Recording";
    private static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();
    private static final String TOKENS_DIRECTORY_PATH = "tokens";
    /*
     * Global instance of the scopes required by this quickstart.
     * If modifying these scopes, delete your previously saved tokens/ folder.
     */
    private static final List<String> SCOPES = Collections.singletonList(DriveScopes.DRIVE_METADATA);
    private static final String CREDENTIALS_FILE_PATH = "/credentials.json";
    /**
     * Creates an authorized Credential object.
     * @param HTTP_TRANSPORT The network HTTP Transport.
     * @return An authorized Credential object.
     * @throws IOException If the credentials.json file cannot be found.
     */
    private static Credential getCredentials(AppCompatActivity  activity,final NetHttpTransport HTTP_TRANSPORT, GoogleSignInAccount account) throws IOException {
        // Load client secrets.
//        InputStream in = activity.getClass().getResourceAsStream(CREDENTIALS_FILE_PATH);
        InputStream in = activity.getAssets().open("credentials.json");
        Log.d("<<drive>>",in.toString());
        GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(in));

        java.io.File tokenFolder = new java.io.File(Environment.getExternalStorageDirectory() +
                java.io.File.separator + TOKENS_DIRECTORY_PATH);
        if (!tokenFolder.exists()) {
            tokenFolder.mkdirs();
        }

        // Build flow and trigger user authorization request.
        GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(
                HTTP_TRANSPORT, JSON_FACTORY, clientSecrets, SCOPES)
                .setDataStoreFactory(new FileDataStoreFactory(tokenFolder))
                .setAccessType("offline")
                .build();
        LocalServerReceiver receiver = new LocalServerReceiver.Builder().setPort(8888).build();
        return new AuthorizationCodeInstalledApp(flow, receiver).authorize(account.getId());
    }



    public GoogleDriveManager(AppCompatActivity activity) {

        this.activity=activity;

        // Configure sign-in to request the user's ID, email address, and basic
        // profile. ID and basic profile are included in DEFAULT_SIGN_IN.

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestScopes(new Scope("https://www.googleapis.com/auth/drive"))
                .requestScopes(com.google.android.gms.drive.Drive.SCOPE_FILE)
                .requestScopes(com.google.android.gms.drive.Drive.SCOPE_APPFOLDER)
                .requestEmail()
                .build();

        // Build a GoogleSignInClient with the options specified by gso.
        mGoogleSignInClient = GoogleSignIn.getClient(activity, gso);

    }

    private void signIn() {
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        activity.startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    public void checkSignInAndUpload(String filePath,GoogleSignInAccount    account){

        if (account==null)  account = GoogleSignIn.getLastSignedInAccount(activity);

        Set<Scope> requiredScopes = new HashSet<>(2);
        requiredScopes.add(com.google.android.gms.drive.Drive.SCOPE_FILE);
        requiredScopes.add(com.google.android.gms.drive.Drive.SCOPE_APPFOLDER);
        if (account!=null && account.getGrantedScopes().containsAll(requiredScopes)){
//            new GetCredentialsThenUpload(filePath,account).execute();
            mDriveClient    =   com.google.android.gms.drive.Drive.getDriveClient(activity.getApplicationContext(), account);
            mDriveResourceClient = com.google.android.gms.drive.Drive.getDriveResourceClient(activity.getApplicationContext(), account);
            Log.d(TAG,"Signed in and has permission");
            createFileInAppFolder(filePath);
        }else{
            signIn();
        }
    }

    private void check_permision_then_upload(String filePath) {
        Set<Scope> requiredScopes = new HashSet<>(2);
        requiredScopes.add(com.google.android.gms.drive.Drive.SCOPE_FILE);
        requiredScopes.add(com.google.android.gms.drive.Drive.SCOPE_APPFOLDER);
        if (!GoogleSignIn.hasPermissions(
                GoogleSignIn.getLastSignedInAccount(activity),
                com.google.android.gms.drive.Drive.SCOPE_APPFOLDER,com.google.android.gms.drive.Drive.SCOPE_FILE)) {
            GoogleSignIn.requestPermissions(
                    activity,
                    RC_REQUEST_PERMISSION_SUCCESS_CONTINUE_FILE_CREATION,
                    GoogleSignIn.getLastSignedInAccount(activity),
                    com.google.android.gms.drive.Drive.SCOPE_APPFOLDER,com.google.android.gms.drive.Drive.SCOPE_FILE);
        } else {
            createFileInAppFolder(filePath);
//            upload_to_drive(filePath);
        }
    }

    public void upload_to_drive(String  filePath) {
        //async check if folder exists... if not, create it. continue after with create_file_in_folder(driveId);
        if (service != null) {
            check_folder_exists(filePath);
        } else {
            Log.e(TAG, "Could not fucking connect to google drive manager");
        }
    }

    private void check_folder_exists(String  filePath) {
//        create_file_in_folder(filePath);
        createFileInAppFolder(filePath);
//        Query query =
//                new Query.Builder().addFilter(Filters.and(Filters.eq(SearchableField.TITLE, FOLDER_NAME), Filters.eq(SearchableField.TRASHED, false)))
//                        .build();
//        Drive.DriveApi.query(mGoogleApiClient, query).setResultCallback(new ResultCallback<DriveApi.MetadataBufferResult>() {
//            @Override public void onResult(DriveApi.MetadataBufferResult result) {
//                if (!result.getStatus().isSuccess()) {
//                    Log.e(TAG, "Cannot create folder in the root.");
//                } else {
//                    boolean isFound = false;
//                    for (Metadata m : result.getMetadataBuffer()) {
//                        if (m.getTitle().equals(FOLDER_NAME)) {
//                            Log.e(TAG, "Folder exists");
//                            isFound = true;
//                            DriveId driveId = m.getDriveId();
//                            create_file_in_folder(driveId,filePath);
//                            break;
//                        }
//                    }
//                    if (!isFound) {
//                        Log.i(TAG, "Folder not found; creating it.");
//                        MetadataChangeSet changeSet = new MetadataChangeSet.Builder().setTitle(FOLDER_NAME).build();
//                        Drive.DriveApi.getRootFolder(mGoogleApiClient)
//                                .createFolder(mGoogleApiClient, changeSet)
//                                .setResultCallback(new ResultCallback<DriveFolder.DriveFolderResult>() {
//                                    @Override public void onResult(DriveFolder.DriveFolderResult result) {
//                                        if (!result.getStatus().isSuccess()) {
//                                            Log.e(TAG, "U AR A MORON! Error while trying to create the folder");
//                                        } else {
//                                            Log.i(TAG, "Created a folder");
//                                            DriveId driveId = result.getDriveFolder().getDriveId();
//                                            create_file_in_folder(driveId,filePath);
//                                        }
//                                    }
//                                });
//                    }
//                }
//            }
//        });
    }



    // [START drive_android_create_file_in_appfolder]
    private void createFileInAppFolder(String   filePath){
        final Task<DriveFolder> appFolderTask = mDriveResourceClient.getAppFolder();
        final Task<DriveContents> createContentsTask = mDriveResourceClient.createContents();
        Tasks.whenAll(appFolderTask, createContentsTask)
                .continueWithTask(task -> {
                    DriveFolder parent = appFolderTask.getResult();
                    DriveContents contents = createContentsTask.getResult();
//                    OutputStream outputStream = contents.getOutputStream();
//                    try (Writer writer = new OutputStreamWriter(outputStream)) {
//                        writer.write("Hello World!");
//                    }

                    java.io.File    file    =   new java.io.File(filePath);
                    try (OutputStream out = contents.getOutputStream()) {

                        byte[] bytesArray = new byte[(int) file.length()];

                        FileInputStream fis = new FileInputStream(file);
                        fis.read(bytesArray); //read file into bytes[]
                        fis.close();

                        out.write(bytesArray);
                        out.flush();
                    } catch (IOException e) {
                        // handle exception
                    }

                    MetadataChangeSet changeSet = new MetadataChangeSet.Builder()
                            .setTitle("New Recording.amr")
                            .setMimeType("*/*")
                            .setStarred(true)
                            .build();

                    return mDriveResourceClient.createFile(parent, changeSet, contents);
                })
                .addOnSuccessListener(activity,
                        driveFile -> {
                            showMessage(activity.getString(R.string.file_created,
                                    driveFile.getDriveId().encodeToString()));
                            activity.finish();
                        })
                .addOnFailureListener(activity, e -> {
                    Log.e(TAG, "Unable to create file", e);
                    showMessage(activity.getString(R.string.file_create_error));
                    activity.finish();
                    e.printStackTrace();
                });
    }

    private void create_file_in_folder(String  filePath) {
        File fileMetadata = new File();
        fileMetadata.setName("recording.arm");
        java.io.File localFile = new java.io.File(filePath);
        try {
            FileContent mediaContent = new FileContent("*/*", localFile);
            File    file = service.files().create(fileMetadata, mediaContent)
                    .setFields("id")
                    .execute();
            System.out.println("File ID: " + file.getId());
        } catch (IOException e) {
            e.printStackTrace();
        }

//        Drive.DriveApi.newDriveContents(mGoogleApiClient).setResultCallback(new ResultCallback<DriveApi.DriveContentsResult>() {
//            @Override public void onResult(@NonNull DriveApi.DriveContentsResult driveContentsResult) {
//                if (!driveContentsResult.getStatus().isSuccess()) {
//                    Log.e(TAG, "U AR A MORON! Error while trying to create new file contents");
//                    return;
//                }
//
//                OutputStream outputStream = driveContentsResult.getDriveContents().getOutputStream();
//
//                //------ THIS IS AN EXAMPLE FOR PICTURE ------
//                //ByteArrayOutputStream bitmapStream = new ByteArrayOutputStream();
//                //image.compress(Bitmap.CompressFormat.PNG, 100, bitmapStream);
//                //try {
//                //  outputStream.write(bitmapStream.toByteArray());
//                //} catch (IOException e1) {
//                //  Log.i(TAG, "Unable to write file contents.");
//                //}
//                //// Create the initial metadata - MIME type and title.
//                //// Note that the user will be able to change the title later.
//                //MetadataChangeSet metadataChangeSet = new MetadataChangeSet.Builder()
//                //    .setMimeType("image/jpeg").setTitle("Android Photo.png").build();
//
//                //------ THIS IS AN EXAMPLE FOR FILE --------
//                Toast.makeText(activity, "Uploading to drive. If you didn't fucked up something like usual you should see it there", Toast.LENGTH_LONG).show();
//                final File theFile = new File(filePath); //>>>>>> WHAT FILE ?
//                try {
//                    int size = (int) theFile.length();
//                    FileInputStream fileInputStream = new FileInputStream(theFile);
//                    byte[] buffer = new byte[size];
//                    int bytesRead;
//                    while ((bytesRead = fileInputStream.read(buffer)) != -1) {
//                        outputStream.write(buffer, 0, bytesRead);
//                    }
//                } catch (IOException e1) {
//                    Log.i(TAG, "U AR A MORON! Unable to write file contents.");
//                }
//
//                MetadataChangeSet changeSet = new MetadataChangeSet.Builder().setTitle(theFile.getName()).setMimeType("*/*").setStarred(false).build();
//                DriveFolder folder = driveId.asDriveFolder();
//                folder.createFile(mGoogleApiClient, changeSet, driveContentsResult.getDriveContents())
//                        .setResultCallback(new ResultCallback<DriveFolder.DriveFileResult>() {
//                            @Override public void onResult(@NonNull DriveFolder.DriveFileResult driveFileResult) {
//                                if (!driveFileResult.getStatus().isSuccess()) {
//                                    Log.e(TAG, "U AR A MORON!  Error while trying to create the file");
//                                    return;
//                                }
//                                Log.v(TAG, "Created a file: " + driveFileResult.getDriveFile().getDriveId());
//                            }
//                        });
//            }
//        });
    }

    public void onResume() {
//        if (mGoogleApiClient == null) {
//            mGoogleApiClient = new GoogleApiClient.Builder(activity).addApi(Drive.API)
//                    .addScope(Drive.SCOPE_FILE)
//                    .addScope(Drive.SCOPE_APPFOLDER) // required for App Folder sample
//                    .addConnectionCallbacks(this)
//                    .addOnConnectionFailedListener(this)
//                    .build();
//        }
//        mGoogleApiClient.connect();
    }


    public void connectGoogleApiClient(){
//        mGoogleApiClient.connect();
    }

//    public void writeToFile(String fileName, String body) {
//        FileOutputStream fos = null;
//        try {
//            final File dir = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/xtests/");
//            if (!dir.exists()) {
//                if (!dir.mkdirs()) {
//                    Log.e("ALERT", "U AR A MORON!  could not create the directories. CHECK THE FUCKING PERMISSIONS SON!");
//                }
//            }
//            final File myFile = new File(dir, fileName + "_" + String.valueOf(System.currentTimeMillis()) + ".txt");
//            if (!myFile.exists()) {
//                myFile.createNewFile();
//            }
//
//            fos = new FileOutputStream(myFile);
//            fos.write(body.getBytes());
//            fos.close();
//            Toast.makeText(activity, "File created ok! Let me give you a fucking congratulations!", Toast.LENGTH_LONG).show();
//        } catch (IOException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//    }

    @Override public void onConnected(@Nullable Bundle bundle) {
        Log.v(TAG, "+++++++++++++++++++ onConnected +++++++++++++++++++");
    }

    @Override public void onConnectionSuspended(int i) {
        Log.e(TAG, "onConnectionSuspended [" + String.valueOf(i) + "]");
    }

    @Override public void onConnectionFailed(@NonNull ConnectionResult result) {
        Log.i(TAG, "GoogleApiClient connection failed: " + result.toString());
        if (!result.hasResolution()) {
            // show the localized error dialog.
            GoogleApiAvailability.getInstance().getErrorDialog(activity, result.getErrorCode(), 0).show();
            return;
        }
        try {
            result.startResolutionForResult(activity, REQUEST_CODE_RESOLUTION);
        } catch (IntentSender.SendIntentException e) {
            Log.e(TAG, "U AR A MORON! Exception while starting resolution activity", e);
        }
    }

    public void onPause() {
//        if (mGoogleApiClient != null) {
//            mGoogleApiClient.disconnect();
//        }
    }





    @SuppressLint("StaticFieldLeak")
    private class GetCredentialsThenUpload extends AsyncTask<Void, Void, Void> {
        String filePath;
        GoogleSignInAccount account;
        GetCredentialsThenUpload(String filePath,GoogleSignInAccount    account) {
            this.filePath=filePath;
            this.account=account;
        }

        @Override
        protected Void doInBackground(Void... voids) {

            final NetHttpTransport HTTP_TRANSPORT;
            try {
//            HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
                HTTP_TRANSPORT = new com.google.api.client.http.javanet.NetHttpTransport();
                service = new Drive.Builder(HTTP_TRANSPORT, JSON_FACTORY, getCredentials(activity,HTTP_TRANSPORT,account))
                        .setApplicationName(APPLICATION_NAME)
                        .build();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            check_permision_then_upload(filePath);
        }
    }

    /**
     * Shows a toast message.
     */
    protected void showMessage(String message) {
        Toast.makeText(activity, message, Toast.LENGTH_LONG).show();
    }
}
