package com.bwf.automatic.call.recorder.auto.recording.app.activities;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.webkit.URLUtil;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bwf.automatic.call.recorder.auto.recording.app.managers.MoPubAdsManager;
import com.google.ads.consent.ConsentForm;
import com.google.ads.consent.ConsentFormListener;
import com.google.ads.consent.ConsentInfoUpdateListener;
import com.google.ads.consent.ConsentInformation;
import com.google.ads.consent.ConsentStatus;
import com.bwf.automatic.call.recorder.auto.recording.app.R;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.AppConstant;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.SharedPreferenceHelper;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.UtilClass;
import com.bwf.automatic.call.recorder.auto.recording.app.inapp.MyBilling;
import com.bwf.automatic.call.recorder.auto.recording.app.managers.AnalyticsManager;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Objects;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;

public class BaseDrawerActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    Unbinder unbinder;
    private ConsentInformation consentInformation;
    private ConsentForm form;
    private boolean isAppInBackground = false;

    @BindView(R.id.main_base_constraint_layout)
    RelativeLayout mainLayout;

    @BindView(R.id.app_bar)
    AppBarLayout appBarLayout;


    MyBilling mBilling;

    //Toolbar Layout Init
    @BindView(R.id.toolbar_title)
    TextView toolbarTitle;
    @BindView(R.id.menu_no_ads)
    ImageView noAd;
    @BindView(R.id.menu_rate_us)
    ImageView menuRateUs;

    FrameLayout nativeAdView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_base_drawer);
        mainLayout=findViewById(R.id.main_base_constraint_layout);

//        consentInformation = ConsentInformation.getInstance(this);
//        requestGoogleConsentForm(true);
    }

    protected void setContentLayout(String title, int   layoutId){
        mainLayout.addView(LayoutInflater.from(this).inflate(layoutId,null));
        unbinder    =   ButterKnife.bind(this);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        toolbarTitle.setText(title);

        mBilling = new MyBilling(this);
        mBilling.onCreate();
        if (SharedPreferenceHelper.getInstance().getBooleanValue(AppConstant.IS_ADS_DISABLED,false)){
            noAd.setVisibility(View.GONE);
        }else{
            Glide.with(this).load(R.drawable.noads).into(noAd);
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        drawer.bringToFront();
        drawer.requestLayout();
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
//        navigationView.setItemIconTintList(null);
        LinearLayout headerLayout    = (LinearLayout)  navigationView.getHeaderView(0);
        nativeAdView =   headerLayout.findViewById(R.id.native_ad_layout);

        if (UtilClass.isNetworkAvailable(Objects.requireNonNull(this))   &&  !SharedPreferenceHelper.getInstance().getBooleanValue( AppConstant.IS_ADS_DISABLED,false)) {
            MoPubAdsManager.getInstance().load_CP_REC_Ads(nativeAdView,this.getString(R.string.MoPub_CP_Native));
        }else{
            nativeAdView.setVisibility(View.GONE);
        }

        navigationView.setNavigationItemSelectedListener(this);

    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this, R.style.SeekbarTheme);
            alertDialogBuilder.setTitle(getString(R.string.app_name));
            alertDialogBuilder
                    .setMessage("Do you want to exit?")
                    .setCancelable(false)
                    .setPositiveButton("YES", (dialog, id) -> {
                        dialog.cancel();
                        isAppInBackground = true;
                        super.onBackPressed();
                    }).setNeutralButton("Rate Us", (dialog, id) -> {
                dialog.cancel();
                UtilClass.onRateUs(this);
            }).setNegativeButton("NO", (dialog, id) -> dialog.cancel());
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
        }
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_Settings) {
            startActivity(new Intent(this, SettingsActivity.class));
        } else if (id == R.id.nav_rateus) {
            AnalyticsManager.getInstance().sendAnalytics("Side_Menu_Rate_Us","Side_Menu_Rate_Us");
            UtilClass.onRateUs(this);
        }  else if (id == R.id.nav_share_app) {
            AnalyticsManager.getInstance().sendAnalytics("Side_Menu_Share","Side_Menu_Share");
            UtilClass.shareApp(this);
        } else if (id == R.id.nav_more_apps) {
            AnalyticsManager.getInstance().sendAnalytics("Side_Menu_More_Apps","Side_Menu_More_Apps");
            onMoreAppsClicked();
        }else if (id == R.id.nav_privacy_policy) {
            AnalyticsManager.getInstance().sendAnalytics("Side_Menu_Privacy_Policy","Side_Menu_Privacy_Policy");
//            onPrivacyPolicyClicked();
            showPrivacyPolicy();
        } else if (id == R.id.nav_no_ads) {
            AnalyticsManager.getInstance().sendAnalytics("Side_Menu_Remove_Ads","Side_Menu_Remove_Ads");
            mBilling.purchaseRemoveAds();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void showPrivacyPolicy() {
        if (URLUtil.isValidUrl(getString(R.string.privacy_policy_url))) {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.privacy_policy_url)));
            startActivity(i);
        }
    }

    public void onMoreAppsClicked() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/developer?id=Body+Works+%26+Fitness+Group")));
        } catch (ActivityNotFoundException anfe) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/developer?id=Body+Works+%26+Fitness+Group")));
        }
    }

    public void onPrivacyPolicyClicked() {
        consentInformation.setConsentStatus(ConsentStatus.UNKNOWN);
        requestGoogleConsentForm(false);
    }

    @OnClick(R.id.menu_settings)
    void onSettingsClicked(){
        AnalyticsManager.getInstance().sendAnalytics("Top_Bar_Settings","Top_Bar_Settings");
        startActivity(new Intent(this,SettingsActivity.class));
    }

    @OnClick(R.id.menu_no_ads)
    void onNoAdClicked(){
        AnalyticsManager.getInstance().sendAnalytics("Top_Bar_Remove_Ads","Top_Bar_Remove_Ads");
        mBilling.purchaseRemoveAds();
    }

    @Override
    protected void onDestroy() {
        unbinder.unbind();
        super.onDestroy();
        isAppInBackground = true;
    }

    @OnClick(R.id.menu_rate_us)
    void onMenuRateUsClick(){
        AnalyticsManager.getInstance().sendAnalytics("Top_Bar_Rate_Us","Top_Bar_Rate_Us");
        UtilClass.onRateUs(this);
    }


    private void requestGoogleConsentForm(boolean isAppLaunch) {
        consentInformation.requestConsentInfoUpdate(new String[]{getString(R.string.publisher_id)}, new ConsentInfoUpdateListener() {
            @Override
            public void onConsentInfoUpdated(ConsentStatus consentStatus) {
                if (consentInformation.isRequestLocationInEeaOrUnknown()) {
                    // user is located in EEA, consent is required
                    if (consentStatus == ConsentStatus.UNKNOWN) {
                        showGoogleConsentForm();
                    }
                } else {
                    if (!isAppLaunch) {
                        if (!isAppInBackground)
                            showPrivacyPolicy();
                    }
                }
            }

            @Override
            public void onFailedToUpdateConsentInfo(String errorDescription) {
                // User's consent status failed to update
            }
        });
    }

    private void showGoogleConsentForm() {
        // consent not provided, collect consent using Google-rendered consent form
        URL privacyUrl = null;
        try {
            privacyUrl = new URL(getString(R.string.privacy_policy_url));
        } catch (MalformedURLException e) {
        }
        form = new ConsentForm.Builder(this, privacyUrl)
                .withPersonalizedAdsOption()
                .withNonPersonalizedAdsOption()
                .withListener(new ConsentFormListener() {
                    @Override
                    public void onConsentFormLoaded() {
                        // Consent form loaded successfully.
                        if (!isAppInBackground) {
                            form.show();
                        }
                    }

                    @Override
                    public void onConsentFormOpened() {
                        // Consent form was displayed.
                    }

                    @Override
                    public void onConsentFormClosed(ConsentStatus consentStatus, Boolean userPrefersAdFree) {
                        // Consent form was closed.
                        if (consentStatus == ConsentStatus.PERSONALIZED) {
                            SharedPreferenceHelper.getInstance().setBooleanValue(getString(R.string.npa), false);
                        } else if (consentStatus == ConsentStatus.NON_PERSONALIZED) {
                            SharedPreferenceHelper.getInstance().setBooleanValue(getString(R.string.npa), true);
                        }
                    }

                    @Override
                    public void onConsentFormError(String errorDescription) {
                        // Consent form error.
                    }
                })
                .build();
        form.load();
    }

    //    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        // Inflate the menu; this adds items to the action bar if it is present.
//        getMenuInflater().inflate(R.menu.base_drawer, menu);
//        return true;
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        // Handle action bar item clicks here. The action bar will
//        // automatically handle clicks on the Home/Up button, so long
//        // as you specify a parent activity in AndroidManifest.xml.
//        int id = item.getItemId();
//
//        //noinspection SimplifiableIfStatement
//        if (id == R.id.action_settings) {
//            return true;
//        }
//
//        return super.onOptionsItemSelected(item);
//    }
}
