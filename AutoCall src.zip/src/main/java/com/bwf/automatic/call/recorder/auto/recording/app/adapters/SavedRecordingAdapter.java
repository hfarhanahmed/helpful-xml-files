package com.bwf.automatic.call.recorder.auto.recording.app.adapters;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.bwf.automatic.call.recorder.auto.recording.app.R;
import com.bwf.automatic.call.recorder.auto.recording.app.activities.RecordingDetailsActivity;
import com.bwf.automatic.call.recorder.auto.recording.app.adapters.viewHolders.UnifiedNativeAdViewHolder;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.AppConstant;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.SharedPreferenceHelper;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.UtilClass;
import com.bwf.automatic.call.recorder.auto.recording.app.models.SaveRecordingModel;

import static android.support.constraint.Constraints.TAG;

/**
 * Created by RanaTalal on 9/28/2017.
 */

public class SavedRecordingAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    // A menu item view type.
    private static final int THEME_ITEM_VIEW_TYPE = 0;

    // The unified native ad view type.
    private static final int UNIFIED_NATIVE_AD_VIEW_TYPE = 1;

    private int adPosition  =   4;

    public static final int CALL_PERMISSION_CODE = 6452;
    List<SaveRecordingModel> arrayList;
//    List<UnifiedNativeAd> adList;
    Activity activity;

    public SavedRecordingAdapter(List<SaveRecordingModel> arrayList,List<UnifiedNativeAd>   adList, Activity activity) {
        this.arrayList = arrayList;
//        this.adList =   adList;
        this.activity = activity;
    }


//    @Override
//    public int getItemViewType(int position) {
//        if ((position+1)%adPosition==0   &&  adList.size()>0 &&  UtilClass.isNetworkAvailable(activity)   &&  !SharedPreferenceHelper.getInstance().getBooleanValue(AppConstant.IS_ADS_DISABLED,false)) {
//            return UNIFIED_NATIVE_AD_VIEW_TYPE;
//        }else{
//            return THEME_ITEM_VIEW_TYPE;
//        }
//    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
//        switch (viewType){
//            case UNIFIED_NATIVE_AD_VIEW_TYPE:
//                return new UnifiedNativeAdViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.ad_unified, parent, false));
//            case    THEME_ITEM_VIEW_TYPE:
//            default:
                view    =   LayoutInflater.from(parent.getContext()).inflate(R.layout.history_viewholder, null);
//        }
        return new HistoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int index) {
//        int     viewType    =   getItemViewType(index);
//        switch (viewType) {
//            case UNIFIED_NATIVE_AD_VIEW_TYPE:
//                if (adList.size() > (index / adPosition) && adList.get(index / adPosition) != null) {
//                    AdsManager.getInstance().populateUnifiedNativeAdView(adList.get(0), ((UnifiedNativeAdViewHolder) holder).adView);
//                }
//                break;
//            case THEME_ITEM_VIEW_TYPE:
//            default:
                HistoryViewHolder viewHolder = (HistoryViewHolder) holder;
                int position;
//                if (adList.size()>=1)
//                    position=index-((index+1)/adPosition);
//                else
                    position=index;

                    if (position<arrayList.size()){
                        SaveRecordingModel saveRecordingModel = arrayList.get(position);

                        String name = "", number = "";

                        number = saveRecordingModel.getName().split("in_")[1].split(".amr")[0];

                        try{
                            String mediaPath = saveRecordingModel.getFilePath();
                            MediaMetadataRetriever mmr = new MediaMetadataRetriever();
                            mmr.setDataSource(mediaPath);
                            String duration = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                            mmr.release();
                            int durationSec = Integer.parseInt(duration)/1000;
                            Log.d("duration",durationSec+"");
                            if (durationSec / 3600 > 0) {
                                viewHolder.durationTextView.setText(String.format("%02d", durationSec / 3600) + ":" + String.format("%02d", durationSec / 60) + ":" + String.format("%02d", durationSec % 60));
                            } else {
                                viewHolder.durationTextView.setText(String.format("%02d", durationSec / 60) + ":" + String.format("%02d", durationSec % 60));
                            }
                        }catch (Exception   e){
                            e.printStackTrace();
                            viewHolder.durationTextView.setText(saveRecordingModel.getDuration());
                        }

//                setContactNameAndImage(number, viewHolder);
                        viewHolder.phoneNoTextView.setText(number);
                        viewHolder.contactName.setText(saveRecordingModel.getContactName());
                        Date    date =  new Date(saveRecordingModel.getDate());
                        @SuppressLint("SimpleDateFormat") SimpleDateFormat    simpleDateFormat    =   new SimpleDateFormat("dd-MM-yyyy");
                        viewHolder.timeTextView.setText(simpleDateFormat.format(date));

                        if (saveRecordingModel.isIncomingCall()) {
                            viewHolder.callIcon.setImageResource(R.drawable.call_in);
                        } else {
                            viewHolder.callIcon.setImageResource(R.drawable.callout);
                        }

                        String finalNumber = number;
                        viewHolder.call.setOnClickListener(v -> makeCall(finalNumber));

                        viewHolder.detail.setOnClickListener(v -> {
                            Intent intent = new Intent(activity, RecordingDetailsActivity.class);
                            intent.putExtra("id", arrayList.get(position).getId());
                            activity.startActivity(intent);
                        });

                        viewHolder.itemView.setOnClickListener(v -> {
                            Intent intent = new Intent(activity, RecordingDetailsActivity.class);
                            intent.putExtra("id", arrayList.get(position).getId());
                            activity.startActivity(intent);
                        });
                    }
//        }

    }

    private String convertMiliToTime(long millis) {
        String time = String.format("%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(millis),
                TimeUnit.MILLISECONDS.toMinutes(millis) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(millis)),
                TimeUnit.MILLISECONDS.toSeconds(millis) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millis)));
        return time;
    }


    @Override
    public int getItemCount() {
//        if (arrayList.size()>3){
//            return arrayList.size()+adList.size();
//        }else{
//            return arrayList.size();
//        }
        if (arrayList!=null)
            return arrayList.size();
        else    return 0;
    }

    public class HistoryViewHolder extends RecyclerView.ViewHolder {
        TextView phoneNoTextView, timeTextView, durationTextView, call, detail, contactName;
        ImageView callIcon, contactIcon;

        public HistoryViewHolder(View itemView) {
            super(itemView);
            phoneNoTextView = itemView.findViewById(R.id.phone_no);
            timeTextView = itemView.findViewById(R.id.call_time);
            durationTextView = itemView.findViewById(R.id.call_duration_time);

            callIcon = itemView.findViewById(R.id.call_icon);
            contactIcon = itemView.findViewById(R.id.contact_image);

            call = itemView.findViewById(R.id.call);
            detail = itemView.findViewById(R.id.detail);
            contactName = itemView.findViewById(R.id.contact_name);
        }

    }


    public void setContactNameAndImage(final String phoneNumber, HistoryViewHolder holder) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (activity.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
        }

        int len = phoneNumber.length();
        Uri uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(phoneNumber.length() > 9 ? phoneNumber.substring(len - 9) : phoneNumber));

        String[] projection = new String[]{ContactsContract.Contacts._ID, ContactsContract.Contacts.DISPLAY_NAME_PRIMARY, ContactsContract.Contacts.PHOTO_THUMBNAIL_URI};

        String selection = null;
        if (phoneNumber.length() > 9)
            selection = ContactsContract.PhoneLookup.NUMBER + " LIKE %" + phoneNumber.substring(len - 9) + "%";
        else
            selection = ContactsContract.PhoneLookup.NUMBER + " LIKE %" + phoneNumber + "%";

        String contactName = "", imageUrl = "";
        int id = 0;
        Cursor cursor = activity.getContentResolver().query(uri, projection, selection, null, null);

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                id = cursor.getInt(0);
                contactName = cursor.getString(1);
                imageUrl = cursor.getString(2);


                int drawableId = -1;
                drawableId = getBackgroundDrawableId((holder.getAdapterPosition() % 5) + 1);
                if (drawableId != -1) {
                    holder.contactIcon.setBackgroundResource(drawableId);
                }

                if (imageUrl != null)
                    Glide.with(activity).load(imageUrl).apply(RequestOptions.circleCropTransform()).into(holder.contactIcon);
                holder.contactName.setText(contactName);
            }else{
                holder.contactName.setText("Unknown");
            }
            cursor.close();
        }
    }

    private int getBackgroundDrawableId(int randomNumber) {
        int drawableId = -1;
        if (randomNumber == 1) {
            drawableId = R.drawable.display_photo_background1;
        } else if (randomNumber == 2) {
            drawableId = R.drawable.display_photo_background2;
        } else if (randomNumber == 3) {
            drawableId = R.drawable.display_photo_background3;
        } else if (randomNumber == 4) {
            drawableId = R.drawable.display_photo_background4;
        } else if (randomNumber == 5) {
            drawableId = R.drawable.display_photo_background5;
        }
        return drawableId;
    }


    private void makeCall(String number) {
        try {
            Intent callIntent = new Intent(Intent.ACTION_CALL);
            callIntent.setData(Uri.parse("tel:" + number));
            if (ActivityCompat.checkSelfPermission(activity, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.

                ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.CALL_PHONE}, CALL_PERMISSION_CODE);
                return;
            }
            activity.startActivity(callIntent);
        } catch (Exception e) {
            Toast.makeText(activity, "Phone app not found", Toast.LENGTH_SHORT).show();
            Log.d(TAG, "Error making call: " + e.getLocalizedMessage());
        }
    }
}
