package com.bwf.automatic.call.recorder.auto.recording.app;

import android.content.Context;
import android.support.multidex.MultiDex;
import android.support.multidex.MultiDexApplication;

import com.bwf.automatic.call.recorder.auto.recording.app.helper.AppConstant;
import com.bwf.automatic.call.recorder.auto.recording.app.managers.MoPubAdsManager;


public class Application extends MultiDexApplication {

    public static Context context;
    private static Application instance;


    public static Application getInstance() {
        return instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        context = getApplicationContext();
        AppConstant.CONTEXT=getApplicationContext();
        instance=this;


        MoPubAdsManager.getInstance().initializtion();

        MultiDex.install(this);

//        MobileAds.initialize(this, context.getString(R.string.app_id));
//        if (BuildConfig.DEBUG) {
//            AdSettings.addTestDevice("1cc22019-6450-4d86-96f9-ad5ba867d13f");
//        }
//        // preload the ads
//         AdsManager.getInstance();
    }

    public static Context getContext() {
        return context;
    }

}
