package com.bwf.automatic.call.recorder.auto.recording.app.receivers;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.support.v4.app.NotificationCompat;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import com.bwf.automatic.call.recorder.auto.recording.app.FloatingIconService;
import com.bwf.automatic.call.recorder.auto.recording.app.R;
import com.bwf.automatic.call.recorder.auto.recording.app.activities.ApplyBackgroudToSpecificsActivity;
import com.bwf.automatic.call.recorder.auto.recording.app.activities.MainActivity;
import com.bwf.automatic.call.recorder.auto.recording.app.database.LocalDatabase;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.AppConstant;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.SharedPreferenceHelper;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.UtilClass;
import com.bwf.automatic.call.recorder.auto.recording.app.models.ContactSettings;
import com.bwf.automatic.call.recorder.auto.recording.app.models.SaveRecordingModel;

import static android.support.v4.app.NotificationCompat.VISIBILITY_PUBLIC;

public class PhoneStateReceiver extends BroadcastReceiver {

    private static MediaRecorder mediaRecorder;
    int state = 0;
    String saveNo;
    String stringDate;
    boolean mStart, mStop;
    Date date;
    String CHANNEL_ID = "my_channel_01";
    Context context;


    @Override
    public void onReceive(final Context context, Intent intent) {
        if (intent != null) {
            date = new Date();
            stringDate = String.valueOf(Calendar.getInstance().getTimeInMillis());
            this.context = context;
            String stateStr = Objects.requireNonNull(intent.getExtras()).getString(TelephonyManager.EXTRA_STATE);
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.LOLLIPOP_MR1) {
                Bundle bundle = intent.getExtras();
                String getNo = bundle.getString("incoming_number");
                saveNo = getNo;
                Log.d("checkStatus", "onReceive: " + saveNo);

            } else {
                saveNo = intent.getExtras().getString(TelephonyManager.EXTRA_INCOMING_NUMBER);
                Log.d("checkStatus > Lollipop", "onReceive: " + saveNo);
            }

            AppConstant.CONTEXT = context;

            if (stateStr.equals(TelephonyManager.EXTRA_STATE_IDLE)) {
                state = TelephonyManager.CALL_STATE_IDLE;
            } else if (stateStr.equals(TelephonyManager.EXTRA_STATE_OFFHOOK)) {
                state = TelephonyManager.CALL_STATE_OFFHOOK;
            } else if (stateStr.equals(TelephonyManager.EXTRA_STATE_RINGING)) {
                state = TelephonyManager.CALL_STATE_RINGING;
            }


            if (SharedPreferenceHelper.getInstance().getBooleanValue(AppConstant.IS_RECORDING_ENABLE, true)) {
                if (SharedPreferenceHelper.getInstance().getBooleanValue(AppConstant.IS_RECORDING_MODE_AUTOMATIC, true)) {
                    checkRecordingCase();
                } else {
                    //Show Manual Button
                    if (SharedPreferenceHelper.getInstance().getBooleanValue(AppConstant.IS_OVERLAY_ENABLED, false)) {
                        checkStatusForFloatingService(state, 0);
                        Log.d("<<CallSTATUS>>", "0");
                    }
                }
            }
        }
    }


    private void checkRecordingCase() {
        if (SharedPreferenceHelper.getInstance().getBooleanValue(AppConstant.IS_RECORD_CONTACTS, false)) {
            new GetContact(getContactId(saveNo, AppConstant.CONTEXT), state, 0).execute();
            Log.d("<<CallSTATUS>>", "0");
        } else if (SharedPreferenceHelper.getInstance().getBooleanValue(AppConstant.IS_OVERLAY_ENABLED, false) && Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
//					checkStatus(state);
            checkStatusForFloatingService(state, 1);
            Log.d("<<CallSTATUS>>", "1");
        } else if (SharedPreferenceHelper.getInstance().getBooleanValue(AppConstant.IS_OVERLAY_ENABLED, false) && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
//					checkStatus(state);
            if (UtilClass.isForegroundPermissionAllowed(AppConstant.CONTEXT)) {
                checkStatusForFloatingService(state, 1);
                Log.d("<<CallSTATUS>>", "1");
            } else {
                checkStatus(state);
            }
        } else {
            checkStatus(state);
        }
    }


    private String audioFileName() {
        String state;
        if (SharedPreferenceHelper.getInstance().getBooleanValue(AppConstant.CALL_STATUS, false)) {
            state = "incoming";
        } else {
            state = "outgoing";
        }
        String fileName = state + "," + stringDate/*+"_"+stringTime*/ + "_in_" + saveNo;
        return fileName;
    }


    @SuppressLint("StaticFieldLeak")
    private class SaveRecordingToDB extends AsyncTask<Void, Void, Void> {
        SaveRecordingModel saveRecordingModel;
        long id;

        SaveRecordingToDB(SaveRecordingModel saveRecordingModel) {
            this.saveRecordingModel = saveRecordingModel;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            LocalDatabase appDataBase = LocalDatabase.getInstance(AppConstant.CONTEXT);
            appDataBase.saveRecordingDAO().insert(saveRecordingModel);
            Log.d("saved", "database");
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }
    }


    @SuppressLint("StaticFieldLeak")
    private class GetContact extends AsyncTask<Void, Void, ContactSettings> {
        LocalDatabase appDataBase;
        int contactId = 0;
        int state = 0;
        int overlayState;

        GetContact(int contactId, int state, int overlayState) {
            this.contactId = contactId;
            this.state = state;
            this.overlayState = overlayState;
        }

        @Override
        protected ContactSettings doInBackground(Void... voids) {
            appDataBase = LocalDatabase.getInstance(AppConstant.CONTEXT);
            ContactSettings contactSetting = appDataBase.contactSettingsDao().findById(contactId);
            return contactSetting;
        }

        @Override
        protected void onPostExecute(ContactSettings contactSettings) {
            super.onPostExecute(contactSettings);
            if (SharedPreferenceHelper.getInstance().getBooleanValue(AppConstant.IS_OVERLAY_ENABLED, false)) {
                if (contactSettings != null && contactSettings.getId() != 0) {
//				checkStatus(state);
                    checkStatusForFloatingService(state, 1);
                } else {
                    Log.d("Contact Settings", "null or empty");
                    checkStatusForFloatingService(state, 0);
                }
            } else if (contactSettings != null && contactSettings.getId() != 0) {
                checkStatus(state);
            }
        }
    }

    private void checkStatusForFloatingService(int state, int overlayState) {
        switch (state) {
            case TelephonyManager.CALL_STATE_RINGING:
                SharedPreferenceHelper.getInstance().setBooleanValue(AppConstant.CALL_STATUS, true);
                break;
            case TelephonyManager.CALL_STATE_OFFHOOK:
                checkOverlayStartFloatingsService(overlayState);
                break;
            case TelephonyManager.CALL_STATE_IDLE:
                checkOverlayStartFloatingsService(overlayState);
                break;
        }
    }

    private void checkOverlayStartFloatingsService(int overlayState) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(context)) {
            startFloatingButtonService(overlayState);
        } else if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            startFloatingButtonService(overlayState);
        }
//        else if (SharedPreferenceHelper.getInstance().getBooleanValue(AppConstant.IS_RECORDING_ENABLE, true)) {
//            checkStatus(state);
//        }
    }


    private void checkStatus(int state) {
        switch (state) {
            case TelephonyManager.CALL_STATE_RINGING: {
                SharedPreferenceHelper.getInstance().setBooleanValue(AppConstant.CALL_STATUS, true);
                Log.d("checkStatus", "CALL_STATE_RINGING: ");
                break;
            }
            case TelephonyManager.CALL_STATE_OFFHOOK: {
                Log.d("checkStatus", "CALL_STATE_OFFHOOK: ");
                createRecordingNotification(context, "Recording", 001, "OffHook");
                if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.LOLLIPOP_MR1) {
                    if (saveNo != null) {
                        startRecordCall();
                    } else {
                        Log.d("saveno", "null");
                    }
                } else {
                    startRecordCall();
                }
                break;
            }
            case TelephonyManager.CALL_STATE_IDLE: {
                Log.d("checkStatus", "CALL_STATE_IDLE: ");
                if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.LOLLIPOP_MR1) {
                    stopRecordCall();
                } else {
                    stopRecordCall();
                }
                createRecordingNotification(context, "Recorded", 001, "idle");
                break;
            }
        }
    }


    private void stopRecordCall() {
        try {
            if (mediaRecorder != null && mStart) {
                mStart = false;
                mediaRecorder.stop();
                mediaRecorder.reset();
                mediaRecorder.release();
                mediaRecorder = null;
            } else {
                Log.d("Media Recorder", "null");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        SharedPreferenceHelper.getInstance().setBooleanValue(AppConstant.CALL_STATUS, false);
    }


    private void startRecordCall() {
        mediaRecorderReady();
        if (mediaRecorder != null) {
            if (!mStart) {
                try {
                    mediaRecorder.start();
                    mStart = true;
                } catch (Exception e) {
                    e.printStackTrace();

                }
            }
        } else {
            Log.d("recorder", "null on start");
        }
    }


    private void startFloatingButtonService(int overlayState) {
        Intent serviceIntent = new Intent(context, FloatingIconService.class);
        serviceIntent.putExtra("state", state);
        serviceIntent.putExtra("saveNo", saveNo);
        serviceIntent.putExtra("date", date.getTime());
        serviceIntent.putExtra("stringDate", stringDate);
        serviceIntent.putExtra("overlayState", overlayState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent);
        } else {
            context.startService(serviceIntent);
        }
    }


    public int getContactId(final String phoneNumber, Context context) {
        if (phoneNumber != null && !phoneNumber.isEmpty()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (context.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                    return 0;
                }
            }
            int len = phoneNumber.length();
            Uri uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(phoneNumber.length() > 9 ? phoneNumber.substring(len - 9) : phoneNumber));
            String[] projection = new String[]{ContactsContract.Contacts._ID, ContactsContract.Contacts.DISPLAY_NAME_PRIMARY, ContactsContract.Contacts.PHOTO_THUMBNAIL_URI};
            String selection = null;
            if (phoneNumber.length() > 9)
                selection = ContactsContract.PhoneLookup.NUMBER + " LIKE %" + phoneNumber.substring(len - 9) + "%";
            else
                selection = ContactsContract.PhoneLookup.NUMBER + " LIKE %" + phoneNumber + "%";

            String contactName = "", imageUrl = "";
            int id = 0;
            Cursor cursor = context.getContentResolver().query(uri, projection, selection, null, null);

            if (cursor != null) {
                if (cursor.moveToFirst()) {
                    id = cursor.getInt(0);
                    contactName = cursor.getString(1);
                } else {
                    contactName = phoneNumber;
                    id = 0;
                }
                cursor.close();
            }
            return id;
        } else {
            return 0;
        }
    }


    private void mediaRecorderReady() {
        File file = new File(AppConstant.FILE_PATH);
        if (!file.exists()) {
            Log.d("callreceiver", "file not exist: " + "audio " + " file " + file);
            file.mkdirs();
        }
        mediaRecorder = new MediaRecorder();
        String manufacturer = Build.MANUFACTURER;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP && !manufacturer.toLowerCase().contains("htc") && !manufacturer.toLowerCase().contains("mi") && !manufacturer.toLowerCase().contains("samsung")) {
            mediaRecorder.setAudioSource(MediaRecorder.AudioSource.VOICE_CALL);
//            Toast.makeText(AppConstant.CONTEXT, "Open speaker then call Record ", Toast.LENGTH_SHORT).show();
        } else {
            mediaRecorder.setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION);
        }
        mediaRecorder.setAudioSamplingRate(8000);
        mediaRecorder.setAudioEncodingBitRate(12200);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
        mediaRecorder.setOutputFile(file + File.separator + audioFileName() + ".amr");

        new SaveRecordingToDB(new SaveRecordingModel(audioFileName(), "", AppConstant.FILE_PATH + File.separator + audioFileName() + ".amr", SharedPreferenceHelper.getInstance().getBooleanValue(AppConstant.CALL_STATUS, false), "", date.getTime(), saveNo, saveNo != null ? getContactName(saveNo, AppConstant.CONTEXT) : "Unknown", "", false)).execute();

        Log.d("callreceiver", "startRecordCall: " + "audio " + " file " + file + File.separator + audioFileName() + ".3gp");
        try {
            mediaRecorder.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void createRecordingNotification(Context context, String message, int id, String notificationType) {
        Intent intent = new Intent(context, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, 0);


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel chan1 = new NotificationChannel(CHANNEL_ID, "NOTIFICATION_CHANNEL_NAME", NotificationManager.IMPORTANCE_DEFAULT);
            chan1.setLightColor(Color.GREEN);
            chan1.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            assert manager != null;
            manager.createNotificationChannel(chan1);

            Notification.Builder notification = new Notification.Builder(context, CHANNEL_ID)
                    .setContentTitle(saveNo)
                    .setContentText(message)
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setAutoCancel(false)
                    .setOngoing(true);

            if (notificationType.equals("idle")) {
                manager.cancel(001);
                notification.setOngoing(false);
                notification.setContentIntent(pendingIntent);
            }

            manager.notify(id, notification.build());
        } else {
            NotificationCompat.Builder builder = new NotificationCompat.Builder(context)
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setContentTitle(saveNo)
                    .setContentText(message)
                    .setDefaults(Notification.DEFAULT_ALL)
                    .setAutoCancel(false)
                    .setOngoing(true)
                    .setVisibility(VISIBILITY_PUBLIC);
            NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (notificationType.equals("idle")) {
                manager.cancel(001);
                builder.setOngoing(false);
                builder.setContentIntent(pendingIntent);
            }
            assert manager != null;
            manager.notify(id, builder.build());
        }

    }


    public String getContactName(final String phoneNumber, Context activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (activity.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                return "";
            }
        }

        int len = phoneNumber.length();
        Uri uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(phoneNumber.length() > 9 ? phoneNumber.substring(len - 9) : phoneNumber));

        String[] projection = new String[]{ContactsContract.Contacts._ID, ContactsContract.Contacts.DISPLAY_NAME_PRIMARY, ContactsContract.Contacts.PHOTO_THUMBNAIL_URI};

        String selection = null;
        if (phoneNumber.length() > 9)
            selection = ContactsContract.PhoneLookup.NUMBER + " LIKE %" + phoneNumber.substring(len - 9) + "%";
        else
            selection = ContactsContract.PhoneLookup.NUMBER + " LIKE %" + phoneNumber + "%";

        String contactName = "", imageUrl = "";
        int id = 0;
        Cursor cursor = activity.getContentResolver().query(uri, projection, selection, null, null);

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                id = cursor.getInt(0);
                contactName = cursor.getString(1);
                return contactName;

            }
            cursor.close();
        }
        return "Unknown";
    }

}
