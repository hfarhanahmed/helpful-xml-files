package com.bwf.automatic.call.recorder.auto.recording.app.activities;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.SwitchCompat;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.webkit.URLUtil;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.bwf.automatic.call.recorder.auto.recording.app.managers.MoPubAdsManager;
import com.google.ads.consent.ConsentForm;
import com.google.ads.consent.ConsentFormListener;
import com.google.ads.consent.ConsentInfoUpdateListener;
import com.google.ads.consent.ConsentInformation;
import com.google.ads.consent.ConsentStatus;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Objects;

import com.bwf.automatic.call.recorder.auto.recording.app.R;
import com.bwf.automatic.call.recorder.auto.recording.app.database.LocalDatabase;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.AppConstant;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.SharedPreferenceHelper;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.UtilClass;
import com.bwf.automatic.call.recorder.auto.recording.app.managers.AnalyticsManager;
import com.mopub.common.MoPub;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnCheckedChanged;
import butterknife.OnClick;
import butterknife.Unbinder;

import static com.bwf.automatic.call.recorder.auto.recording.app.helper.UtilClass.PERMISSION;

public class SettingsActivity extends AppCompatActivity {

    private static final int DRAW_OVER_OTHER_APP_PERMISSION = 654;
    public int PERMISSION_CODE = 25;

    Unbinder    unbinder;

    @BindView(R.id.record_every_call)
    SwitchCompat recordEveryCallSwitch;

    @BindView(R.id.settings_toolbar)
    Toolbar toolbar;

    @BindView(R.id.record_mode_details)
    AppCompatTextView recordModeDetails;

    @BindView(R.id.storage_details)
    AppCompatTextView storageDetails;

    @BindView(R.id.app_version_details)
    AppCompatTextView appVersionDetails;

    @BindView(R.id.native_ad_layout)
    FrameLayout nativeAdView;

    private ConsentInformation consentInformation;
    private ConsentForm form;
    private boolean isAppInBackground = false;
    private boolean isDialogOpen=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        unbinder    = ButterKnife.bind(this);

//        consentInformation = ConsentInformation.getInstance(this);
//        requestGoogleConsentForm(true);

        recordEveryCallSwitch.setChecked(SharedPreferenceHelper.getInstance().getBooleanValue(AppConstant.IS_RECORDING_ENABLE,true));
        toolbar.setNavigationOnClickListener(v -> onBackPressed());

        AnalyticsManager.getInstance().sendAnalytics("Settings_Screen","Settings_Screen");

        MoPubAdsManager.getInstance().load_CP_REC_Ads(nativeAdView,this.getString(R.string.MoPub_CP_Native));
        if (UtilClass.isNetworkAvailable(this)   &&  !SharedPreferenceHelper.getInstance().getBooleanValue(AppConstant.IS_ADS_DISABLED,false)){
            MoPubAdsManager.getInstance().loadMoPubInterstital(this.getString(R.string.MoPubInterstital),this);
            MoPubAdsManager.getInstance().showMoPubInterstitial();
        }
    }

    @Override
    protected void onResume() {
        MoPub.onResume(this);
        recordModeDetails.setText(SharedPreferenceHelper.getInstance().getBooleanValue(AppConstant.IS_RECORDING_MODE_AUTOMATIC,true)?"Automatic":"Manual");
        storageDetails.setText(AppConstant.FILE_PATH);
        try {
            PackageInfo pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
            String version = pInfo.versionName;
            appVersionDetails.setText(version);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        if (isDialogOpen){
            showRecordModeSettings();
        }

        super.onResume();
    }

    @OnCheckedChanged(R.id.record_every_call)
    void onRecordEveryCall(boolean  isChecked){
        if (isChecked){
                if (UtilClass.isAllowPermission(this)){
                    SharedPreferenceHelper.getInstance().setBooleanValue(AppConstant.IS_RECORDING_ENABLE,isChecked);
                }else if (isChecked){
                    recordEveryCallSwitch.setChecked(false);
                    showPrePermissionDialog();
                }

//            if (SharedPreferenceHelper.getInstance().getBooleanValue(AppConstant.IS_CONSENT_AGREED,false)){ }else {
//                recordEveryCallSwitch.setChecked(false);
//                UtilClass.showConsentDialog(this);
//            }
        }else{
            SharedPreferenceHelper.getInstance().setBooleanValue(AppConstant.IS_RECORDING_ENABLE,isChecked);
        }
    }

    @OnClick(R.id.record_mode)
    void onSpecificCallRecord(){
        showRecordModeSettings();
//        startActivity(new Intent(this,ApplyBackgroudToSpecificsActivity.class));
    }

    private void showRecordModeSettings() {
        final Dialog dialog = new Dialog(this,android.R.style.Theme_Translucent_NoTitleBar);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.dialog_recording_mode_settings);
        SwitchCompat automaticSwitch =   dialog.findViewById(R.id.automatic_record_call);
        SwitchCompat recordContactsSwitch =   dialog.findViewById(R.id.record_contacts_switch);
        SwitchCompat screenOverlaySwitch =   dialog.findViewById(R.id.screen_overlay_switch);
        LinearLayout    automaticLayout =   dialog.findViewById(R.id.automatic_layout);
        LinearLayout    manualLayout =   dialog.findViewById(R.id.manual_layout);
        AppCompatTextView   contactsSelectedTV  =   dialog.findViewById(R.id.contacts_selected_text);
        AppCompatTextView   recordAllDetails  =   dialog.findViewById(R.id.record_all_details);

        new UpdateSelectedContactsText(contactsSelectedTV).execute();

        dialog.show();
        isDialogOpen=true;

        recordEveryCallSwitch.setChecked(SharedPreferenceHelper.getInstance().getBooleanValue(AppConstant.IS_RECORDING_ENABLE,true));
        automaticSwitch.setChecked(SharedPreferenceHelper.getInstance().getBooleanValue(AppConstant.IS_RECORDING_MODE_AUTOMATIC,true));
        recordContactsSwitch.setChecked(!SharedPreferenceHelper.getInstance().getBooleanValue(AppConstant.IS_RECORD_CONTACTS,false));
        screenOverlaySwitch.setChecked(SharedPreferenceHelper.getInstance().getBooleanValue(AppConstant.IS_OVERLAY_ENABLED,false));
        if (!SharedPreferenceHelper.getInstance().getBooleanValue(AppConstant.IS_RECORD_CONTACTS,false)){
            dialog.findViewById(R.id.contacts_to_record).setAlpha(0.3f);
            dialog.findViewById(R.id.contacts_to_record).setBackgroundColor(Color.parseColor("#00F7A7A6"));
//            recordAllDetails.setText("All incoming and outgoing calls will be recorded.");
        }else{
            dialog.findViewById(R.id.contacts_to_record).setAlpha(1.0f);
            dialog.findViewById(R.id.contacts_to_record).setBackgroundColor(Color.parseColor("#44F7A7A6"));
//            recordAllDetails.setText("Select contacts to record their calls.");
        }

        if (SharedPreferenceHelper.getInstance().getBooleanValue(AppConstant.IS_RECORDING_MODE_AUTOMATIC,true)){
            automaticLayout.setVisibility(View.VISIBLE);
            manualLayout.setVisibility(View.GONE);
        }else{
            automaticLayout.setVisibility(View.GONE);
            manualLayout.setVisibility(View.VISIBLE);
        }


        dialog.findViewById(R.id.contacts_to_record).setOnClickListener(v -> startActivity(new Intent(SettingsActivity.this,ContactsToRecordActivity.class)));

        automaticSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            SharedPreferenceHelper.getInstance().setBooleanValue(AppConstant.IS_RECORDING_MODE_AUTOMATIC,isChecked);
            if (isChecked){
                automaticLayout.setVisibility(View.VISIBLE);
                manualLayout.setVisibility(View.GONE);
            }else{
                automaticLayout.setVisibility(View.GONE);
                manualLayout.setVisibility(View.VISIBLE);
            }
        });

        dialog.findViewById(R.id.contacts_to_record).setOnClickListener(v -> {
            if(!recordContactsSwitch.isChecked()) {
                startActivity(new Intent(SettingsActivity.this,ContactsToRecordActivity.class));
                dialog.dismiss();
            }
            else Toast.makeText(this,"Turn off Record All first",Toast.LENGTH_SHORT).show();
        });

        recordContactsSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            SharedPreferenceHelper.getInstance().setBooleanValue(AppConstant.IS_RECORD_CONTACTS,!isChecked);
            if (isChecked){
                dialog.findViewById(R.id.contacts_to_record).setAlpha(0.3f);
                dialog.findViewById(R.id.contacts_to_record).setBackgroundColor(Color.parseColor("#00F7A7A6"));
//                recordAllDetails.setText("All incoming and outgoing calls will be recorded.");
            }else{
                dialog.findViewById(R.id.contacts_to_record).setAlpha(1.0f);
                dialog.findViewById(R.id.contacts_to_record).setBackgroundColor(Color.parseColor("#44F7A7A6"));
//                recordAllDetails.setText("Select contacts to record their calls.");
            }
        });

        screenOverlaySwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked){
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
                    if (!Settings.canDrawOverlays(SettingsActivity.this)){
                        askForSystemOverlayPermission();
                        screenOverlaySwitch.setChecked(false);
                        dialog.dismiss();
                    }else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P    &&  !UtilClass.isForegroundPermissionAllowed(this)){
                        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.FOREGROUND_SERVICE}, DRAW_OVER_OTHER_APP_PERMISSION);
                    }else{
                        SharedPreferenceHelper.getInstance().setBooleanValue(AppConstant.IS_OVERLAY_ENABLED,isChecked);
                    }
                }else{
                    SharedPreferenceHelper.getInstance().setBooleanValue(AppConstant.IS_OVERLAY_ENABLED,isChecked);
                }
            }else{
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
                alertDialogBuilder.setTitle("Call Recording Disable:");
                alertDialogBuilder
                        .setMessage("Do you want to disable Call Recording?")
                        .setCancelable(false)
                        .setPositiveButton("CONTINUE", (dialog12, which) -> {
                            dialog12.cancel();
                            SharedPreferenceHelper.getInstance().setBooleanValue(AppConstant.IS_OVERLAY_ENABLED,isChecked);
                        }).setNegativeButton("CANCEL", (dialog12, id) -> dialog.cancel());
                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();
            }
        });

        ((Toolbar)dialog.findViewById(R.id.mode_settings_toolbar)).setNavigationOnClickListener(v ->
                {
                    dialog.dismiss();
                    isDialogOpen = false;
                }
        );

        dialog.setOnCancelListener(dialog1 -> isDialogOpen = false);

    }

    @OnClick(R.id.share_app)
    void onShareAppClicked(){
        UtilClass.shareApp(this);
    }

    @OnClick(R.id.privacy_policy)
    void onPrivacyPolicy(){
//            AnalyticsManager.getInstance().sendAnalytics("Privacy_Policy","Privacy_Policy");
//            consentInformation.setConsentStatus(ConsentStatus.UNKNOWN);
//            requestGoogleConsentForm(false);
        showPrivacyPolicy();
    }



    private void requestGoogleConsentForm(boolean isAppLaunch) {
        consentInformation.requestConsentInfoUpdate(new String[]{getString(R.string.publisher_id)}, new ConsentInfoUpdateListener() {
            @Override
            public void onConsentInfoUpdated(ConsentStatus consentStatus) {
                if (consentInformation.isRequestLocationInEeaOrUnknown()) {
                    // user is located in EEA, consent is required
                    if (consentStatus == ConsentStatus.UNKNOWN) {
                        showGoogleConsentForm();
                    }
                } else {
                    if (!isAppLaunch) {
                        if (!isAppInBackground)
                            showPrivacyPolicy();
                    }
                }
            }

            @Override
            public void onFailedToUpdateConsentInfo(String errorDescription) {
                // User's consent status failed to update
                Log.d("Error", "onFailedToUpdateConsentInfo: " + errorDescription);
            }
        });
    }

    private void showGoogleConsentForm() {
        // consent not provided, collect consent using Google-rendered consent form
        URL privacyUrl = null;
        try {
            privacyUrl = new URL(getString(R.string.privacy_policy_url));
        } catch (MalformedURLException e) {
            Log.e("Error", "onConsentInfoUpdated: " + e.getLocalizedMessage());
        }
        form = new ConsentForm.Builder(this, privacyUrl)
                .withPersonalizedAdsOption()
                .withNonPersonalizedAdsOption()
                .withListener(new ConsentFormListener() {
                    @Override
                    public void onConsentFormLoaded() {
                        // Consent form loaded successfully.
                        Log.d("consent form", "onConsentFormLoaded");
                        if (!isAppInBackground) {
                            form.show();
                        }
                    }

                    @Override
                    public void onConsentFormOpened() {
                        // Consent form was displayed.
                        Log.d("TAG", "onConsentFormOpened");
                    }

                    @Override
                    public void onConsentFormClosed(ConsentStatus consentStatus, Boolean userPrefersAdFree) {
                        // Consent form was closed.
                        Log.d("TAG", "onConsentFormClosed");
                        if (consentStatus == ConsentStatus.PERSONALIZED) {
                            SharedPreferenceHelper.getInstance().setBooleanValue(getString(R.string.npa), false);
                        } else if (consentStatus == ConsentStatus.NON_PERSONALIZED) {
                            SharedPreferenceHelper.getInstance().setBooleanValue(getString(R.string.npa), true);
                        }
                    }

                    @Override
                    public void onConsentFormError(String errorDescription) {
                        // Consent form error.
                        Log.d("TAG", "onConsentFormError: " + errorDescription);
                    }
                })
                .build();
        form.load();
    }

    private void showPrivacyPolicy() {
        if (URLUtil.isValidUrl(getString(R.string.privacy_policy_url))) {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.privacy_policy_url)));
            startActivity(i);
        }
    }


    private void showPrePermissionDialog() {
        final Dialog prePermissionDialog = new Dialog(this);     //,android.R.style.Theme_Translucent_NoTitleBar
        prePermissionDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        prePermissionDialog.setContentView(R.layout.pre_permission_dialog);
        Objects.requireNonNull(Objects.requireNonNull(prePermissionDialog.getWindow())).setBackgroundDrawableResource(android.R.color.transparent);

        prePermissionDialog.findViewById(R.id.deny_permissions).setOnClickListener(v -> {
            SharedPreferenceHelper.getInstance().setBooleanValue(AppConstant.IS_RECORDING_ENABLE,false);
            prePermissionDialog.dismiss();
        });

        prePermissionDialog.findViewById(R.id.allow_permissions).setOnClickListener(v -> {
            prePermissionDialog.dismiss();
            requestPermission();
        });
        prePermissionDialog.show();
    }


    private void requestPermission() {
        ActivityCompat.requestPermissions(this, PERMISSION, PERMISSION_CODE);
        Log.d("Permissions","requested");
    }

    private void askForSystemOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            //If the draw over permission is not available open the settings screen
            //to grant the permission.
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" +this.getPackageName()));
            startActivityForResult(intent, DRAW_OVER_OTHER_APP_PERMISSION);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode==DRAW_OVER_OTHER_APP_PERMISSION){
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(SettingsActivity.this)){
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    if (UtilClass.isForegroundPermissionAllowed(SettingsActivity.this)) {
                        SharedPreferenceHelper.getInstance().setBooleanValue(AppConstant.IS_OVERLAY_ENABLED,true);
                        showRecordModeSettings();
                    }else{
                        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.FOREGROUND_SERVICE}, DRAW_OVER_OTHER_APP_PERMISSION);
                    }
                }else {
                    SharedPreferenceHelper.getInstance().setBooleanValue(AppConstant.IS_OVERLAY_ENABLED,true);
                    showRecordModeSettings();
                }

            }
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode==DRAW_OVER_OTHER_APP_PERMISSION){
            if (grantResults.length > 0) {
                for (int    result:grantResults){
                    if (result != PackageManager.PERMISSION_GRANTED){
                        SharedPreferenceHelper.getInstance().setBooleanValue(AppConstant.IS_OVERLAY_ENABLED,false);
                    }else{
                        SharedPreferenceHelper.getInstance().setBooleanValue(AppConstant.IS_OVERLAY_ENABLED,true);
                    }
                    showRecordModeSettings();
                }
            }
        }
    }

    @Override
    protected void onDestroy() {
        MoPubAdsManager.getInstance().destroyAllAdsView();
        isAppInBackground=true;
        unbinder.unbind();
        super.onDestroy();
    }

    @Override
    protected void onPause() {
        MoPub.onPause(this);
        super.onPause();
    }

    @Override
    protected void onStop() {
        MoPub.onStop(this);
        super.onStop();
    }


    @SuppressLint("StaticFieldLeak")
    private class UpdateSelectedContactsText extends AsyncTask<Void, Void, Integer> {
        LocalDatabase appDataBase;
        AppCompatTextView   contactsToRecord;

        UpdateSelectedContactsText(AppCompatTextView   contactsToRecord) {
            this.contactsToRecord=contactsToRecord;
        }

        @Override
        protected Integer doInBackground(Void... voids) {
            appDataBase = LocalDatabase.getInstance(SettingsActivity.this);
            return appDataBase.contactSettingsDao().getCount();
        }

        @Override
        protected void onPostExecute(Integer    count) {
            super.onPostExecute(count);
            if (contactsToRecord!=null) contactsToRecord.setText(count+" Selected");

        }
    }
}
