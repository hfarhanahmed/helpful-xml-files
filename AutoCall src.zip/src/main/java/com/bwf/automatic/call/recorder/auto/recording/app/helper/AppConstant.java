package com.bwf.automatic.call.recorder.auto.recording.app.helper;

import android.content.Context;
import android.os.Environment;

import java.io.File;

/**
 * Created by RanaTalal on 9/26/2017.
 */

public class AppConstant {
//    public static final String IS_CONSENT_AGREED = "IS_CONSENT_AGREED";
    public static final String ACTION_TYPE = "action_type";
    public static final String CALL_ACTION = "android.intent.action.PHONE_STATE";
    public static final String OUT_GOING_CALL_ACTION = "android.intent.action.NEW_OUTGOING_CALL";
    public static final String IS_ADS_DISABLED = "IS_ADS_DISABLED";
    public static final String IS_RECORDING_ENABLE = "IS_RECORDING_ENABLE";
    public static final String IS_RECORDING_MODE_AUTOMATIC = "IS_RECORDING_MODE_AUTOMATIC";
    public static final String IS_OVERLAY_ENABLED = "IS_OVERLAY_ENABLED";
    public static final String IS_RECORD_CONTACTS = "IS_RECORD_CONTACTS";
    public static final int READ_PHONE_STATE_PERMISSION = 453;
    public static final int READ_CONTACTS_PERMISSION = 567;
    public static final int CONTACT_UPDATE_REQUEST_CODE = 234;
    public static String CALL_STATUS = "callStatus";
    public static Context CONTEXT = null;
    public static String RUN_FIRST_TIME = "runFirstTime";
    public static String FILE_PATH = Environment.getExternalStorageDirectory() + File.separator + "CallRecorder" + File.separator + "IncommingCallRecord" + File.separator;
    public static String OUTGOING_FILE_PATH = Environment.getExternalStorageDirectory() + File.separator + "CallRecorder" + File.separator + "outgoingCallRecord" + File.separator;
    public static String CALL_BUTTON_STATE = "callButtonState";
    public static String CALL_FILE_NAME = "callRecorderFile";
}
