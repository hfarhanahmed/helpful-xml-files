package com.bwf.automatic.call.recorder.auto.recording.app.dao;


import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import java.util.List;

import com.bwf.automatic.call.recorder.auto.recording.app.models.SaveRecordingModel;


@Dao
public interface SaveRecordingDAO {
    @Query("SELECT * FROM saverecordingmodel WHERE  contactName LIKE    '%' ||  :prefix ||  '%' OR  notes   LIKE    '%' ||  :prefix ||  '%' OR  noteSubject   LIKE    '%' ||  :prefix ||  '%'")
    List<SaveRecordingModel> getSearchedRecordings(String prefix);

    @Query("SELECT * FROM saverecordingmodel")
    List<SaveRecordingModel> getAllRecordings();

    @Query("SELECT * FROM saverecordingmodel WHERE  date > :date")
    List<SaveRecordingModel> getAllWhereRecordingsGreaterThan(long date);

    @Query("SELECT * FROM saverecordingmodel WHERE  incomingCall = :isIncoming  AND contactName LIKE    '%' ||  :prefix ||  '%' OR  notes   LIKE    '%' ||  :prefix ||  '%' OR  noteSubject   LIKE    '%' ||  :prefix ||  '%'")
    List<SaveRecordingModel> getSearchFilteredRecordings(boolean isIncoming, String prefix);

    @Query("SELECT * FROM saverecordingmodel WHERE  incomingCall = :isIncoming")
    List<SaveRecordingModel> getAllFilteredRecordings(boolean isIncoming);

    @Query("SELECT * FROM saverecordingmodel WHERE id = :id")
    SaveRecordingModel findById(long id);

    @Query("SELECT * FROM saverecordingmodel WHERE id = :id")
    SaveRecordingModel findByIdbg(int id);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(SaveRecordingModel... saveRecordingModels);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(SaveRecordingModel saveRecordingModel);

    @Update(onConflict = OnConflictStrategy.REPLACE)
    void update(SaveRecordingModel saveRecordingModel);

    @Delete
    void delete(SaveRecordingModel saveRecordingModel);

}
