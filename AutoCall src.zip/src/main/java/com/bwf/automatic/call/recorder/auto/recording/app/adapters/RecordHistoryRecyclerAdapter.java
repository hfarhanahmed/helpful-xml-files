package com.bwf.automatic.call.recorder.auto.recording.app.adapters;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v4.content.FileProvider;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import com.bwf.automatic.call.recorder.auto.recording.app.BuildConfig;
import com.bwf.automatic.call.recorder.auto.recording.app.R;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.AppConstant;
import com.bwf.automatic.call.recorder.auto.recording.app.models.HistoryModel;

/**
 * Created by RanaTalal on 9/28/2017.
 */

public class RecordHistoryRecyclerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    ArrayList<HistoryModel> arrayList;
    Context context;

    public RecordHistoryRecyclerAdapter(ArrayList<HistoryModel> arrayList, Context context) {
        this.arrayList = arrayList;
        this.context = context;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.history_viewholder, parent, false);
        HistoryViewHolder viewHolder = new HistoryViewHolder(view, arrayList, context);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        HistoryModel historyModel = arrayList.get(position);
        HistoryViewHolder viewHolder = (HistoryViewHolder) holder;


        viewHolder.durationTextView.setText(historyModel.getDuration());

        viewHolder.phoneNoTextView.setText(historyModel.getName());
        viewHolder.timeTextView.setText(historyModel.getTime());

        if (historyModel.getCallType().equals("incomming")) {
            viewHolder.callIcon.setImageResource(R.drawable.call_in);
        } else {
            viewHolder.callIcon.setImageResource(R.drawable.callout);
        }
    }

    private String convertMiliToTime(long millis) {

        String time = String.format("%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(millis),
                TimeUnit.MILLISECONDS.toMinutes(millis) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(millis)),
                TimeUnit.MILLISECONDS.toSeconds(millis) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millis)));
        return time;
    }


    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class HistoryViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ArrayList<HistoryModel> arrayList;
        Context context;
        TextView phoneNoTextView, timeTextView, durationTextView;
        ImageView callIcon;

        public HistoryViewHolder(View itemView, ArrayList<HistoryModel> arrayList, Context context) {
            super(itemView);
            this.arrayList = arrayList;
            this.context = context;
            phoneNoTextView = itemView.findViewById(R.id.phone_no);
            timeTextView = itemView.findViewById(R.id.call_time);
            durationTextView = itemView.findViewById(R.id.call_duration_time);

            callIcon = itemView.findViewById(R.id.call_icon);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            int position = getAdapterPosition();
            HistoryModel historyModel = arrayList.get(position);
            Intent intent = new Intent();
            intent.setAction(Intent.ACTION_VIEW);
            File file = new File(AppConstant.FILE_PATH + File.separator + historyModel.getFilePath());
            final Uri uri = FileProvider.getUriForFile(context, BuildConfig.APPLICATION_ID + ".files", file);
//            intent.setDataAndType(FileProvider.getUriForFile(activity, BuildConfig.APPLICATION_ID + ".myfileprovider", file));/*, "audio*//*");*/
            Log.d("fileUriPath",uri.getPath());
            intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.setDataAndType(uri, "audio/*");
            context.startActivity(intent);

        }
    }
}
