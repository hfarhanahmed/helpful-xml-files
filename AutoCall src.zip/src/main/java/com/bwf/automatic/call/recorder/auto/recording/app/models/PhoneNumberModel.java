package com.bwf.automatic.call.recorder.auto.recording.app.models;

import java.io.Serializable;

public class PhoneNumberModel implements Serializable {

    public final static int ID = 0;
    public final static int PHONE_NUMBER = 1;
    public final static int PHONE_TYPE = 2;
    public final static int PHONE_LABEL = 3;

    private int id;
    private String phoneNumber;
    private String phoneType;
    private String phoneLabel;

    public PhoneNumberModel() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getPhoneType() {
        return phoneType;
    }

    public void setPhoneType(String phoneType) {
        this.phoneType = phoneType;
    }

    public String getPhoneLabel() {
        return phoneLabel;
    }

    public void setPhoneLabel(String phoneLabel) {
        this.phoneLabel = phoneLabel;
    }

}