package com.bwf.automatic.call.recorder.auto.recording.app.models;

import java.io.Serializable;
import java.util.ArrayList;

public class ContactModel implements Serializable {

    public final static int ID = 0;
    public final static int LOOKUP_KEY = 1;
    public final static int DISPLAY_NAME = 2;
    public final static int PHOTO_THUMBNAIL_DATA = 3;
    public final static int RAW_CONTACT_ID_KEY = 4;

    private int Id;
    private int rawContactId;
    private String lookup;
    private String displayName;
    private String displayPhoto;
    private ArrayList<PhoneNumberModel> phoneNumberList;
    private boolean internationalised;

    public ContactModel() {
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public int getRawContactId() {
        return rawContactId;
    }

    public void setRawContactId(int rawContactId) {
        this.rawContactId = rawContactId;
    }

    public String getLookup() {
        return lookup;
    }

    public void setLookup(String lookup) {
        this.lookup = lookup;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayPhoto() {
        return displayPhoto;
    }

    public void setDisplayPhoto(String displayPhoto) {
        this.displayPhoto = displayPhoto;
    }

    public ArrayList<PhoneNumberModel> getPhoneNumberList() {
        return phoneNumberList;
    }

    public void setPhoneNumberList(ArrayList<PhoneNumberModel> phoneNumberList) {
        this.phoneNumberList = phoneNumberList;
    }

    public boolean isInternationalised() {
        return internationalised;
    }

    public void setInternationalised(boolean internationalised) {
        this.internationalised = internationalised;
    }


}