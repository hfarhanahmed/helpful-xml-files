package com.bwf.automatic.call.recorder.auto.recording.app.activities;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.LoaderManager;
import android.app.SearchManager;
import android.content.Context;
import android.content.CursorLoader;
import android.content.Intent;
import android.content.Loader;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bwf.automatic.call.recorder.auto.recording.app.managers.MoPubAdsManager;
import com.dhruvvaishnav.sectionindexrecyclerviewlib.IndicatorScrollRecyclerView;

import java.util.ArrayList;
import java.util.List;

import com.bwf.automatic.call.recorder.auto.recording.app.R;
import com.bwf.automatic.call.recorder.auto.recording.app.adapters.SelectContactsFromListAdapter;
import com.bwf.automatic.call.recorder.auto.recording.app.database.LocalDatabase;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.AppConstant;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.ContactsQuery;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.SharedPreferenceHelper;
import com.bwf.automatic.call.recorder.auto.recording.app.interfaces.ContactInteractionListener;
import com.bwf.automatic.call.recorder.auto.recording.app.managers.AnalyticsManager;
import com.bwf.automatic.call.recorder.auto.recording.app.models.ContactSettings;
import com.mopub.common.MoPub;
import com.mopub.mobileads.MoPubView;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;

public class ApplyBackgroudToSpecificsActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor>,ContactInteractionListener {

    private static final int REQUEST_CODE_SET_DEFAULT_DIALER = 311;
    private static final String TAG = ApplyBackgroudToSpecificsActivity.class.getSimpleName();
    private Unbinder unbinder;

    @BindView(R.id.contactsList)
    IndicatorScrollRecyclerView contactsList;

    @BindView(R.id.noContacts)
    ImageView noContacts;

    @BindView(R.id.toolbar)
    Toolbar toolbar;

    @BindView(R.id.no_contacts_selected)
    TextView noContactTextView;

    @BindView(R.id.set_background_to_specific)
    TextView setBackgroundToSpecific;

    @BindView(R.id.baner_ad_view_contacts)
    MoPubView bannerAdView;

//    @BindView(R.id.baner_Admob)
//    AdView nativeAdView;



    private Menu menu;
    private String searchQuery;
    private SelectContactsFromListAdapter contactsAdapter;
    private ArrayList<Integer> selectedContacts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apply_background_to_specifics);
        unbinder = ButterKnife.bind(this);
        // get permissions
        selectedContacts=new ArrayList<>();
        getPermissions();

        toolbar.setNavigationOnClickListener(v -> onBackPressed());
        setSupportActionBar(toolbar);

        ContactsToRecordActivity.showAd=true;

        AnalyticsManager.getInstance().sendAnalytics("Select_Contacts_Screen","Select_Contacts_Screen");
    }

    @Override
    protected void onResume() {
        MoPubAdsManager.getInstance().showMoPubBanner(this.getString(R.string.MoPubBanner),bannerAdView);
        MoPub.onResume(this);
        if (noContacts.getVisibility() == View.VISIBLE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
                    initContactsLoader();
                }
            } else {
                initContactsLoader();
            }
        }

//        if (Utils.isNetworkAvailable(this)){
//            AdsManager.getInstance().showBanner(nativeAdView,null);
//        }else{
//            nativeAdView.setVisibility(View.GONE);
//        }

        super.onResume();

    }


    @Override
    protected void onPause() {
        MoPubAdsManager.getInstance().destroyBannerView();
        MoPub.onPause(this);
        super.onPause();
    }

    @Override
    protected void onStop() {
        MoPub.onStop(this);
        super.onStop();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        this.menu = menu;
        getMenuInflater().inflate(R.menu.menu_apply_background_to_specific, menu);
        MenuItem searchMenuItem = menu.findItem(R.id.menu_search);

        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        final SearchView searchView = (SearchView) searchMenuItem.getActionView();

        searchMenuItem.setOnActionExpandListener(new MenuItem.OnActionExpandListener() {
            @Override
            public boolean onMenuItemActionExpand(MenuItem item) {
                ImageView searchIcon = searchView.findViewById(android.support.v7.appcompat.R.id.search_close_btn);
                searchIcon.setImageResource(R.drawable.ic_search_white_24dp);
                return true;
            }

            @Override
            public boolean onMenuItemActionCollapse(MenuItem item) {
                searchQuery = null;
                // restarts the loader, this triggers onCreateLoader(), which builds the necessary content Uri from searchQuery
                restartContactsLoader();
                return true;
            }
        });


        ImageView searchClose = searchView.findViewById(android.support.v7.appcompat.R.id.search_close_btn);
        searchClose.setImageResource(R.drawable.ic_cancel);

        // Assign searchable info to SearchView
        if (searchManager != null) {
            searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
        }

        if (searchView != null) {
            searchView.setQueryHint(getString(R.string.search1));
            searchView.setIconifiedByDefault(true);

            EditText searchEditText = searchView.findViewById(android.support.v7.appcompat.R.id.search_src_text);
            searchEditText.setTextColor(getResources().getColor(android.R.color.white));
            searchEditText.setHintTextColor(getResources().getColor(android.R.color.white));

            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    return true;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    // Called when the action bar search text has changed.  Updates
                    // the search filter, and restarts the loader to do a new query
                    // using the new search string.
                    String newFilter = !TextUtils.isEmpty(newText) ? newText : null;

                    // Don't do anything if the filter is empty
                    if (searchQuery == null && newFilter == null) {
                        return true;
                    }

                    // Don't do anything if the new filter is the same as the current filter
                    if (searchQuery != null && searchQuery.equals(newFilter)) {
                        return true;
                    }

                    // Updates current filter to new filter
                    searchQuery = newFilter;

                    // restarts the loader, this triggers onCreateLoader(), which builds the necessary content Uri from searchQuery
                    restartContactsLoader();
                    return true;
                }
            });
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        switch (item.getItemId()){
            case   android.R.id.home:
                onBackPressed();
                break;
        }
        return true;
    }

    @OnClick(R.id.set_background_to_specific)
    void    onSetToSpecificContacts(){
        getPhonePermissions();
    }



    private void getPhonePermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, AppConstant.READ_PHONE_STATE_PERMISSION);
            }
            else {
                new SaveSpecificContactBackgrounds().execute();
            }
        }
//        else {
//            initContactsLoader();
//        }
    }


    private void restartContactsLoader() {
        getLoaderManager().restartLoader(ContactsQuery.ContactQuery.QUERY_ID, null, this);
    }

    @Override
    protected void onDestroy() {
        MoPubAdsManager.getInstance().destroyBannerView();
        unbinder.unbind();
        super.onDestroy();
    }




    private void getPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE}, AppConstant.READ_CONTACTS_PERMISSION);
            } else {
                initContactsLoader();
            }
        } else {
            initContactsLoader();
        }
    }

    private void initContactsLoader() {
        getLoaderManager().initLoader(ContactsQuery.ContactQuery.QUERY_ID, null, this);
    }


    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle bundle) {

        // If this is the loader for finding contacts in the Contacts Provider
        // (the only one supported)
        if (id == ContactsQuery.ContactQuery.QUERY_ID) {
            Uri contentUri;

            // There are two types of searches, one which displays all contacts and
            // one which filters contacts by a search query. If mSearchTerm is set
            // then a search query has been entered and the latter should be used.
            if (searchQuery == null) {
                // Since there's no search string, use the content URI that searches the entire Contacts table
                contentUri = ContactsQuery.ContactQuery.CONTENT_URI;
            } else {
                // Since there's a search string, use the special content Uri that searches the
                // Contacts table. The URI consists of a base Uri and the search string.

                // for example if user searches for a then the special filter URI will be = content://com.android.contacts/contacts/filter/a
                contentUri = Uri.withAppendedPath(ContactsQuery.ContactQuery.FILTER_URI, Uri.encode(searchQuery));
            }
            // Returns a new CursorLoader for querying the Contacts table. No arguments are used
            // for the selection clause. The search string is either encoded onto the content URI,
            // or no contacts search string is used. The other search criteria are constants. See
            // the ContactsQuery interface.
            return new CursorLoader(this,
                    contentUri,
                    ContactsQuery.ContactQuery.PROJECTION,
                    ContactsQuery.ContactQuery.SELECTION,
                    null,
                    ContactsQuery.ContactQuery.SORT_ORDER);
        }

        Log.d(TAG, "onCreateLoader - incorrect ID provided (" + id + ")");
        return null;
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
        Log.d(TAG, "onLoadFinished - Loader ID provided: " + loader.getId());
        if (loader.getId() == ContactsQuery.ContactQuery.QUERY_ID) {
            if (cursor == null || cursor.getCount() == 0) {
                if (menu != null) {
                    MenuItem search = menu.findItem(R.id.menu_search);
                    if (search != null) {
                        search.setVisible(false);
                    }
                }
            }
            if (cursor != null) {
                Cursor cursor1 = cursor;
                initContactsAdapter(cursor);
                boolean isContactsCursorUpdated = true;
                if (cursor.getCount() == 0) {
                    noContacts.setVisibility(View.VISIBLE);
                    if (menu != null) {
                        MenuItem search = menu.findItem(R.id.menu_search);
                        if (search != null) {
                            search.setVisible(false);
                        }
                    }
                } else {
                    noContacts.setVisibility(View.GONE);
                    if (menu != null) {
                        MenuItem search = menu.findItem(R.id.menu_search);
                        if (search != null) {
                            search.setVisible(true);
                        }
                    }
                }
            }
        }
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        if (loader.getId() == ContactsQuery.ContactQuery.QUERY_ID) {
            // When the loader is being reset, clear the cursor from the adapter. This allows the
            // cursor resources to be freed.
            contactsAdapter.swapCursor(null);
        }
    }


    private void initContactsAdapter(Cursor cursor) {
        if (contactsAdapter == null) {
            contactsAdapter = new SelectContactsFromListAdapter(ApplyBackgroudToSpecificsActivity.this, this, cursor,selectedContacts);
            contactsList.setHasFixedSize(false);
            contactsList.setLayoutManager(new LinearLayoutManager(this));
            contactsList.setAdapter(contactsAdapter);
            new GetSelectedContacts().execute();
        } else {
            contactsAdapter.swapCursor(cursor);
        }
//        if (merge.getVisibility() == View.GONE) {
//            merge.setVisibility(View.VISIBLE);
//        }
    }

    @Override
    public void onContactSelected(Intent contactDetailActivity) {
        startActivityForResult(contactDetailActivity, AppConstant.CONTACT_UPDATE_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case AppConstant.CONTACT_UPDATE_REQUEST_CODE:
                if (resultCode == RESULT_OK) {
                    // restarts the loader, this triggers onCreateLoader(), which builds the necessary content Uri from searchQuery
                    restartContactsLoader();
                }
                break;
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults.length > 0) {
            switch (requestCode) {
                case AppConstant.READ_CONTACTS_PERMISSION:
                    if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                        initContactsLoader();
                    } else {
                        noContacts.setVisibility(View.VISIBLE);
                        if (menu != null) {
                            menu.findItem(R.id.menu_search).setVisible(false);
                        }
                    }

                    break;
                case AppConstant.READ_PHONE_STATE_PERMISSION:
                    if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                        new SaveSpecificContactBackgrounds().execute();
                    }else{
                        new SaveSpecificContactBackgrounds().execute();
                    }

                    break;
            }
        } else {
            noContacts.setVisibility(View.VISIBLE);
            if (menu != null) {
                menu.findItem(R.id.menu_search).setVisible(false);
            }
        }
    }

    public void addRemoveSelectedContact(int    contactId){
        if (selectedContacts.contains(contactId)){
            for (int    a=0;a<selectedContacts.size();a++){
                if (selectedContacts.get(a)==contactId){
                    selectedContacts.remove(a);
                }
            }
        }else{
            selectedContacts.add(contactId);
        }
        noContactTextView.setText(selectedContacts.size()+" Contacts Selected");
        contactsAdapter.notifyDataSetChanged();

        if (selectedContacts.size()==0){
            setBackgroundToSpecific.setBackgroundResource(R.drawable.set_button_unclickable_background);
            setBackgroundToSpecific.setClickable(false);
        }else{
            setBackgroundToSpecific.setBackgroundResource(R.drawable.button_background);
            setBackgroundToSpecific.setClickable(true);
        }
    }



    @SuppressLint("StaticFieldLeak")
    private class SaveSpecificContactBackgrounds extends AsyncTask<Void, Void, Void> {
        LocalDatabase appDataBase;
        SaveSpecificContactBackgrounds() {
        }

        @Override
        protected Void doInBackground(Void... voids) {
            appDataBase = LocalDatabase.getInstance(ApplyBackgroudToSpecificsActivity.this);
            appDataBase.contactSettingsDao().deleteAll();
            for (int    id:selectedContacts){
                ContactSettings contactSettings=new ContactSettings();
                contactSettings.setId(id);
                contactSettings.setBlocked(false);
                appDataBase.contactSettingsDao().insert(contactSettings);
                Log.d("Id saved", id +"");
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            SharedPreferenceHelper.getInstance().setBooleanValue(AppConstant.IS_RECORDING_MODE_AUTOMATIC,true);
            SharedPreferenceHelper.getInstance().setBooleanValue(AppConstant.IS_RECORD_CONTACTS,true);
            Toast.makeText(getApplicationContext(),"Contact Selected Successfully", Toast.LENGTH_LONG).show();
//            AnalyticsManager.getInstance(ApplyBackgroudToSpecificsActivity.this).sendAnalytics("Theme Applied to Contacts","Theme Applied to Contacts");
            ApplyBackgroudToSpecificsActivity.this.finish();
        }
    }

    @SuppressLint("StaticFieldLeak")
    private class GetSelectedContacts extends AsyncTask<Void, Void, Void> {
        LocalDatabase appDataBase;
        GetSelectedContacts() {
        }

        @Override
        protected Void doInBackground(Void... voids) {
            appDataBase = LocalDatabase.getInstance(ApplyBackgroudToSpecificsActivity.this);
            List<ContactSettings> contactSettings =   appDataBase.contactSettingsDao().getAllContactSettings();
            for (ContactSettings    settings:contactSettings){
                selectedContacts.add(settings.getId());
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            noContactTextView.setText(selectedContacts.size()+" Contacts Selected");
            if (selectedContacts.size()==0){
                setBackgroundToSpecific.setBackgroundResource(R.drawable.set_button_unclickable_background);
                setBackgroundToSpecific.setClickable(false);
            }else{
                setBackgroundToSpecific.setBackgroundResource(R.drawable.button_background);
                setBackgroundToSpecific.setClickable(true);
            }

            contactsAdapter.notifyDataSetChanged();
        }
    }

}
