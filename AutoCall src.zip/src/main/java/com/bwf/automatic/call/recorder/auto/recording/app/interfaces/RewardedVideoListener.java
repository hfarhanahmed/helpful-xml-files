package com.bwf.automatic.call.recorder.auto.recording.app.interfaces;

public interface RewardedVideoListener {

    void onRewardedVideoLoaded();

    void onRewardedVideoStarted();

    void onRewardedVideoCompleted();

    void onGotReward();

    void onRewardedVideoClosed();

}
