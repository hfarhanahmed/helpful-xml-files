package com.bwf.automatic.call.recorder.auto.recording.app.adapters;


import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.AppCompatCheckBox;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.dhruvvaishnav.sectionindexrecyclerviewlib.IndicatorScrollRecyclerView;
import com.bwf.automatic.call.recorder.auto.recording.app.R;
import com.bwf.automatic.call.recorder.auto.recording.app.activities.ApplyBackgroudToSpecificsActivity;
import com.bwf.automatic.call.recorder.auto.recording.app.activities.ContactsToRecordActivity;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.UtilClass;
import com.bwf.automatic.call.recorder.auto.recording.app.interfaces.ContactInteractionListener;
import com.bwf.automatic.call.recorder.auto.recording.app.models.ContactModel;

import java.util.ArrayList;
import java.util.Random;

public class SelectedContactsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Random random;
    private ContactsToRecordActivity activity;
    private final String TAG = SelectedContactsAdapter.class.getSimpleName();
    ArrayList<ContactModel> selectedContcats;

    public SelectedContactsAdapter(ContactsToRecordActivity activity, ArrayList<ContactModel> selectedContcats) {
        this.activity = activity;
        this.random = new Random();
        this.selectedContcats   =   selectedContcats;
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        ImageView flag;
        TextView initials;
        TextView displayName;
        ImageView displayPhoto;
        LinearLayout mainLayout;

        ViewHolder(View itemView) {
            super(itemView);
            initials = itemView.findViewById(R.id.initials);
            flag = itemView.findViewById(R.id.internationalized);
            displayName = itemView.findViewById(R.id.displayName);
            displayPhoto = itemView.findViewById(R.id.displayPhoto);
            mainLayout  =   itemView.findViewById(R.id.contact_item_list_main_layout);
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.selected_contact_item_list_layout, parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        final ViewHolder viewHolder = (ViewHolder) holder;

        ContactModel    contactModel=selectedContcats.get(position);

        // setting the data on the item
        int drawableId = -1;
        viewHolder.displayName.setText(contactModel.getDisplayName());
        drawableId = getBackgroundDrawableId((position%5)+1);
        if (drawableId != -1) {
            viewHolder.displayPhoto.setBackgroundResource(drawableId);
        }

        viewHolder.mainLayout.setBackgroundResource(R.color.white);
        viewHolder.displayName.setTextColor(ContextCompat.getColor(activity,R.color.black));

        if (contactModel.getDisplayName() != null && contactModel.getDisplayName().trim().length() > 0) {
            String initials = UtilClass.getInitials(contactModel.getDisplayName());
            viewHolder.initials.setText(initials);
            if (contactModel.getDisplayPhoto() != null) {
                try {
                    Glide.with(activity).load(contactModel.getDisplayPhoto()).apply(new RequestOptions().circleCrop()).listener(new RequestListener<Drawable>() {
                        @Override
                        public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                            return false;
                        }

                        @Override
                        public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                            viewHolder.initials.setText(null);
                            return false;
                        }
                    }).into(viewHolder.displayPhoto);
                } catch (Exception e) {
                    Log.e(TAG, "Error loading contact thumbnail image using Glide from path: " + contactModel.getDisplayPhoto() + " " + e.getLocalizedMessage());
                }
            }
        }

    }

    @Override
    public int getItemCount() {
        if (selectedContcats == null)
            return 0;
        else
            return selectedContcats.size();
    }

    @Override
    public void onViewRecycled(RecyclerView.ViewHolder holder) {
        ViewHolder viewHolder = (ViewHolder) holder;
        viewHolder.initials.setText(null);
        viewHolder.displayName.setText(null);
        viewHolder.flag.setImageDrawable(null);
        viewHolder.displayPhoto.setImageDrawable(null);
        super.onViewRecycled(holder);
    }

    private int getBackgroundDrawableId(int randomNumber) {
        int drawableId = -1;
        if (randomNumber == 1) {
            drawableId = R.drawable.display_photo_background1;
        } else if (randomNumber == 2) {
            drawableId = R.drawable.display_photo_background2;
        } else if (randomNumber == 3) {
            drawableId = R.drawable.display_photo_background3;
        } else if (randomNumber == 4) {
            drawableId = R.drawable.display_photo_background4;
        } else if (randomNumber == 5) {
            drawableId = R.drawable.display_photo_background5;
        }
        return drawableId;
    }

}
