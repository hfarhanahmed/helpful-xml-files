package com.bwf.automatic.call.recorder.auto.recording.app.database;

import android.arch.persistence.db.SupportSQLiteOpenHelper;
import android.arch.persistence.room.Database;
import android.arch.persistence.room.DatabaseConfiguration;
import android.arch.persistence.room.InvalidationTracker;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;
import android.support.annotation.NonNull;

import com.bwf.automatic.call.recorder.auto.recording.app.R;
import com.bwf.automatic.call.recorder.auto.recording.app.dao.ContactSettingsDao;
import com.bwf.automatic.call.recorder.auto.recording.app.dao.SaveRecordingDAO;
import com.bwf.automatic.call.recorder.auto.recording.app.models.ContactSettings;
import com.bwf.automatic.call.recorder.auto.recording.app.models.SaveRecordingModel;

@Database(entities = {SaveRecordingModel.class, ContactSettings.class}, version = 1, exportSchema = false)
public abstract class LocalDatabase extends RoomDatabase {

    public abstract SaveRecordingDAO saveRecordingDAO();
    public abstract ContactSettingsDao contactSettingsDao();

    public static LocalDatabase getInstance(Context context) {
        return Room.databaseBuilder(context, LocalDatabase.class, context.getString(R.string.database))
                    .fallbackToDestructiveMigration()
                    .build();
    }

    @NonNull
    @Override
    protected SupportSQLiteOpenHelper createOpenHelper(DatabaseConfiguration config) {
        return null;
    }

    @NonNull
    @Override
    protected InvalidationTracker createInvalidationTracker() {
        return null;
    }

    @Override
    public void clearAllTables() {

    }
}
