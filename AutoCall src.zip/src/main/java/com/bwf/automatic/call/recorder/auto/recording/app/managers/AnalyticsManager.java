package com.bwf.automatic.call.recorder.auto.recording.app.managers;

import android.os.Bundle;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.bwf.automatic.call.recorder.auto.recording.app.Application;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.AppConstant;

public class AnalyticsManager {

    private static AnalyticsManager manager;
    private FirebaseAnalytics firebaseAnalytics;

    private AnalyticsManager() {
        firebaseAnalytics = FirebaseAnalytics.getInstance(Application.context);
    }

    public static AnalyticsManager getInstance() {
        if (manager == null) {
            manager = new AnalyticsManager();
        }
        return manager;
    }

    public void sendAnalytics(String actionDetail, String actionName) {
        Bundle bundle = new Bundle();
        bundle.putString(AppConstant.ACTION_TYPE, "Mda_acr_" + actionName);
        bundle.putString(FirebaseAnalytics.Param.CONTENT, "Mda_acr_" + actionDetail);
        firebaseAnalytics.logEvent("Mda_acr_" + actionName, bundle);
    }
}
