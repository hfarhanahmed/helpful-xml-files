package com.bwf.automatic.call.recorder.auto.recording.app.adapters;


import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.AppCompatCheckBox;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.dhruvvaishnav.sectionindexrecyclerviewlib.IndicatorScrollRecyclerView;

import java.util.ArrayList;
import java.util.Random;

import com.bwf.automatic.call.recorder.auto.recording.app.R;
import com.bwf.automatic.call.recorder.auto.recording.app.activities.ApplyBackgroudToSpecificsActivity;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.UtilClass;
import com.bwf.automatic.call.recorder.auto.recording.app.interfaces.ContactInteractionListener;
import com.bwf.automatic.call.recorder.auto.recording.app.models.ContactModel;

public class SelectContactsFromListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> implements IndicatorScrollRecyclerView.SectionedAdapter {

    private Cursor cursor;
    private Random random;
    private ApplyBackgroudToSpecificsActivity activity;
    private ContactInteractionListener listener;
    private final String TAG = SelectContactsFromListAdapter.class.getSimpleName();
    ArrayList<Integer> selectedContcats;

    public SelectContactsFromListAdapter(ContactInteractionListener listener, ApplyBackgroudToSpecificsActivity activity, Cursor cursor, ArrayList<Integer> selectedContcats) {
        this.cursor = cursor;
        this.activity = activity;
        this.random = new Random();
        this.listener = listener;
        this.selectedContcats   =   selectedContcats;
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        ImageView flag;
        TextView initials;
        TextView displayName;
        ImageView displayPhoto;
        LinearLayout mainLayout;
        AppCompatCheckBox checkBox;

        ViewHolder(View itemView) {
            super(itemView);
            initials = itemView.findViewById(R.id.initials);
            flag = itemView.findViewById(R.id.internationalized);
            displayName = itemView.findViewById(R.id.displayName);
            displayPhoto = itemView.findViewById(R.id.displayPhoto);
            mainLayout  =   itemView.findViewById(R.id.contact_item_list_main_layout);
            checkBox    =   itemView.findViewById(R.id.contact_selected_checkBox);
        }
    }

    public void swapCursor(Cursor cursor) {
        this.cursor = cursor;
        if (this.cursor != null) {
            this.cursor.moveToPosition(-1);
        }
        notifyDataSetChanged();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.contact_item_list_layout, parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        final ViewHolder viewHolder = (ViewHolder) holder;
        // cursor has been moved to position
        cursor.moveToPosition(position);

        final ContactModel contactModel = new ContactModel();
        contactModel.setId(cursor.getInt(ContactModel.ID));
        contactModel.setLookup(cursor.getString(ContactModel.LOOKUP_KEY));
        contactModel.setDisplayName(cursor.getString(ContactModel.DISPLAY_NAME));
        contactModel.setDisplayPhoto(cursor.getString(ContactModel.PHOTO_THUMBNAIL_DATA));
        contactModel.setRawContactId(cursor.getInt(ContactModel.RAW_CONTACT_ID_KEY));

        // setting the data on the item
        int drawableId = -1;
        viewHolder.displayName.setText(contactModel.getDisplayName());

        Log.i("id : Raw id",contactModel.getId()+" : "+contactModel.getRawContactId());

        drawableId = getBackgroundDrawableId((position%5)+1);
        if (drawableId != -1) {
            viewHolder.displayPhoto.setBackgroundResource(drawableId);
        }

        viewHolder.mainLayout.setBackgroundResource(R.color.white);
        viewHolder.displayName.setTextColor(ContextCompat.getColor(activity,R.color.black));
        viewHolder.checkBox.setChecked(false);

        if (contactModel.getDisplayName() != null && contactModel.getDisplayName().trim().length() > 0) {
            String initials = UtilClass.getInitials(contactModel.getDisplayName());
            viewHolder.initials.setText(initials);
            if (selectedContcats.contains(contactModel.getId())){
                Glide.with(activity).load(R.drawable.ic_selected_contact).into(viewHolder.displayPhoto);
                viewHolder.initials.setVisibility(View.GONE);
                viewHolder.mainLayout.setBackgroundResource(R.color.colorPrimary);
//                viewHolder.mainLayout.setBackgroundColor(Color.parseColor("#e6e1de"));
                viewHolder.displayName.setTextColor(ContextCompat.getColor(activity,R.color.white));
                viewHolder.checkBox.setChecked(true);
            }else   if (contactModel.getDisplayPhoto() != null) {
                try {
                    Glide.with(activity).load(contactModel.getDisplayPhoto()).apply(new RequestOptions().circleCrop()).listener(new RequestListener<Drawable>() {
                        @Override
                        public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                            return false;
                        }

                        @Override
                        public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                            viewHolder.initials.setText(null);
                            return false;
                        }
                    }).into(viewHolder.displayPhoto);
                } catch (Exception e) {
                    Log.e(TAG, "Error loading contact thumbnail image using Glide from path: " + contactModel.getDisplayPhoto() + " " + e.getLocalizedMessage());
                }
            }
        }
        final int finalDrawableId = drawableId;
        viewHolder.itemView.setOnClickListener(v -> {
            // contact has been clicked, open the contact detail activity
            Log.d("item","clicked");
            activity.addRemoveSelectedContact(contactModel.getId());
        });


    }

    @Override
    public int getItemCount() {
        if (cursor == null)
            return 0;
        else
            return cursor.getCount();
    }

    @Override
    public void onViewRecycled(RecyclerView.ViewHolder holder) {
        ViewHolder viewHolder = (ViewHolder) holder;
        viewHolder.initials.setText(null);
        viewHolder.displayName.setText(null);
        viewHolder.flag.setImageDrawable(null);
        viewHolder.displayPhoto.setImageDrawable(null);
        super.onViewRecycled(holder);
    }

    private int getBackgroundDrawableId(int randomNumber) {
        int drawableId = -1;
        if (randomNumber == 1) {
            drawableId = R.drawable.display_photo_background1;
        } else if (randomNumber == 2) {
            drawableId = R.drawable.display_photo_background2;
        } else if (randomNumber == 3) {
            drawableId = R.drawable.display_photo_background3;
        } else if (randomNumber == 4) {
            drawableId = R.drawable.display_photo_background4;
        } else if (randomNumber == 5) {
            drawableId = R.drawable.display_photo_background5;
        }
        return drawableId;
    }

    @NonNull
    @Override
    public String getSectionName(int position) {
        if (cursor != null) {
            cursor.moveToPosition(position);
            String displayName = cursor.getString(ContactModel.DISPLAY_NAME);
            return String.valueOf(displayName.charAt(0)).toUpperCase();
        }
        return "";
    }
}
