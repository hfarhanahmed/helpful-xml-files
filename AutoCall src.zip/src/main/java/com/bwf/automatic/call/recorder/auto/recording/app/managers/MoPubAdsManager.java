package com.bwf.automatic.call.recorder.auto.recording.app.managers;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import com.bwf.automatic.call.recorder.auto.recording.app.Application;
import com.bwf.automatic.call.recorder.auto.recording.app.BuildConfig;
import com.bwf.automatic.call.recorder.auto.recording.app.R;
import com.mopub.common.privacy.ConsentDialogListener;
import com.mopub.common.privacy.PersonalInfoManager;
import com.mopub.mobileads.GooglePlayServicesBanner;
import com.mopub.mobileads.GooglePlayServicesInterstitial;
import com.mopub.mobileads.GooglePlayServicesRewardedVideo;
import com.mopub.mobileads.MoPubErrorCode;
import com.mopub.nativeads.AdapterHelper;
import com.mopub.nativeads.FacebookAdRenderer;
import com.mopub.nativeads.GooglePlayServicesAdRenderer;
import com.mopub.nativeads.GooglePlayServicesNative;
import com.mopub.nativeads.MediaViewBinder;
import com.mopub.nativeads.MoPubNative;
import com.mopub.nativeads.MoPubStaticNativeAdRenderer;
import com.mopub.nativeads.NativeAd;
import com.mopub.nativeads.NativeErrorCode;
import com.mopub.nativeads.ViewBinder;

import com.mopub.common.MoPub;
import com.mopub.common.SdkConfiguration;
import com.mopub.common.SdkInitializationListener;
import com.mopub.mobileads.MoPubInterstitial;
import com.mopub.mobileads.MoPubView;

import java.util.HashMap;
import java.util.Map;


public class MoPubAdsManager {

    private MoPubView moPubView;
    private MoPubNative moPubNative;
    private AdapterHelper adapterHelper;
    private NativeAd.MoPubNativeEventListener moPubNativeEventListener;
    private  MoPubInterstitial mInterstitial;

    private String TAG = MoPubAdsManager.class.getName();
    private static MoPubAdsManager manager;
    private boolean isEnableAds = true;

   /* private final String MoPubInterstital ="7db6a21d540a45b8b5eb4122ad53b50a";
    private final String MoPubBanner="af3fcb6081484441a0678d90c3fb972b";
    private final String MoPubNative="40c7fd67db7642628ff3e1b6cc61797c";
    private final String MoPub_CP_icon="0c92a6f163ff4949943b0049249b4359";
*/

    Context context = Application.getContext();

    // initialization function is call to initialize SDK - call it splash Activity or Application class
    public void initializtion()
    {
        if(!isNetworkAvailable(context) ||  !isEnableAds)
            return;

        Bundle extras = new Bundle();
        if(MoPub.canCollectPersonalInformation()) {
            extras.putString("npa", "1");
            Log.d(TAG, "ConsentData is Personalized");
        }
        else {
            extras.putString("npa", "0");
            Log.d(TAG, "ConsentData is nonPersonalized");
        }

        SdkConfiguration sdkConfiguration = new SdkConfiguration.Builder(context.getString(R.string.MoPubInterstital))
                .withMediationSettings(new GooglePlayServicesBanner.GooglePlayServicesMediationSettings(extras),
                        new GooglePlayServicesInterstitial.GooglePlayServicesMediationSettings(extras),
                        new GooglePlayServicesRewardedVideo.GooglePlayServicesMediationSettings(extras),
                        new GooglePlayServicesNative.GooglePlayServicesMediationSettings(extras))
                .build();

        MoPub.initializeSdk(context, sdkConfiguration, initSdkListener());
    }


    public static MoPubAdsManager getInstance() {
        if (manager == null) {
            manager = new MoPubAdsManager();
        }
        return manager;
    }

    // if use only banner or Banner+interstitial in activity then use this fuction.
    public void destroyBannerView() {
        if (moPubView != null) {
            moPubView.destroy();
            moPubView = null;
        }
    }

    // if use only Native or Native+interstitial in activity then use this fuction.
    public void destroyNativeView() {
        if( moPubNative != null) {
            moPubNative.destroy();
            moPubNative = null;
            moPubNativeEventListener = null;
        }
    }


    // destroyAdsView function is call to destroy Ads Views - call it in onDestroy fuctiion of each Activity
    public void destroyAllAdsView()
    {
        if (moPubView != null) {
            moPubView.destroy();
            moPubView = null;
        }

        if(mInterstitial!= null) {
            mInterstitial.destroy();
            mInterstitial = null;
        }

        if( moPubNative != null) {
            moPubNative.destroy();
            moPubNative = null;
            moPubNativeEventListener = null;
        }
    }

    private SdkInitializationListener initSdkListener() {
        return new SdkInitializationListener() {
            @Override
            public void onInitializationFinished() {
           /* MoPub SDK initialized.
            Check if you should show the consent dialog here, and make your ad requests. */
                // yourAppsShowInterstitialMethod();
            }
        };
    }

    private boolean isInitialized()
    {
        return MoPub.isSdkInitialized() && isNetworkAvailable(context) &&  isEnableAds;
    }

    public void showConsentForm()
    {
        if(!isNetworkAvailable(context) ||  !isEnableAds)
            return;

        SdkConfiguration sdkConfiguration = new SdkConfiguration.Builder(context.getString(R.string.MoPubInterstital))
                .build();

        MoPub.initializeSdk(context, sdkConfiguration, initSdkListener());

        final PersonalInfoManager mPersonalInfoManager = MoPub.getPersonalInformationManager();
        if(BuildConfig.DEBUG)
            mPersonalInfoManager.forceGdprApplies();

        mPersonalInfoManager.shouldShowConsentDialog();
        if (mPersonalInfoManager.shouldShowConsentDialog()) {
            mPersonalInfoManager.loadConsentDialog(new ConsentDialogListener() {
                @Override
                public void onConsentDialogLoaded() {
                    if (mPersonalInfoManager != null) {
                        mPersonalInfoManager.showConsentDialog();
                    }
                }

                @Override
                public void onConsentDialogLoadFailed(@NonNull MoPubErrorCode moPubErrorCode) {

                }
            });
        }

        //ConsentData consentData = mPersonalInfoManager.getConsentData();

        // Call this to let MoPub know the user has granted consent
        // mPersonalInfoManager.grantConsent();

        // Call this to let MoPub know the user has revoked consent.
        //mPersonalInfoManager.revokeConsent();

        // MoPub.canCollectPersonalInformation();//
        //Log.e(TAG, "ConsentData is "+MoPub.canCollectPersonalInformation());
    }


    public boolean isNetworkAvailable(Context mContext) {
        ConnectivityManager connectivityManager = (ConnectivityManager) mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager != null) {
            NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
            return activeNetworkInfo != null && activeNetworkInfo.isConnected();
        }
        return false;
    }

    public void showMoPubBanner(String AdUnit_id_banner, final View moPubView1)
    {
        moPubView = (MoPubView)moPubView1;
        if (!isInitialized())
            return;
        moPubView.setAdUnitId(AdUnit_id_banner);
        moPubView.setLocalExtras(localExtraMap());
        moPubView.loadAd();
        moPubView.setBannerAdListener(new MoPubView.BannerAdListener() {
            @Override
            public void onBannerLoaded(MoPubView banner) {
                if(moPubView==null)
                    return;
                Log.e(TAG, "onBannerLoaded");
                moPubView.setVisibility(View.VISIBLE);
            }

            @Override
            public void onBannerFailed(MoPubView banner, MoPubErrorCode errorCode) {
                Log.e(TAG, "onBannerFailed");

                switch(errorCode)
                {
                    case NO_FILL:
                        // ("No inventory.")
                        Log.e(TAG, "NO_FILL");
                        break;
                    case SERVER_ERROR:
                        //("Unable to connect to MoPub adserver.")
                        Log.e(TAG, "SERVER_ERROR");
                        break;
                    case ADAPTER_NOT_FOUND:
                        //("Unable to find Native Network or Custom Event adapter.")
                        break;
                    case ADAPTER_CONFIGURATION_ERROR:
                        //("Native Network or Custom Event adapter was configured incorrectly."),
                        break;
                    case NETWORK_TIMEOUT:
                        //("Third-party network failed to respond in a timely manner."),
                        Log.e(TAG, "NETWORK_TIMEOUT");
                        break;
                    case NETWORK_INVALID_STATE:
                        //("Third-party network failed due to invalid internal state."),
                        break;
                    case MRAID_LOAD_ERROR:
                        //("Error loading MRAID ad."),
                        break;
                    case CANCELLED:
                        //("Ad request was cancelled.")
                        break;
                    case UNSPECIFIED:
                        //("Unspecified error.")
                        break;
                }

            }

            @Override
            public void onBannerClicked(MoPubView banner) {
                Log.e(TAG, "onBannerClicked");
            }

            @Override
            public void onBannerExpanded(MoPubView banner) {
                Log.e(TAG, "onBannerExpanded");

            }

            @Override
            public void onBannerCollapsed(MoPubView banner) {
                Log.e(TAG, "onBannerCollapsed");

            }
        });
    }


    private Map localExtraMap()
    {
        Map<String, Object> localExtras = new HashMap<>();
        localExtras.put("testDevices", "E7E82682FFA421C225677D81754D5894");
        //localExtras.put("testDevices", "F7791C457D40D3516832A6E00C8EFF3C");
        //localExtras.put("ad_choices_placement", NativeAdOptions.ADCHOICES_TOP_LEFT);
        return localExtras;
    }

    public void loadMoPubInterstital(final String AdUnit_id, final Activity activity)
    {

        if (!isInitialized())
            return;

        if(mInterstitial!= null) {
            mInterstitial.destroy();
            mInterstitial = null;
        }

        mInterstitial = new MoPubInterstitial(activity,AdUnit_id);

        mInterstitial.setLocalExtras(localExtraMap());

        mInterstitial.load();

        mInterstitial.setInterstitialAdListener(new MoPubInterstitial.InterstitialAdListener() {
            @Override
            public void onInterstitialLoaded(MoPubInterstitial interstitial) {
                Log.e(TAG, "onInterstitialLoaded");
            }

            @Override
            public void onInterstitialFailed(MoPubInterstitial interstitial, MoPubErrorCode errorCode) {

                Log.e(TAG, "onInterstitialFailed");

                switch(errorCode)
                {
                    case NO_FILL:
                        // ("No inventory.")
                        Log.e(TAG, "NO_FILL");
                        break;
                    case SERVER_ERROR:
                        //("Unable to connect to MoPub adserver.")
                        Log.e(TAG, "SERVER_ERROR");
                        break;
                    case ADAPTER_NOT_FOUND:
                        //("Unable to find Native Network or Custom Event adapter.")
                        break;
                    case ADAPTER_CONFIGURATION_ERROR:
                        //("Native Network or Custom Event adapter was configured incorrectly."),
                        break;
                    case NETWORK_TIMEOUT:
                        //("Third-party network failed to respond in a timely manner."),
                        Log.e(TAG, "NETWORK_TIMEOUT");
                        break;
                    case NETWORK_INVALID_STATE:
                        //("Third-party network failed due to invalid internal state."),
                        break;
                    case MRAID_LOAD_ERROR:
                        //("Error loading MRAID ad."),
                        break;
                    case CANCELLED:
                        //("Ad request was cancelled.")
                        break;
                    case UNSPECIFIED:
                        //("Unspecified error.")
                        break;
                }

            }

            @Override
            public void onInterstitialShown(MoPubInterstitial interstitial) {
                Log.e(TAG, "onInterstitialShown");

            }

            @Override
            public void onInterstitialClicked(MoPubInterstitial interstitial) {
                Log.e(TAG, "onInterstitialClicked");
            }

            @Override
            public void onInterstitialDismissed(MoPubInterstitial interstitial) {
                Log.e(TAG, "onInterstitialDismissed");
                loadMoPubInterstital(AdUnit_id,  activity);
            }
        });

    }


    private void waitnShowMoPubInterstital()
    {

        if (!isInitialized())
            return;

        if(mInterstitial == null) {
            return;
        }

        mInterstitial.setInterstitialAdListener(new MoPubInterstitial.InterstitialAdListener() {
            @Override
            public void onInterstitialLoaded(MoPubInterstitial interstitial) {
                Log.e(TAG, "onInterstitialLoaded");
                mInterstitial.show();
            }

            @Override
            public void onInterstitialFailed(MoPubInterstitial interstitial, MoPubErrorCode errorCode) {

                Log.e(TAG, "onInterstitialFailed");

                switch(errorCode)
                {
                    case NO_FILL:
                        // ("No inventory.")
                        Log.e(TAG, "NO_FILL");
                        break;
                    case SERVER_ERROR:
                        //("Unable to connect to MoPub adserver.")
                        Log.e(TAG, "SERVER_ERROR");
                        break;
                    case ADAPTER_NOT_FOUND:
                        //("Unable to find Native Network or Custom Event adapter.")
                        break;
                    case ADAPTER_CONFIGURATION_ERROR:
                        //("Native Network or Custom Event adapter was configured incorrectly."),
                        break;
                    case NETWORK_TIMEOUT:
                        //("Third-party network failed to respond in a timely manner."),
                        Log.e(TAG, "NETWORK_TIMEOUT");
                        break;
                    case NETWORK_INVALID_STATE:
                        //("Third-party network failed due to invalid internal state."),
                        break;
                    case MRAID_LOAD_ERROR:
                        //("Error loading MRAID ad."),
                        break;
                    case CANCELLED:
                        //("Ad request was cancelled.")
                        break;
                    case UNSPECIFIED:
                        //("Unspecified error.")
                        break;
                }

            }

            @Override
            public void onInterstitialShown(MoPubInterstitial interstitial) {
                Log.e(TAG, "onInterstitialShown");

            }

            @Override
            public void onInterstitialClicked(MoPubInterstitial interstitial) {
                Log.e(TAG, "onInterstitialClicked");
            }

            @Override
            public void onInterstitialDismissed(MoPubInterstitial interstitial) {
                Log.e(TAG, "onInterstitialDismissed");
            }
        });

    }


    // Defined by your application, indicating that you're ready to show an interstitial ad.
    public void showMoPubInterstitial() {

        if (!isInitialized())
            return;

        if(mInterstitial == null)
            return;

        if (mInterstitial.isReady()) {
            mInterstitial.show();
        } else {
            // Caching is likely already in progress if `isReady()` is false.
            // Avoid calling `load()` here and instead rely on the callbacks as suggested below.
            Log.e(TAG, "Interstitial waiting");
            waitnShowMoPubInterstital();

        }
    }


    public void loadNativeAds(final FrameLayout parentView, final String AdUnit_id)
    {
        if (!isInitialized())
            return;

        final RelativeLayout nativeAdView = new RelativeLayout(context);
        adapterHelper = new AdapterHelper(context, 0, 3); // When standalone, any range will be fine.

        moPubNativeEventListener = new NativeAd.MoPubNativeEventListener() {

            @Override
            public void onImpression(View view) {
                Log.d(TAG, "onImpression");
                // Impress is recorded - do what is needed AFTER the ad is visibly shown here.
            }

            @Override
            public void onClick(View view) {
                Log.d(TAG, "onClick");
                // Click tracking.
            }
        };

        MoPubNative.MoPubNativeNetworkListener moPubNativeNetworkListener = new MoPubNative.MoPubNativeNetworkListener() {

            @Override
            public void onNativeLoad(final NativeAd nativeAd) {
                Log.d(TAG, "onNativeLoad");

                // Retrieve the pre-built ad view that AdapterHelper prepared for us.

                View v = adapterHelper.getAdView(null, nativeAdView, nativeAd, new ViewBinder.Builder(0).build());

                // Set the native event listeners (onImpression, and onClick).
                nativeAd.setMoPubNativeEventListener(moPubNativeEventListener);

                v.setLayoutParams(new ActionBar.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

                // Add the ad view to our view hierarchy, defined in the XML (activity_main.xml).
                parentView.addView(v);

            }


            @Override
            public void onNativeFail(NativeErrorCode errorCode) {
                Log.d(TAG, "onNativeFail: " + errorCode.toString());

                switch(errorCode)
                {
                    case NETWORK_TIMEOUT:
                        //("Third-party network failed to respond in a timely manner."),
                        Log.e(TAG, "NETWORK_TIMEOUT");
                        break;
                    case NETWORK_INVALID_STATE:
                        //("Third-party network failed due to invalid internal state."),
                        break;
                    case UNSPECIFIED:
                        //("Unspecified error.")
                        break;
                }

            }
        };

        moPubNative = new MoPubNative(context, AdUnit_id, moPubNativeNetworkListener);
        moPubNative.setLocalExtras(localExtraMap());

        MoPubStaticNativeAdRenderer moPubStaticNativeAdRenderer = new MoPubStaticNativeAdRenderer(
                new ViewBinder.Builder(R.layout.ad_app_install)
                        .titleId(R.id.native_title)
                        .textId(R.id.native_text)
                        .mainImageId(R.id.native_main_image)
                        .iconImageId(R.id.native_icon_image)
                        .callToActionId(R.id.native_cta)
                        .privacyInformationIconImageId(R.id.native_privacy_information_icon_image)
                        .build()
        );

        // AdMob
     /*  final GooglePlayServicesAdRenderer googlePlayServicesAdRenderer = new GooglePlayServicesAdRenderer(
               new MediaViewBinder.Builder(R.layout.ad_app_install_admob)
                       .mediaLayoutId(R.id.appinstall_media) // bind to your `com.mopub.nativeads.MediaLayout` element
                       .iconImageId(R.id.appinstall_app_icon)
                       .titleId(R.id.appinstall_headline)
                       .textId(R.id.appinstall_body)
                       .callToActionId(R.id.appinstall_call_to_action)
                       .privacyInformationIconImageId(R.id.native_privacy_information_icon_image)
                       .addExtra("key_star_rating",
                               R.id.appinstall_stars)
                       .build());*/


        final GooglePlayServicesAdRenderer googlePlayServicesAdRenderer = new GooglePlayServicesAdRenderer(
                new MediaViewBinder.Builder(R.layout.ad_app_install_admob)
                        .titleId(R.id.native_title)
                        .textId(R.id.native_text)
                        .mediaLayoutId(R.id.native_main_image)
                        .iconImageId(R.id.native_icon_image)
                        .callToActionId(R.id.native_cta)
                        // .addExtra("key_star_rating",R.id.appinstall_stars)
                        .privacyInformationIconImageId(R.id.native_privacy_information_icon_image)
                        .build());

        FacebookAdRenderer facebookAdRenderer = new FacebookAdRenderer(
                new FacebookAdRenderer.FacebookViewBinder.Builder(R.layout.ad_app_install_facebook)
                        .titleId(R.id.native_title)
                        .textId(R.id.native_text)
                        // Binding to new layouts from Facebook 4.99.0+
                        .mediaViewId(R.id.native_main_image)
                        .adIconViewId(R.id.native_icon_image)
                        .adChoicesRelativeLayoutId(R.id.native_privacy_information_icon_image)
                        .advertiserNameId(R.id.native_title) // Bind either the titleId or advertiserNameId depending on the FB SDK version
                        // End of binding to new layouts
                        .callToActionId(R.id.native_cta)
                        .build());


        moPubNative.registerAdRenderer(moPubStaticNativeAdRenderer);
        moPubNative.registerAdRenderer(googlePlayServicesAdRenderer);
        moPubNative.registerAdRenderer(facebookAdRenderer);

        // Send out the ad request.
        moPubNative.makeRequest();
    }


    public void load_CP_ICON_Ads(final FrameLayout parentView, final String AdUnit_id)
    {
        if (!isInitialized())
            return;

        final RelativeLayout nativeAdView = new RelativeLayout(context);
        adapterHelper = new AdapterHelper(context, 0, 3); // When standalone, any range will be fine.

        moPubNativeEventListener = new NativeAd.MoPubNativeEventListener() {

            @Override
            public void onImpression(View view) {
                Log.d(TAG, "onImpression");
                // Impress is recorded - do what is needed AFTER the ad is visibly shown here.
            }

            @Override
            public void onClick(View view) {
                Log.d(TAG, "onClick");
                // Click tracking.
            }
        };

        MoPubNative.MoPubNativeNetworkListener moPubNativeNetworkListener = new MoPubNative.MoPubNativeNetworkListener() {

            @Override
            public void onNativeLoad(final NativeAd nativeAd) {
                Log.d(TAG, "onNativeLoad");

                View v = adapterHelper.getAdView(null, nativeAdView, nativeAd, new ViewBinder.Builder(0).build());

                // Set the native event listeners (onImpression, and onClick).
                nativeAd.setMoPubNativeEventListener(moPubNativeEventListener);

                v.setLayoutParams(new ActionBar.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

                // Add the ad view to our view hierarchy, defined in the XML (activity_main.xml).
                parentView.addView(v);
            }


            @Override
            public void onNativeFail(NativeErrorCode errorCode) {
                Log.d(TAG, "onNativeFail: " + errorCode.toString());
            }
        };

        moPubNative = new MoPubNative(context, AdUnit_id, moPubNativeNetworkListener);

        MoPubStaticNativeAdRenderer moPubStaticNativeAdRenderer = new MoPubStaticNativeAdRenderer(
                new ViewBinder.Builder(R.layout.ad_cp_icon)
                        .iconImageId(R.id.native_icon_image)
                        .build()
        );

        moPubNative.registerAdRenderer(moPubStaticNativeAdRenderer);
        // Send out the ad request.
        moPubNative.makeRequest();
    }


    public void load_CP_REC_Ads(final FrameLayout parentView, final String AdUnit_id)
    {
        if (!isInitialized())
            return;

        final RelativeLayout nativeAdView = new RelativeLayout(context);
        adapterHelper = new AdapterHelper(context, 0, 3); // When standalone, any range will be fine.

        moPubNativeEventListener = new NativeAd.MoPubNativeEventListener() {

            @Override
            public void onImpression(View view) {
                Log.d(TAG, "onImpression");
                // Impress is recorded - do what is needed AFTER the ad is visibly shown here.
            }

            @Override
            public void onClick(View view) {
                Log.d(TAG, "onClick");
                // Click tracking.
            }
        };

        MoPubNative.MoPubNativeNetworkListener moPubNativeNetworkListener = new MoPubNative.MoPubNativeNetworkListener() {

            @Override
            public void onNativeLoad(final NativeAd nativeAd) {
                Log.d(TAG, "onNativeLoad");

                View v = adapterHelper.getAdView(null, nativeAdView, nativeAd, new ViewBinder.Builder(0).build());

                // Set the native event listeners (onImpression, and onClick).
                nativeAd.setMoPubNativeEventListener(moPubNativeEventListener);

                v.setLayoutParams(new ActionBar.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

                // Add the ad view to our view hierarchy, defined in the XML (activity_main.xml).
                parentView.addView(v);
            }


            @Override
            public void onNativeFail(NativeErrorCode errorCode) {
                Log.d(TAG, "onNativeFail: " + errorCode.toString());
            }
        };

        moPubNative = new MoPubNative(context, AdUnit_id, moPubNativeNetworkListener);

        MoPubStaticNativeAdRenderer moPubStaticNativeAdRenderer = new MoPubStaticNativeAdRenderer(
                new ViewBinder.Builder(R.layout.ad_app_install )
                        .titleId(R.id.native_title)
                        .textId(R.id.native_text)
                        .mainImageId(R.id.native_main_image)
                        .iconImageId(R.id.native_icon_image)
                        .callToActionId(R.id.native_cta)
                        .privacyInformationIconImageId(R.id.native_privacy_information_icon_image)
                        .build()
        );

        moPubNative.registerAdRenderer(moPubStaticNativeAdRenderer);
        // Send out the ad request.
        moPubNative.makeRequest();
    }
}
