package com.bwf.automatic.call.recorder.auto.recording.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.IBinder;
import android.provider.ContactsContract;
import android.support.annotation.RequiresApi;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.AppCompatTextView;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;

import com.bwf.automatic.call.recorder.auto.recording.app.activities.MainActivity;
import com.bwf.automatic.call.recorder.auto.recording.app.database.LocalDatabase;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.AppConstant;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.SharedPreferenceHelper;
import com.bwf.automatic.call.recorder.auto.recording.app.models.SaveRecordingModel;
import com.bwf.automatic.call.recorder.auto.recording.app.receivers.PhoneStateReceiver;

import static android.support.v4.app.NotificationCompat.PRIORITY_MIN;
import static android.support.v4.app.NotificationCompat.VISIBILITY_PUBLIC;

public class FloatingIconService extends Service {

    private WindowManager mWindowManager = null;
    private View mOverlayView = null;
    protected int mWidth  = 0;
    private ImageView counterFab = null;
    private ImageView mButtonClose = null;
    private AppCompatTextView   recordingText   =   null;

    private static boolean isRecording=false;
    String CHANNEL_ID = "my_channel_01";
    String saveNo;
    String stringDate;
    Date date;


    int overlayState=-1;

    private static MediaRecorder mediaRecorder;

    public FloatingIconService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public void onCreate() {
        super.onCreate();
        overlayState=-1;
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            NotificationChannel chan1 = new NotificationChannel("channel_02", "Temp_cannal", NotificationManager.IMPORTANCE_LOW);
//            chan1.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
//            Notification.Builder notification = new Notification.Builder(AppConstant.CONTEXT, CHANNEL_ID);
//            startForeground(2,notification.build());
//        } else {
//            startForeground(2, new Notification());
//        }
        String channelId = "";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            channelId  =  createNotificationChannel("my_service", "My Background Service");
        }

        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this, channelId );
        Notification notification = notificationBuilder.setOngoing(true)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setPriority(PRIORITY_MIN)
                .setCategory(Notification.CATEGORY_SERVICE)
                .build();
        startForeground(101, notification);
        setTheme(R.style.AppTheme);
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private String createNotificationChannel(String channelId,String channelName){
        NotificationChannel chan = new  NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_NONE);
        chan.setLightColor(Color.BLUE);
        chan.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
        NotificationManager service = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        service.createNotificationChannel(chan);
        return channelId;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);
        if (intent!=null){
            overlayState=intent.getIntExtra("overlayState",0);
            if (intent.getIntExtra("state",0)==TelephonyManager.CALL_STATE_IDLE){
                Log.d("service","stop");
                if (isRecording){
                    stopRecordCall();
                    stopSelf();
                }else {
                    stopSelf();
                }
            }else{
                Log.d("service","start");
                saveNo=intent.getStringExtra("saveNo");
                stringDate=intent.getStringExtra("stringDate");
                date=new Date(intent.getLongExtra("date",0));
                isRecording=false;
                if (mOverlayView == null) {
                    mOverlayView = LayoutInflater.from(this).inflate(R.layout.overlay_layout, null);

                    int LAYOUT_FLAG;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        try {
                            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
                        }catch (Exception   e){
                            e.printStackTrace();
                            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_PHONE;
                        }
                    } else {
                        LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_PHONE;
                    }

                    final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                            WindowManager.LayoutParams.WRAP_CONTENT,
                            WindowManager.LayoutParams.WRAP_CONTENT,
                            LAYOUT_FLAG,
                            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                            PixelFormat.TRANSLUCENT);


                    //Specify the view position
                    params.gravity = Gravity.TOP | Gravity.START;      //Initially view will be added to top-left corner
                    params.x = 0;
                    params.y = 100;

                    mWindowManager = (WindowManager)    getSystemService(WINDOW_SERVICE);

                    if (Build.VERSION.SDK_INT >= 19) {
                        // Call some material design APIs here
                        mWindowManager.addView(mOverlayView, params);
                    } else {
                        // Implement this feature without material design
                        mWindowManager.addView(mOverlayView, params);
                    }


                    Display display = mWindowManager.getDefaultDisplay();
                    final Point size = new Point();
                    display.getSize(size);

                    counterFab =(ImageView) mOverlayView.findViewById(R.id.fabHead);
                    mButtonClose = (ImageView)  mOverlayView.findViewById(R.id.closeButton);
                    recordingText   =   mOverlayView.findViewById(R.id.recording_text);


                    final RelativeLayout layout = (RelativeLayout)   mOverlayView.findViewById(R.id.layout);
                    ViewTreeObserver vto = layout.getViewTreeObserver();
                    vto.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                        @Override
                        public void onGlobalLayout() {
                            layout.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                            int width = layout.getMeasuredWidth();

                            //To get the accurate middle of the screen we subtract the width of the floating widget.
                            mWidth = size.x - width;
                        }
                    });

         /*   with(mButtonClose!!){
                setOnClickListener(object : View.OnClickListener {
                    override fun onClick(v: View) {
                        stopSelf()
                    }
                })
            }*/

                    mButtonClose.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (isRecording){
                                stopRecordCall();
                            }
                            stopSelf();
                        }
                    });

                    if (counterFab!=null) {
                        counterFab.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
//                        startActivity(Intent(baseContext,CallRecordingsActivity.class));
                            }
                        });
                        counterFab.setOnTouchListener(new View.OnTouchListener() {
                            private int initialX = 0;
                            private int initialY = 0;
                            private float initialTouchX = 0.0f;
                            private float initialTouchY = 0.0f;
                            @Override
                            public boolean onTouch(View v, MotionEvent event) {

                                switch (event.getAction()) {
                                    case    MotionEvent.ACTION_DOWN :

                                        //remember the initial position.
                                        initialX = params.x;
                                        initialY = params.y;


                                        //get the touch location
                                        initialTouchX = event.getRawX();
                                        initialTouchY = event.getRawY();

                                        return true;
                                    case    MotionEvent.ACTION_UP :

                                        //Only start the activity if the application is in background. Pass the current badge_count to the activity

                                        float xDiff = event.getRawX() - initialTouchX;
                                        float yDiff = event.getRawY() - initialTouchY;

                                        if (Math.abs(xDiff) < 5 && Math.abs(yDiff) < 5) {
                                            if (!isRecording){
                                                stringDate = String.valueOf(Calendar.getInstance().getTimeInMillis());
                                                recordingText.setText("Recording");
                                                startRecordCall();
                                                counterFab.setColorFilter(ContextCompat.getColor(AppConstant.CONTEXT, R.color.white), android.graphics.PorterDuff.Mode.MULTIPLY);
                                                counterFab.setBackgroundResource(R.drawable.floating_button_background_recording);
                                                isRecording=true;
                                            }else{
                                                stopRecordCall();
                                                isRecording=false;
                                                recordingText.setText("Record");
                                                counterFab.setColorFilter(ContextCompat.getColor(AppConstant.CONTEXT, R.color.black), android.graphics.PorterDuff.Mode.MULTIPLY);
                                                counterFab.setBackgroundResource(R.drawable.floating_button_background);
                                            }
//                                    Intent intent = new Intent(getBaseContext(), MainActivity.class);
//                                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                                    startActivity(intent);

                                            //close the service and remove the fab view
                                        }
                                        //    stopSelf()


                                        //Logic to auto-position the widget based on where it is positioned currently w.r.t middle of the screen.
                                        float middle = mWidth / 2;
                                        float nearestXWall = params.x >= middle? mWidth : 0;
                                        params.x = (int) nearestXWall;


                                        mWindowManager.updateViewLayout(mOverlayView, params);

                                        return true;
                                    case   MotionEvent.ACTION_MOVE :
                                        float xDiff2 = Math.round(event.getRawX() - initialTouchX);
                                        float yDiff2 = Math.round(event.getRawY() - initialTouchY);


                                        //Calculate the X and Y coordinates of the view.
                                        params.x = (int) (initialX + xDiff2);
                                        params.y = (int) (initialY + yDiff2);

                                        //Update the layout with new X & Y coordinates
                                        mWindowManager.updateViewLayout(mOverlayView, params);

                                        return true;
                                }
                                return false;
                            }
                        });

                        if (overlayState==0){
                            Log.d("<<Received>>","0");
                            recordingText.setText("Record");
                            counterFab.setColorFilter(ContextCompat.getColor(AppConstant.CONTEXT, R.color.black), android.graphics.PorterDuff.Mode.MULTIPLY);
                            counterFab.setBackgroundResource(R.drawable.floating_button_background);
                        }else   if (overlayState==1){
                            Log.d("<<Received>>","1");
                            recordingText.setText("Recording");
                            startRecordCall();
                            counterFab.setColorFilter(ContextCompat.getColor(AppConstant.CONTEXT, R.color.white), android.graphics.PorterDuff.Mode.MULTIPLY);
                            counterFab.setBackgroundResource(R.drawable.floating_button_background_recording);
                        }
                    }
                }
            }
        }
        return START_STICKY;
    }


    private void stopRecordCall() {
        try{
            if (mediaRecorder != null   &&  isRecording) {
                mediaRecorder.stop();
                mediaRecorder.reset();
                mediaRecorder.release();
                mediaRecorder = null;
                createRecordingNotification(AppConstant.CONTEXT, "Recorded", 001, "idle");
                isRecording=false;
            }else {
                Log.d("Media Recorder","null");
            }
        }catch (Exception   e){
            e.printStackTrace();
        }

        SharedPreferenceHelper.getInstance().setBooleanValue(AppConstant.CALL_STATUS, false);
    }


    private void startRecordCall() {
        if (mediaRecorder==null){
            mediaRecorderReady();
        }
        if (mediaRecorder != null) {
            if (!isRecording) {
                try{
                    Log.d("<<recorder>>","Service on start");
                    isRecording = true;
                    mediaRecorder.start();
                    createRecordingNotification(AppConstant.CONTEXT, "Recording", 001, "OffHook");
                }catch (Exception   e){
                    e.printStackTrace();
                }
            }
        }else{
            Log.d("recorder","null on start");
        }
    }

    private void mediaRecorderReady() {
        File file = new File(AppConstant.FILE_PATH);
        if (!file.exists()) {
            Log.d("callreceiver", "file not exist: " + "audio " + " file " + file);
            file.mkdirs();
        }
        mediaRecorder = new MediaRecorder();
        String manufacturer = Build.MANUFACTURER;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP	&&	!manufacturer.toLowerCase().contains("htc")	&&	!manufacturer.toLowerCase().contains("mi")	&&	!manufacturer.toLowerCase().contains("samsung")) {
            mediaRecorder.setAudioSource(MediaRecorder.AudioSource.VOICE_CALL);
//            Toast.makeText(AppConstant.CONTEXT, "Open speaker then call Record ", Toast.LENGTH_SHORT).show();
        } else {
            mediaRecorder.setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION);
        }
        mediaRecorder.setAudioSamplingRate(8000);
        mediaRecorder.setAudioEncodingBitRate(12200);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
        mediaRecorder.setOutputFile(file + File.separator + audioFileName() + ".amr");

        new SaveRecordingToDB(new SaveRecordingModel(audioFileName(),"",AppConstant.FILE_PATH+File.separator+audioFileName()+".amr",SharedPreferenceHelper.getInstance().getBooleanValue(AppConstant.CALL_STATUS, false),"",date.getTime(),saveNo,saveNo!=null?getContactName(saveNo,AppConstant.CONTEXT):"Unknown","",false)).execute();

        Log.d("callreceiver", "startRecordCall: " + "audio " + " file " + file + File.separator + audioFileName() + ".3gp");
        try {
            mediaRecorder.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String audioFileName() {
        String state;
        if (SharedPreferenceHelper.getInstance().getBooleanValue(AppConstant.CALL_STATUS, false)) {
            state = "incoming";
        } else {
            state = "outgoing";
        }
        String fileName = state + "," + stringDate/*+"_"+stringTime*/ + "_in_" + saveNo;
        return fileName;
    }

    private void createRecordingNotification(Context context, String message, int id, String notificationType) {
        Intent intent = new Intent(context, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, 0);


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel chan1 = new NotificationChannel(CHANNEL_ID, "NOTIFICATION_CHANNEL_NAME", NotificationManager.IMPORTANCE_DEFAULT);
            chan1.setLightColor(Color.GREEN);
            chan1.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            assert manager != null;
            manager.createNotificationChannel(chan1);

            Notification.Builder notification = new Notification.Builder(context, CHANNEL_ID)
                    .setContentTitle(saveNo)
                    .setContentText(message)
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setAutoCancel(false)
                    .setOngoing(true);

            if (notificationType.equals("idle")) {
                manager.cancel(001);
                notification.setOngoing(false);
                notification.setContentIntent(pendingIntent);
            }

            manager.notify(id, notification.build());
        } else {
            NotificationCompat.Builder builder = new NotificationCompat.Builder(context)
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setContentTitle(saveNo)
                    .setContentText(message)
                    .setDefaults(Notification.DEFAULT_ALL)
                    .setAutoCancel(false)
                    .setOngoing(true)
                    .setVisibility(VISIBILITY_PUBLIC);
            NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (notificationType.equals("idle")) {
                manager.cancel(001);
                builder.setOngoing(false);
                builder.setContentIntent(pendingIntent);
            }
            assert manager != null;
            manager.notify(id, builder.build());
        }

    }


    @SuppressLint("StaticFieldLeak")
    private class SaveRecordingToDB extends AsyncTask<Void, Void, Void> {
        SaveRecordingModel saveRecordingModel;
        long id;

        SaveRecordingToDB(SaveRecordingModel saveRecordingModel) {
            this.saveRecordingModel=saveRecordingModel;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            LocalDatabase appDataBase = LocalDatabase.getInstance(AppConstant.CONTEXT);
            appDataBase.saveRecordingDAO().insert(saveRecordingModel);
            Log.d("saved","database");
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }
    }



    public String getContactName(final String phoneNumber, Context   activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (activity.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                return "";
            }
        }

        int len = phoneNumber.length();
        Uri uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(phoneNumber.length() > 9 ? phoneNumber.substring(len - 9) : phoneNumber));

        String[] projection = new String[]{ContactsContract.Contacts._ID, ContactsContract.Contacts.DISPLAY_NAME_PRIMARY, ContactsContract.Contacts.PHOTO_THUMBNAIL_URI};

        String selection = null;
        if (phoneNumber.length() > 9)
            selection = ContactsContract.PhoneLookup.NUMBER + " LIKE %" + phoneNumber.substring(len - 9) + "%";
        else
            selection = ContactsContract.PhoneLookup.NUMBER + " LIKE %" + phoneNumber + "%";

        String contactName = "", imageUrl = "";
        int id = 0;
        Cursor cursor = activity.getContentResolver().query(uri, projection, selection, null, null);

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                id = cursor.getInt(0);
                contactName = cursor.getString(1);
                return contactName;

            }
            cursor.close();
        }
        return  "Unknown";
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mOverlayView != null)
            mWindowManager.removeView(mOverlayView);
    }
}
