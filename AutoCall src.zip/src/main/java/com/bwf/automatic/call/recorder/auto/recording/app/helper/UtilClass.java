package com.bwf.automatic.call.recorder.auto.recording.app.helper;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.support.v4.content.ContextCompat;
import android.util.Log;

import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;

/**
 * Created by RanaTalal on 9/27/2017.
 */

public class UtilClass {
    public static UtilClass utilClass;
    public static String[] PERMISSION = {Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CONTACTS}; //, Manifest.permission.CAPTURE_AUDIO_OUTPUT

    public static UtilClass getInstaance() {
        if (utilClass == null) {
            utilClass = new UtilClass();
        }
        return utilClass;
    }


    public static boolean isNetworkAvailable(Context context) {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = null;
        if (connectivityManager != null) {
            activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
            return activeNetworkInfo != null && activeNetworkInfo.isConnected();
        }
        return false;
    }

    public static String getInitials(String text) {
        String[] parts;
        String initials = null;
        StringBuilder stringBuilder;
        if (text != null) {
            stringBuilder = new StringBuilder();
            if (!text.contains(" ")) {
                stringBuilder.append(text.substring(0, 1));
            } else {
                parts = text.split(" ");
                for (String part : parts) {
                    if (part.length() > 0) {
                        stringBuilder.append(part.charAt(0));
                    }
                }
            }
            initials = stringBuilder.toString().toUpperCase();
        }
        return initials;
    }

    public static void shareApp(Context context) {
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT,
                "Check out the best call recording app: https://play.google.com/store/apps/details?id="+context.getPackageName());
        sendIntent.setType("text/plain");
        context.startActivity(sendIntent);
    }

    public void shareText(Context context, String text) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.putExtra(Intent.EXTRA_TEXT, text);
        intent.setType("text/plain");
        context.startActivity(Intent.createChooser(intent, "share"));
    }

    public void likeUs(Context context) {
        String url = "";
        try {
            //Check whether Google Play store is installed or not:
            context.getPackageManager().getPackageInfo("com.android.vending", 0);
            url = "market://details?id=" + context.getPackageName();
        } catch (final Exception e) {
            url = "https://play.google.com/store/apps/details?id=" + context.getPackageName();
        }

        //Open the app page in Google Play store:
        final Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
        context.startActivity(intent);
    }

    public void moreApps(Context context) {
        try {
            context.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://developer?id=Local+App+Store")));
        } catch (ActivityNotFoundException anfe) {
            context.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/developer?id=Local+App+Store")));
        }
    }

    public  static boolean isAllowPermission(Context    context) {
        boolean permissionResult=true;
        for (String permission : PERMISSION) {
            if (ContextCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED){
                permissionResult    = false;
                Log.d("permission failed",permission);
            }
        }
        return permissionResult;
    }

    public  static boolean isForegroundPermissionAllowed(Context    context) {
        boolean permissionResult=true;
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.FOREGROUND_SERVICE) != PackageManager.PERMISSION_GRANTED){
                permissionResult    = false;
                Log.d("permission failed","FOREGROUND_SERVICE");
            }

        return permissionResult;
    }

//    public  static void showConsentDialog(Context   context) {
//        final Dialog consentDialog = new Dialog(context);     //,android.R.style.Theme_Translucent_NoTitleBar
//        consentDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
//        consentDialog.setContentView(R.layout.consent_dialog);
//        Objects.requireNonNull(Objects.requireNonNull(consentDialog.getWindow())).setBackgroundDrawableResource(android.R.color.transparent);
//
//        consentDialog.findViewById(R.id.cancel_consent).setOnClickListener(v -> {
//            consentDialog.dismiss();
//        });
//
//        consentDialog.findViewById(R.id.agree_consent).setOnClickListener(v -> {
//            consentDialog.dismiss();
////            SharedPreferenceHelper.getInstance().setBooleanValue(AppConstant.IS_CONSENT_AGREED,true);
//        });
//
//        consentDialog.show();
//    }


    public static void onRateUs(Context context) {
//        AnalyticsManager.getInstance().sendAnalytics("rate_us_clicked_done", "Rate_us");
//        SharedPrefHelper.writeBoolean(context, "rate", true);
        try {
            context.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id="+context.getPackageName())));
        } catch (ActivityNotFoundException anfe) {
            context.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/developer?id="+context.getPackageName())));
        }
    }

}
