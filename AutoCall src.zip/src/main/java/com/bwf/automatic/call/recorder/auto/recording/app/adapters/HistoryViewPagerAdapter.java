package com.bwf.automatic.call.recorder.auto.recording.app.adapters;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import java.util.ArrayList;

import com.bwf.automatic.call.recorder.auto.recording.app.fragment.ShowFragment;

/**
 * Created by RanaTalal on 10/2/2017.
 */

public class HistoryViewPagerAdapter extends FragmentStatePagerAdapter {
    ArrayList<ShowFragment> arrayList;
    Context context;
    String[] title = {"All","incoming","outgoing"};

    public HistoryViewPagerAdapter(FragmentManager fm, ArrayList<ShowFragment> arrayList, Context context) {
        super(fm);
        this.arrayList = arrayList;
        this.context = context;
    }

    @Override
    public Fragment getItem(int position) {

        Bundle bundle = new Bundle();
        bundle.putString("title",title[position]);
        bundle.putInt("index",position);
        arrayList.get(position).setArguments(bundle);
        return arrayList.get(position);
    }

    @Override
    public int getCount() {
        return arrayList.size();
    }

    @Override
    public CharSequence getPageTitle(int position) {

        return title[position];
    }
}
