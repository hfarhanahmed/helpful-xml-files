package com.bwf.automatic.call.recorder.auto.recording.app.models;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

import java.util.Date;

@Entity
public class SaveRecordingModel {

    @PrimaryKey(autoGenerate = true)
    private long    id;

    private String name;
    private String time;
    private String duration;
    private String filePath;
    private boolean incomingCall;
    private String notes;
    private String noteSubject;


    //File Naming convension details
    private long date;
    private String saveNo;
    private String contactName;
    private boolean isSaved;

    public SaveRecordingModel(String name, String time, String filePath, boolean incomingCall, String notes, long date, String saveNo, String   contactName, String noteSubject, boolean isSaved) {
        this.name = name;
        this.time = time;
        this.filePath = filePath;
        this.incomingCall = incomingCall;
        this.notes = notes;
        this.date = date;
        this.saveNo = saveNo;
        this.contactName=contactName;
        this.noteSubject    =   noteSubject;
        this.isSaved    =   isSaved;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public boolean isIncomingCall() {
        return incomingCall;
    }

    public void setIncomingCall(boolean incomingCall) {
        this.incomingCall = incomingCall;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }

    public String getSaveNo() {
        return saveNo;
    }

    public void setSaveNo(String saveNo) {
        this.saveNo = saveNo;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getNoteSubject() {
        return noteSubject;
    }

    public void setNoteSubject(String noteSubject) {
        this.noteSubject = noteSubject;
    }

    public boolean isSaved() {
        return isSaved;
    }

    public void setSaved(boolean saved) {
        isSaved = saved;
    }
}
