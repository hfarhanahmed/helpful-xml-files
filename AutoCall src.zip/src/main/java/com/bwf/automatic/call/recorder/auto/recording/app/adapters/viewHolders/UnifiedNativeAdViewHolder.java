package com.bwf.automatic.call.recorder.auto.recording.app.adapters.viewHolders;


import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.bwf.automatic.call.recorder.auto.recording.app.R;

public class UnifiedNativeAdViewHolder extends RecyclerView.ViewHolder {

    public UnifiedNativeAdView adView;

    public UnifiedNativeAdView getAdView() {
        return adView;
    }

    public UnifiedNativeAdViewHolder(View view) {
        super(view);
        adView = (UnifiedNativeAdView) view.findViewById(R.id.ad_unified_layout);

    }
}
