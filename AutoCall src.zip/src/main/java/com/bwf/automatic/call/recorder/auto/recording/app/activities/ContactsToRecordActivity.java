package com.bwf.automatic.call.recorder.auto.recording.app.activities;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.bwf.automatic.call.recorder.auto.recording.app.managers.MoPubAdsManager;
import com.dhruvvaishnav.sectionindexrecyclerviewlib.IndicatorScrollRecyclerView;
import com.bwf.automatic.call.recorder.auto.recording.app.R;
import com.bwf.automatic.call.recorder.auto.recording.app.adapters.SelectedContactsAdapter;
import com.bwf.automatic.call.recorder.auto.recording.app.database.LocalDatabase;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.AppConstant;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.ContactsQuery;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.SharedPreferenceHelper;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.UtilClass;
import com.bwf.automatic.call.recorder.auto.recording.app.managers.AnalyticsManager;
import com.bwf.automatic.call.recorder.auto.recording.app.models.ContactModel;
import com.bwf.automatic.call.recorder.auto.recording.app.models.ContactSettings;
import com.mopub.common.MoPub;
import com.mopub.mobileads.MoPubView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

public class ContactsToRecordActivity extends AppCompatActivity{

    private static final String TAG = ApplyBackgroudToSpecificsActivity.class.getSimpleName();
    private Unbinder unbinder;
    public static boolean   showAd=true;

    @BindView(R.id.contactsList)
    IndicatorScrollRecyclerView contactsList;

    @BindView(R.id.noContacts)
    ImageView noContacts;

    @BindView(R.id.toolbar)
    Toolbar toolbar;

    @BindView(R.id.no_contacts_selected)
    TextView noContactTextView;

    @BindView(R.id.baner_ad_view_contacts)
    MoPubView   bannerAdView;

    private SelectedContactsAdapter contactsAdapter;
    private ArrayList<ContactModel> selectedContacts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacts_to_record);

        unbinder = ButterKnife.bind(this);
        // get permissions
        selectedContacts=new ArrayList<>();

        initContactsAdapter();

        toolbar.setNavigationOnClickListener(v -> onBackPressed());
        setSupportActionBar(toolbar);
        AnalyticsManager.getInstance().sendAnalytics("Selected_Contacts_Screen","Selected_Contacts_Screen");
        showAd=true;

    }

    @Override
    protected void onResume() {

        MoPubAdsManager.getInstance().showMoPubBanner(this.getString(R.string.MoPubBanner),bannerAdView);
        MoPub.onResume(this);

        if (showAd){
            showAd=false;
            if (UtilClass.isNetworkAvailable(this)   &&  !SharedPreferenceHelper.getInstance().getBooleanValue(AppConstant.IS_ADS_DISABLED,false)){
                MoPubAdsManager.getInstance().loadMoPubInterstital(this.getString(R.string.MoPubInterstital),this);
                MoPubAdsManager.getInstance().showMoPubInterstitial();
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
        }
        new GetSelectedContacts().execute();

        super.onResume();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_contacts_to_record, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        switch (item.getItemId()){
            case   android.R.id.home:
                onBackPressed();
                break;
            case   R.id.action_add_contacts:
                startActivity(new Intent(this,ApplyBackgroudToSpecificsActivity.class));
                break;
        }
        return true;
    }

    @Override
    protected void onDestroy() {
        unbinder.unbind();
        MoPubAdsManager.getInstance().destroyAllAdsView();
        super.onDestroy();
    }



    private void initContactsAdapter() {
        if (contactsAdapter == null) {
            contactsAdapter = new SelectedContactsAdapter(this, selectedContacts);
            contactsList.setHasFixedSize(false);
            contactsList.setLayoutManager(new LinearLayoutManager(this));
            contactsList.setAdapter(contactsAdapter);
        }
    }

    @SuppressLint("StaticFieldLeak")
    private class GetSelectedContacts extends AsyncTask<Void, Void, Void> {
        LocalDatabase appDataBase;
        GetSelectedContacts() {
        }

        @Override
        protected Void doInBackground(Void... voids) {
            appDataBase = LocalDatabase.getInstance(ContactsToRecordActivity.this);
            List<ContactSettings> contactSettings =   appDataBase.contactSettingsDao().getAllContactSettings();
            selectedContacts.clear();
            for (ContactSettings    settings:contactSettings){
                selectedContacts.add(getContact(String.valueOf(settings.getId())));
            }
            return null;
        }

        @SuppressLint("SetTextI18n")
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

            noContactTextView.setText(selectedContacts.size()+" Contacts Selected");

            if (contactsAdapter!=null)  contactsAdapter.notifyDataSetChanged();
        }
    }


    public ContactModel getContact(final String id) {

        Uri uri = ContactsQuery.ContactQuery.CONTENT_URI;

        String[] projection = new String[]{ContactsContract.Contacts._ID, ContactsContract.Contacts.LOOKUP_KEY, ContactsContract.Contacts.DISPLAY_NAME_PRIMARY, ContactsContract.Contacts.PHOTO_THUMBNAIL_URI};

        String selection =ContactsContract.Contacts._ID +" =? ";

        ContactModel    contactModel    =   new ContactModel();
        String contactName = "", imageUrl = "";
        Cursor cursor = getContentResolver().query(uri, projection, selection, new String[]{id}, null);

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                contactName = cursor.getString(2);
                imageUrl = cursor.getString(3);
                contactModel.setDisplayName(contactName);
                contactModel.setDisplayPhoto(imageUrl);
                contactModel.setId(cursor.getInt(0));
                Log.d("name",contactName);
            }else {
                Log.d("cursor","move to first fail");
            }
            cursor.close();
        }else{
            Log.d("cursor","null");
        }

        return contactModel;
    }


    @Override
    protected void onPause() {
        MoPub.onPause(this);
        MoPubAdsManager.getInstance().destroyBannerView();
        super.onPause();
    }

    @Override
    protected void onStop() {
        MoPub.onStop(this);
        super.onStop();
    }

}
