package com.bwf.automatic.call.recorder.auto.recording.app;

import android.app.Service;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.support.annotation.Nullable;

import com.bwf.automatic.call.recorder.auto.recording.app.helper.AppConstant;
import com.bwf.automatic.call.recorder.auto.recording.app.receivers.PhoneStateReceiver;

/**
 * Created by RanaTalal on 9/26/2017.
 */

public class RegisterCallService extends Service {
    PhoneStateReceiver callReceiver;
    IntentFilter intentFilter,outgoingIntentFilter;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        callReceiver = new PhoneStateReceiver();
        intentFilter = new IntentFilter();
        intentFilter.addAction(AppConstant.CALL_ACTION);
        intentFilter.addAction(AppConstant.OUT_GOING_CALL_ACTION);
        registerReceiver(callReceiver, intentFilter);
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        unregisterReceiver(callReceiver);
    }

    /*  TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Service.TELEPHONY_SERVICE);
        telephonyManager.listen(new PhoneStateListener() {
            @Override
            public void onCallStateChanged(int state, String incomingNumber) {
                super.onCallStateChanged(state, incomingNumber);


                checkCallState(context, state);


            }

        }, PhoneStateListener.LISTEN_CALL_STATE);*/
}
