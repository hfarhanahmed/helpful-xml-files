package com.bwf.automatic.call.recorder.auto.recording.app.activities;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.ContactsContract;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.SeekBar;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.bwf.automatic.call.recorder.auto.recording.app.managers.MoPubAdsManager;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

import com.bwf.automatic.call.recorder.auto.recording.app.R;
import com.bwf.automatic.call.recorder.auto.recording.app.database.LocalDatabase;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.AppConstant;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.SharedPreferenceHelper;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.UtilClass;
import com.bwf.automatic.call.recorder.auto.recording.app.managers.AnalyticsManager;
import com.bwf.automatic.call.recorder.auto.recording.app.models.GoogleDriveManager;
import com.bwf.automatic.call.recorder.auto.recording.app.models.SaveRecordingModel;
import com.mopub.common.MoPub;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;

import static com.bwf.automatic.call.recorder.auto.recording.app.models.GoogleDriveManager.RC_SIGN_IN;
import static com.bwf.automatic.call.recorder.auto.recording.app.models.GoogleDriveManager.REQUEST_CODE_RESOLUTION;

public class RecordingDetailsActivity extends AppCompatActivity implements MediaPlayer.OnCompletionListener, MediaPlayer.OnPreparedListener {

    Unbinder unbinder;
    SaveRecordingModel saveRecordingModel;
    GoogleDriveManager googleDriveManager;
    MediaPlayer mediaPlayer;
    boolean isPaused = false;

    @BindView(R.id.play_recording)
    AppCompatImageView pausePlayMusic;

    @BindView(R.id.media_seekbar)
    SeekBar seekBar;

    @BindView(R.id.contact_name)
    AppCompatTextView contactName;

    @BindView(R.id.contact_number)
    AppCompatTextView contactNumber;

    @BindView(R.id.call_time)
    AppCompatTextView callTime;

    @BindView(R.id.call_date)
    AppCompatTextView callDate;

    @BindView(R.id.current_duration)
    AppCompatTextView currentDuration;

    @BindView(R.id.total_duration)
    AppCompatTextView totalDuration;


    @BindView(R.id.contact_image)
    AppCompatImageView contactImage;


    @BindView(R.id.native_ad_layout)
    FrameLayout nativeAdView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recording_details);
        unbinder = ButterKnife.bind(this);

        MainActivity.showAd = true;

        new GetRecordingFromDB(getIntent().getLongExtra("id", 0)).execute();

        googleDriveManager = new GoogleDriveManager(this);
        mediaPlayer = new MediaPlayer();
        seekBar.getProgressDrawable().setColorFilter(new PorterDuffColorFilter(Color.parseColor("#a9160f"), PorterDuff.Mode.MULTIPLY));
        seekBar.getThumb().setColorFilter(Color.parseColor("#a9160f"), PorterDuff.Mode.SRC_IN);

        AnalyticsManager.getInstance().sendAnalytics("Details_Screen", "Details_Screen");

        if (UtilClass.isNetworkAvailable(this) && !SharedPreferenceHelper.getInstance().getBooleanValue(AppConstant.IS_ADS_DISABLED, false)) {
            MoPubAdsManager.getInstance().loadNativeAds(nativeAdView,this.getString(R.string.MoPubNative));
        } else {
            nativeAdView.setVisibility(View.GONE);
        }
    }

    @Override
    protected void onResume() {
        MoPub.onResume(this);
        googleDriveManager.onResume();
        super.onResume();
    }


    public void setContactNameAndImage(final String phoneNumber) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
        }

        int len = phoneNumber.length();
        Uri uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(phoneNumber.length() > 9 ? phoneNumber.substring(len - 9) : phoneNumber));

        String[] projection = new String[]{ContactsContract.Contacts._ID, ContactsContract.Contacts.DISPLAY_NAME_PRIMARY, ContactsContract.Contacts.PHOTO_THUMBNAIL_URI};

        String selection = null;
        if (phoneNumber.length() > 9)
            selection = ContactsContract.PhoneLookup.NUMBER + " LIKE %" + phoneNumber.substring(len - 9) + "%";
        else
            selection = ContactsContract.PhoneLookup.NUMBER + " LIKE %" + phoneNumber + "%";

        String contactName = "", imageUrl = "";
        int id = 0;
        Cursor cursor = getContentResolver().query(uri, projection, selection, null, null);

        if (cursor != null  &&  this.contactName!=null) {
            if (cursor.moveToFirst()) {
                id = cursor.getInt(0);
                contactName = cursor.getString(1);
                imageUrl = cursor.getString(2);

                if (imageUrl != null)
                    Glide.with(this).load(imageUrl).apply(RequestOptions.circleCropTransform()).into(contactImage);
                this.contactName.setText(contactName);
            } else {
                this.contactName.setText("Unknown");
            }
            cursor.close();
        }
    }

    private int getBackgroundDrawableId(int randomNumber) {
        int drawableId = -1;
        if (randomNumber == 1) {
            drawableId = R.drawable.display_photo_background1;
        } else if (randomNumber == 2) {
            drawableId = R.drawable.display_photo_background2;
        } else if (randomNumber == 3) {
            drawableId = R.drawable.display_photo_background3;
        } else if (randomNumber == 4) {
            drawableId = R.drawable.display_photo_background4;
        } else if (randomNumber == 5) {
            drawableId = R.drawable.display_photo_background5;
        }
        return drawableId;
    }

    @Override
    protected void onPause() {
        MoPub.onPause(this);
        googleDriveManager.onPause();
        super.onPause();
    }

    @OnClick(R.id.add_notes)
    void onAddNotesClicked() {
        if (UtilClass.isNetworkAvailable(this) && !SharedPreferenceHelper.getInstance().getBooleanValue(AppConstant.IS_ADS_DISABLED, false)) {
            MoPubAdsManager.getInstance().loadMoPubInterstital(this.getString(R.string.MoPubInterstital),this);
        }
        showAddNotesDialog();
    }

    @OnClick(R.id.add_to_drive)
    void onAddToDriveClicked() {
        googleDriveManager.checkSignInAndUpload(saveRecordingModel.getFilePath(), null);
    }

    @OnClick(R.id.share_audio)
    void onShareAudioClicked() {
//        AnalyticsManager.getInstance().sendAnalytics("Gallery_Share_Card","Gallery_Share_Card");

        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_SEND);
        intent.putExtra(Intent.EXTRA_SUBJECT, "Share Recording");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.setType("audio/*");

//                Uri uriFront = Uri.fromFile(fileList.get(position));
        File file = new File(saveRecordingModel.getFilePath());
        Uri uriFront = FileProvider.getUriForFile(this, this.getApplicationContext().getPackageName() + ".files", file);


        intent.putExtra(Intent.EXTRA_STREAM, uriFront);
        startActivity(Intent.createChooser(intent, "Share Recording to.."));

//        if (Utils.isNetworkAvailable(activity)  &&  !SharedPrefHelper.readBoolean(activity, AppStateManager.IS_ADS_DISABLED,false)) {
//            AdsManager.getInstance().showInterstitialAd(activity.getString(R.string.Business_Card_Int_Main_Menu));
//        }
    }

    @OnClick(R.id.delete_audio)
    void onDeleteAudioClicked() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this, R.style.SeekbarTheme);
        alertDialogBuilder.setTitle("Delete Recording");
        alertDialogBuilder
                .setMessage("Do you want to delete this recording?")
                .setCancelable(false)
                .setPositiveButton("YES", (dialog, id) -> {
                    dialog.cancel();
                    AnalyticsManager.getInstance().sendAnalytics("Delete_Recording", "Delete_Recording");
                    File file = new File(saveRecordingModel.getFilePath());
                    file.delete();
                    finish();
                }).setNegativeButton("NO", (dialog, id) -> dialog.cancel());
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }


    @OnClick(R.id.play_recording)
    void onPlayPauseMusic() {
        if (mediaPlayer.isPlaying()) {
            isPaused = true;
            pausePlayMusic.setImageResource(R.drawable.play);
            mediaPlayer.pause();
//            AnalyticsManager.getInstance(this).sendAnalytics("Pause_Music","Pause_Music");
        } else {
            isPaused = false;
            pausePlayMusic.setImageResource(R.drawable.pause);
            if (isPaused) {
                mediaPlayer.start();
            } else {
                mediaPlayer.reset();
                playMusic();
            }
//                AnalyticsManager.getInstance(this).sendAnalytics("Play_Music","Play_Music");
        }
    }

    private void playMusic() {
        try {
            Uri myUri = Uri.parse(saveRecordingModel.getFilePath());
            mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            mediaPlayer.setDataSource(getApplicationContext(), myUri);
            mediaPlayer.setOnCompletionListener(this);
            mediaPlayer.setOnPreparedListener(this);
            mediaPlayer.prepare();
            Log.d("duration", mediaPlayer.getDuration() + "");
            int durectionSec = mediaPlayer.getDuration() / 1000;
            seekBar.setMax(mediaPlayer.getDuration() / 1000);
            if (durectionSec / 3600 > 0) {
                totalDuration.setText(String.format("%02d", durectionSec / 3600) + ":" + String.format("%02d", durectionSec / 60) + ":" + String.format("%02d", durectionSec % 60));
            } else {
                totalDuration.setText(String.format("%02d", durectionSec / 60) + ":" + String.format("%02d", durectionSec % 60));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showAddNotesDialog() {
        final Dialog notesDialog = new Dialog(this);
        notesDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        notesDialog.setContentView(R.layout.add_notes_dialog);     //,android.R.style.Theme_Translucent_NoTitleBar
        Objects.requireNonNull(Objects.requireNonNull(notesDialog.getWindow())).setBackgroundDrawableResource(android.R.color.transparent);

        final AppCompatEditText notesET = notesDialog.findViewById(R.id.notes_edit_text);
        final AppCompatEditText noteSubjectET = notesDialog.findViewById(R.id.notes_subject);
        notesET.setText(saveRecordingModel.getNotes());
        noteSubjectET.setText(saveRecordingModel.getNoteSubject());
        notesDialog.findViewById(R.id.save_notes).setOnClickListener(v -> {
            saveRecordingModel.setNoteSubject(Objects.requireNonNull(noteSubjectET.getText()).toString());
            saveRecordingModel.setNotes(Objects.requireNonNull(notesET.getText()).toString());
            notesDialog.dismiss();
            MoPubAdsManager.getInstance().showMoPubInterstitial();
        });
        notesDialog.findViewById(R.id.discard_notes).setOnClickListener(v -> {
            notesDialog.dismiss();
            MoPubAdsManager.getInstance().showMoPubInterstitial();
        });

        notesDialog.show();

    }

    @Override
    protected void onStop() {
        MoPub.onStop(this);
        new UpdateRecordingFromDB().execute();
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        MoPubAdsManager.getInstance().destroyAllAdsView();
        unbinder.unbind();
        mediaPlayer.release();
        super.onDestroy();
    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        mediaPlayer.reset();
        pausePlayMusic.setImageResource(R.drawable.play);
        seekBar.setProgress(0);
    }

    @Override
    public void onPrepared(MediaPlayer mp) {
        mediaPlayer.start();

        if (seekBar.getProgress() > 0) {
            mediaPlayer.seekTo(seekBar.getProgress() * 1000);
        }

        Handler mHandler = new Handler();
        //Make sure you update Seekbar on UI thread
        RecordingDetailsActivity.this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mediaPlayer != null && seekBar != null && mediaPlayer.isPlaying()) {
                    int mCurrentPosition = mediaPlayer.getCurrentPosition() / 1000;
                    if (mCurrentPosition / 3600 > 0) {
                        currentDuration.setText(String.format("%02d", mCurrentPosition / 3600) + ":" + String.format("%02d", mCurrentPosition / 60) + ":" + String.format("%02d", mCurrentPosition % 60));
                    } else {
                        currentDuration.setText(String.format("%02d", mCurrentPosition / 60) + ":" + String.format("%02d", mCurrentPosition % 60));
                    }
                    seekBar.setProgress(mCurrentPosition);
                }
                mHandler.postDelayed(this, 1000);
            }
        });

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (mediaPlayer != null && fromUser) {
                    mediaPlayer.seekTo(progress * 1000);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }


    @SuppressLint("StaticFieldLeak")
    private class GetRecordingFromDB extends AsyncTask<Void, Void, Void> {

        long id;

        GetRecordingFromDB(long id) {
            this.id = id;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            LocalDatabase appDataBase = LocalDatabase.getInstance(AppConstant.CONTEXT);
            saveRecordingModel = appDataBase.saveRecordingDAO().findById(id);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            String number = "";
            number = saveRecordingModel.getName().split("in_")[1].split(".mp3")[0];
            setContactNameAndImage(number);
            contactNumber.setText(number);
            @SuppressLint("SimpleDateFormat") SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
            callDate.setText(sdf.format(new Date(saveRecordingModel.getDate())));
            @SuppressLint("SimpleDateFormat") SimpleDateFormat sdfTime = new SimpleDateFormat("hh:mm a");
            callTime.setText(sdfTime.format(saveRecordingModel.getDate()));

            try{
                String mediaPath = saveRecordingModel.getFilePath();
                MediaMetadataRetriever mmr = new MediaMetadataRetriever();
                mmr.setDataSource(mediaPath);
                String duration = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                mmr.release();
                int durationSec = Integer.parseInt(duration)/1000;
                Log.d("duration",durationSec+"");
                if (durationSec / 3600 > 0) {
                    totalDuration.setText(String.format("%02d", durationSec / 3600) + ":" + String.format("%02d", durationSec / 60) + ":" + String.format("%02d", durationSec % 60));
                } else {
                    totalDuration.setText(String.format("%02d", durationSec / 60) + ":" + String.format("%02d", durationSec % 60));
                }
            }catch (Exception   e){
                e.printStackTrace();
            }

            try {
                Uri myUri = Uri.parse(saveRecordingModel.getFilePath());
                mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
                mediaPlayer.setDataSource(getApplicationContext(), myUri);
                seekBar.setMax(mediaPlayer.getDuration());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    @SuppressLint("StaticFieldLeak")
    private class UpdateRecordingFromDB extends AsyncTask<Void, Void, Void> {

        UpdateRecordingFromDB() {
        }

        @Override
        protected Void doInBackground(Void... voids) {
            LocalDatabase appDataBase = LocalDatabase.getInstance(AppConstant.CONTEXT);
            appDataBase.saveRecordingDAO().update(saveRecordingModel);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_CODE_RESOLUTION) {
                googleDriveManager.connectGoogleApiClient();
            } else if (RC_SIGN_IN == requestCode) {
                // The Task returned from this call is always completed, no need to attach
                // a listener.
                Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
                handleSignInResult(task);
            }
        }
    }

    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);

            // Signed in successfully, show authenticated UI.

            Log.w("<<drive>>", "signInResult:Successful");

            googleDriveManager.checkSignInAndUpload(saveRecordingModel.getFilePath(), account);
        } catch (ApiException e) {
            // The ApiException status code indicates the detailed failure reason.
            // Please refer to the GoogleSignInStatusCodes class reference for more information.
            Log.w("<<drive>>", "signInResult:failed code=" + e.getStatusCode());
        }
    }
}
