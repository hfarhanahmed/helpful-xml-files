package com.bwf.automatic.call.recorder.auto.recording.app.activities;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.view.Window;

import java.util.ArrayList;
import java.util.Objects;

import com.bwf.automatic.call.recorder.auto.recording.app.managers.MoPubAdsManager;
import com.google.android.gms.ads.AdView;
import com.bwf.automatic.call.recorder.auto.recording.app.R;
import com.bwf.automatic.call.recorder.auto.recording.app.adapters.HistoryViewPagerAdapter;
import com.bwf.automatic.call.recorder.auto.recording.app.fragment.ShowFragment;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.AppConstant;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.SharedPreferenceHelper;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.UtilClass;
import com.mopub.common.MoPub;

public class MainActivity extends BaseDrawerActivity {
    /**
     * The {@link android.support.v4.view.PagerAdapter} that will provide
     * fragments for each of the sections. We use a
     * {@link FragmentPagerAdapter} derivative, which will keep every
     * loaded fragment in memory. If this becomes too memory intensive, it
     * may be best to switch to a
     * {@link android.support.v4.app.FragmentStatePagerAdapter}.
     */


    public int PERMISSION_CODE = 23;
    private final int DRAW_OVER_OTHER_APP_PERMISSION = 654;

    ViewPager pager;
    TabLayout tabLayout;
    HistoryViewPagerAdapter adapter;
    ArrayList<ShowFragment> arrayList;
    UtilClass utilClass;

//    MyBilling mBilling;

    public static boolean isPredoneDialogShown=false;
    public static boolean   showAd=true;

    /**
     * The {@link ViewPager} that will host the section contents.
     */
    private ViewPager mViewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);

        setContentLayout("Auto Call Recorder",R.layout.activity_main);

        AppConstant.CONTEXT=getApplicationContext();

        isPredoneDialogShown=false;
        showAd=true;

//        Intent serviceIntent = new Intent(MainActivity.this, RegisterCallService.class);
//        startService(serviceIntent);



        if (UtilClass.isNetworkAvailable(this)   &&  !SharedPreferenceHelper.getInstance().getBooleanValue(AppConstant.IS_ADS_DISABLED,false)){
            MoPubAdsManager.getInstance().loadMoPubInterstital(this.getString(R.string.MoPubInterstital),this);
            MoPubAdsManager.getInstance().showMoPubInterstitial();
        }

//        mBilling = new MyBilling(this);
//        mBilling.onCreate();


//        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
//            }
//        });

        if (SharedPreferenceHelper.getInstance().getBooleanValue(AppConstant.RUN_FIRST_TIME, true)) {
            MoPubAdsManager.getInstance().showConsentForm();
            SharedPreferenceHelper.getInstance().setBooleanValue(AppConstant.RUN_FIRST_TIME, false);
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M){
                SharedPreferenceHelper.getInstance().setBooleanValue(AppConstant.IS_OVERLAY_ENABLED, true);
            }
//            Intent intent = new Intent(this, MainActivity.class);
//            startActivity(intent);
        }



//        if (!SharedPreferenceHelper.getInstance().getBooleanValue(AppConstant.IS_CONSENT_AGREED,false)){
//            UtilClass.showConsentDialog(this);
//        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            showOverlayDialog();
        }

        utilClass = new UtilClass();
        /*getSupportActionBar().setDisplayHomeAsUpEnabled(true);*/
        pager = (ViewPager) findViewById(R.id.history_view_pager);
        tabLayout = (TabLayout) findViewById(R.id.history_tabLayout);
        tabLayout.addTab(tabLayout.newTab().setText("All"));
        tabLayout.addTab(tabLayout.newTab().setText("Incoming"));
        tabLayout.addTab(tabLayout.newTab().setText("Outgoing"));
        arrayList = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            ShowFragment showFragment = new ShowFragment();
            Bundle args = new Bundle();
            args.putInt("index", i);
            showFragment.setArguments(args);
            arrayList.add(showFragment);
        }
        adapter = new HistoryViewPagerAdapter(getSupportFragmentManager(), arrayList, this);
        pager.setAdapter(adapter);
        tabLayout.setupWithViewPager(pager);

    }


    private void showOverlayDialog() {
        final Dialog overlayDialog = new Dialog(this);     //,android.R.style.Theme_Translucent_NoTitleBar
        overlayDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        overlayDialog.setContentView(R.layout.overlay_dialog);
        Objects.requireNonNull(Objects.requireNonNull(overlayDialog.getWindow())).setBackgroundDrawableResource(android.R.color.transparent);

        overlayDialog.findViewById(R.id.deny_overlay).setOnClickListener(v -> {
            overlayDialog.dismiss();
        });

        overlayDialog.findViewById(R.id.allow_overlay).setOnClickListener(v -> {
            overlayDialog.dismiss();
            askForSystemOverlayPermission();
        });

        overlayDialog.show();
    }


    private void askForSystemOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            //If the draw over permission is not available open the settings screen
            //to grant the permission.
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" +this.getPackageName()));
            startActivityForResult(intent, DRAW_OVER_OTHER_APP_PERMISSION);
        }else{
            SharedPreferenceHelper.getInstance().setBooleanValue(AppConstant.IS_OVERLAY_ENABLED,true);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode==DRAW_OVER_OTHER_APP_PERMISSION){
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(MainActivity.this)){
                SharedPreferenceHelper.getInstance().setBooleanValue(AppConstant.IS_OVERLAY_ENABLED,true);
            }
        }
    }

    @Override
    protected void onResume() {
        MoPubAdsManager.getInstance().showMoPubBanner(this.getString(R.string.MoPubBanner),findViewById(R.id.main_baner_ad_view));
        MoPub.onResume(this);
        if (showAd){
            showAd=false;
        }
        super.onResume();
    }

    @Override
    public void onDestroy() {
        MoPubAdsManager.getInstance().destroyAllAdsView();
        super.onDestroy();
    }


    @Override
    protected void onPause() {
        MoPubAdsManager.getInstance().destroyBannerView();
        MoPub.onPause(this);
        super.onPause();
    }

    @Override
    protected void onStop() {
        MoPub.onStop(this);
        super.onStop();
    }

//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        // Inflate the menu; this adds items to the action bar if it is present.
//        getMenuInflater().inflate(R.menu.menu_main, menu);
//        return true;
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        // Handle action bar item clicks here. The action bar will
//        // automatically handle clicks on the Home/Up button, so long
//        // as you specify a parent activity in AndroidManifest.xml.
//        int id = item.getItemId();
//
//        //noinspection SimplifiableIfStatement
//        if (id == R.id.action_settings) {
//            startActivity(new Intent(this,SettingsActivity.class));
//            return true;
//        }else   if (id==R.id.action_rate_us){
//            UtilClass.onRateUs(this);
//        }else   if (id==R.id.action_no_ads){
////            AnalyticsManager.getInstance().sendAnalytics("No_Ads","No_Ads");
//            mBilling.purchaseRemoveAds();
//        }
//
//        return super.onOptionsItemSelected(item);
//    }


    @Override
    public void onBackPressed() {
        // super.onBackPressed();
        closeActivity();

    }

    private void closeActivity() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.SeekbarTheme);
        builder.setTitle(R.string.app_name);
        // builder.setIcon(R.drawable.app_logo);
        builder.setMessage("Sure to exit ?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        builder.setNeutralButton("Rate Us", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                utilClass.likeUs(MainActivity.this);
            }
        });
        builder.show();

    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults.length > 0) {
            SharedPreferenceHelper.getInstance().setBooleanValue(AppConstant.IS_RECORDING_ENABLE,true);
            for (int    result:grantResults){
                if (result != PackageManager.PERMISSION_GRANTED){
                    SharedPreferenceHelper.getInstance().setBooleanValue(AppConstant.IS_RECORDING_ENABLE,false);
                }
            }
        }
    }

}
