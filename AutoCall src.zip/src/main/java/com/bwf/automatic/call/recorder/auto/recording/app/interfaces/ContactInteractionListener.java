package com.bwf.automatic.call.recorder.auto.recording.app.interfaces;

import android.content.Intent;


public interface ContactInteractionListener {
    void onContactSelected(Intent contactDetailActivity);
}
