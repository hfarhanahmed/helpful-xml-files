package com.bwf.automatic.call.recorder.auto.recording.app.models;

/**
 * Created by RanaTalal on 9/28/2017.
 */

public class HistoryModel {
    private String name;
    private String time;
    private String duration;
    private String filePath;
    private String callType;

    public HistoryModel(String name, String time, String duration, String filePath, String callType) {

        this.name = name;
        this.time = time;
        this.duration = duration;
        this.filePath = filePath;
        this.callType = callType;
    }

    public String getCallType() {
        return callType;
    }

    public void setCallType(String callType) {
        this.callType = callType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }
}
