package com.bwf.automatic.call.recorder.auto.recording.app.fragment;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputEditText;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AppCompatSpinner;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import com.bwf.automatic.call.recorder.auto.recording.app.managers.MoPubAdsManager;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.bwf.automatic.call.recorder.auto.recording.app.R;
import com.bwf.automatic.call.recorder.auto.recording.app.activities.MainActivity;
import com.bwf.automatic.call.recorder.auto.recording.app.adapters.SavedRecordingAdapter;
import com.bwf.automatic.call.recorder.auto.recording.app.database.LocalDatabase;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.AppConstant;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.SharedPreferenceHelper;
import com.bwf.automatic.call.recorder.auto.recording.app.helper.UtilClass;
import com.bwf.automatic.call.recorder.auto.recording.app.managers.AnalyticsManager;
import com.bwf.automatic.call.recorder.auto.recording.app.models.SaveRecordingModel;
import com.mopub.nativeads.FacebookAdRenderer;
import com.mopub.nativeads.GooglePlayServicesAdRenderer;
import com.mopub.nativeads.MediaViewBinder;
import com.mopub.nativeads.MoPubNativeAdPositioning;
import com.mopub.nativeads.MoPubRecyclerAdapter;
import com.mopub.nativeads.MoPubStaticNativeAdRenderer;
import com.mopub.nativeads.ViewBinder;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

import static com.bwf.automatic.call.recorder.auto.recording.app.helper.UtilClass.PERMISSION;

public class ShowFragment extends Fragment {

    public int PERMISSION_CODE = 23;
    RecyclerView.LayoutManager layoutManager;
    SavedRecordingAdapter adapter;
    MoPubRecyclerAdapter myMoPubAdapter;
    List<SaveRecordingModel> saveRecordingModels;
    String recordType;
    TextView msg;
    int index;
    Unbinder    unbinder;
    boolean isSearching=false;
    List<UnifiedNativeAd> adList;
    boolean isActive=true;


    @BindView(R.id.history_record_list)
    RecyclerView recyclerView;

    @BindView(R.id.sort_spinner)
    AppCompatSpinner sortSpinner;

    @BindView(R.id.search_edittext)
    TextInputEditText searchEditText;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_show_fragment, container, false);
        unbinder    = ButterKnife.bind(this,view);
        View parentView = view.findViewById(R.id.parent_layout);
        parentView.setOnClickListener(null);
        msg = view.findViewById(R.id.record_msg);
        layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        recordType = Objects.requireNonNull(getArguments()).getString("title");
        index = getArguments().getInt("index",0);
        adList  =   new ArrayList<>();
        saveRecordingModels=new ArrayList<>();
        isActive=true;
        adapter = new SavedRecordingAdapter(saveRecordingModels,adList, getActivity());

//        MoPubNativeAdPositioning.MoPubClientPositioning adPositioning = MoPubNativeAdPositioning.clientPositioning();
//        adPositioning.enableRepeatingPositions(4);

        // Pass the recycler Adapter your original adapter.
        myMoPubAdapter = new MoPubRecyclerAdapter(Objects.requireNonNull(getActivity()), adapter, new MoPubNativeAdPositioning.MoPubServerPositioning());
        // Create an ad renderer and view binder that describe your native ad layout.
        ViewBinder myViewBinder = new ViewBinder.Builder(R.layout.ad_app_install_main)
                .titleId(R.id.native_title)
                .textId(R.id.native_text)
//                .mainImageId(R.id.native_main_image)
                .iconImageId(R.id.native_icon_image)
                .callToActionId(R.id.native_cta)
                .privacyInformationIconImageId(R.id.native_privacy_information_icon_image)
                .build();


        MoPubStaticNativeAdRenderer myRenderer = new MoPubStaticNativeAdRenderer(myViewBinder);

        final GooglePlayServicesAdRenderer googlePlayServicesAdRenderer = new GooglePlayServicesAdRenderer(
                new MediaViewBinder.Builder(R.layout.ad_app_install_admob_main)
                        .titleId(R.id.native_title)
                        .textId(R.id.native_text)
//                        .mediaLayoutId(R.id.native_main_image)
                        .iconImageId(R.id.native_icon_image)
                        .callToActionId(R.id.native_cta)
                        // .addExtra("key_star_rating",R.id.appinstall_stars)
                        .privacyInformationIconImageId(R.id.native_privacy_information_icon_image)
                        .build());

        FacebookAdRenderer facebookAdRenderer = new FacebookAdRenderer(
                new FacebookAdRenderer.FacebookViewBinder.Builder(R.layout.ad_app_install_facebook_main)
                        .titleId(R.id.native_title)
                        .textId(R.id.native_text)
                        // Binding to new layouts from Facebook 4.99.0+
//                        .mediaViewId(R.id.native_main_image)
                        .adIconViewId(R.id.native_icon_image)
                        .adChoicesRelativeLayoutId(R.id.native_privacy_information_icon_image)
                        .advertiserNameId(R.id.native_title) // Bind either the titleId or advertiserNameId depending on the FB SDK version
                        // End of binding to new layouts
                        .callToActionId(R.id.native_cta)
                        .build());

        myMoPubAdapter.registerAdRenderer(myRenderer);
        myMoPubAdapter.registerAdRenderer(googlePlayServicesAdRenderer);
        myMoPubAdapter.registerAdRenderer(facebookAdRenderer);

        // Set up the RecyclerView and start loading ads
        recyclerView.setAdapter(myMoPubAdapter);
        myMoPubAdapter.loadAds(getString(R.string.MoPubNative));

        AnalyticsManager.getInstance().sendAnalytics("Main_List_Screen","Main_List_Screen");


        sortSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                // your code here
                try{
                    if (isActive){
                        if (position==0){
                            Collections.sort(saveRecordingModels, (Comparator<SaveRecordingModel>) (softDrinkOne, softDrinkTwo) -> {
                                //comparision for primitive int uses compareTo of the wrapper Integer
                                return Long.compare(softDrinkTwo.getDate(),softDrinkOne.getDate());
                            });
                        }else  if (position==1){
                            Collections.sort(saveRecordingModels, (Comparator<SaveRecordingModel>) (softDrinkOne, softDrinkTwo) -> {
                                //use instanceof to verify the references are indeed of the type in question
                                return softDrinkOne.getContactName().compareTo(softDrinkTwo.getContactName());
                            });
                        }
                        adapter.notifyDataSetChanged();
                    }
                }catch (Exception   e){
                    e.printStackTrace();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });


        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Log.d("count",count+"");
                if (s.toString().isEmpty()){
                    if (!isSearching){
                        new GetRecordingFromDB().execute();
                    }
                }else   if (count%2==0){
                    if (!isSearching){
                        isSearching=true;
                        new SearchRecordingFromDB(s.toString()).execute();
                        Log.d("Searched","Databse");
                    }else {
                        Log.d("search","skipped");
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!MainActivity.isPredoneDialogShown   &&  !UtilClass.isAllowPermission(getContext())) {
            MainActivity.isPredoneDialogShown=true;
            showPrePermissionDialog();
        }else{
            adList.clear();
            saveRecordingModels.clear();
            if (adapter!=null)adapter.notifyDataSetChanged();
            new GetRecordingFromDB().execute();
        }


    }

    private void showPrePermissionDialog() {
        final Dialog prePermissionDialog = new Dialog(Objects.requireNonNull(getContext()));     //,android.R.style.Theme_Translucent_NoTitleBar
        prePermissionDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        prePermissionDialog.setContentView(R.layout.pre_permission_dialog);
        Objects.requireNonNull(Objects.requireNonNull(prePermissionDialog.getWindow())).setBackgroundDrawableResource(android.R.color.transparent);

        prePermissionDialog.findViewById(R.id.deny_permissions).setOnClickListener(v -> {
            SharedPreferenceHelper.getInstance().setBooleanValue(AppConstant.IS_RECORDING_ENABLE,false);
            prePermissionDialog.dismiss();
        });

        prePermissionDialog.findViewById(R.id.allow_permissions).setOnClickListener(v -> {
            prePermissionDialog.dismiss();
            requestPermission();
        });

        prePermissionDialog.show();

    }

    private String getDuration(String fileName) {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
//use one of overloaded setDataSource() functions to set your data source
        try{
            Log.d("filePath",AppConstant.FILE_PATH + File.separator + fileName);
            retriever.setDataSource(getContext(), Uri.parse(AppConstant.FILE_PATH + File.separator + fileName));
            String time = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            long timeInMillisec = Long.parseLong(time);
            String durationTime = convertMiliToTime(timeInMillisec);
            Log.d("duration", "onBindViewHolder: " + durationTime);
            return durationTime;
        }catch (Exception   e){
            e.printStackTrace();
            return "0:0";
        }
    }

    private String convertMiliToTime(long millis) {
        String time = String.format("%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(millis),
                TimeUnit.MILLISECONDS.toMinutes(millis) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(millis)),
                TimeUnit.MILLISECONDS.toSeconds(millis) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millis)));
        return time;
    }

    private ArrayList<String> getFile() {
        ArrayList<String> result = new ArrayList<>();
        File folder = new File(AppConstant.FILE_PATH);
        if (folder.exists()) {
            File[] filesInFolder = folder.listFiles();
            for (File file : filesInFolder) {
                if (!file.isDirectory()) {
                    if ((file.getName()).startsWith(recordType)) {
                        result.add(new String(file.getName()));
                    } else if (recordType.equals("All")) {
                        result.add(new String(file.getName()));
                    }
                }
            }
        }

        return result;
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(getActivity(), PERMISSION, PERMISSION_CODE);
        Log.d("Permissions","requested");
    }

    @SuppressLint("StaticFieldLeak")
    private class GetRecordingFromDB extends AsyncTask<Void, Void, Void> {

        GetRecordingFromDB() {
        }

        @Override
        protected Void doInBackground(Void... voids) {
            LocalDatabase appDataBase = LocalDatabase.getInstance(AppConstant.CONTEXT);
            List<SaveRecordingModel>    list    ;
            switch (index){
                case    1:
                    list    =   appDataBase.saveRecordingDAO().getAllFilteredRecordings(true);
                    break;
                case    2:
                    list    =   appDataBase.saveRecordingDAO().getAllFilteredRecordings(false);
                    break;
                    default:
                        list    =   appDataBase.saveRecordingDAO().getAllRecordings();
                        break;
            }
            saveRecordingModels.clear();
            for (SaveRecordingModel model:list){
                File    file    =   new File(model.getFilePath());
                if (file.exists()   &&  !file.isDirectory()) {
                    model.setDuration(getDuration(model.getName()+".amr"));
                    saveRecordingModels.add(model);
//                    if ((file.getName()).startsWith(recordType)) {
//                        model.setDuration(getDuration(model.getName()+".amr"));
//                        saveRecordingModels.add(model);
//                    } else if (recordType.equals("All")) {
//                        model.setDuration(getDuration(model.getName()+".amr"));
//                        saveRecordingModels.add(model);
//                    }
                }
            }

            appDataBase.close();
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            if (getContext()!=null){
                if (sortSpinner.getSelectedItemPosition()==0){
                    Collections.sort(saveRecordingModels, (Comparator<SaveRecordingModel>) (softDrinkOne, softDrinkTwo) -> {
                        //comparision for primitive int uses compareTo of the wrapper Integer
                        return Long.compare(softDrinkTwo.getDate(), softDrinkOne.getDate());
                    });
                }else{
                    Collections.sort(saveRecordingModels, (Comparator<SaveRecordingModel>) (softDrinkOne, softDrinkTwo) -> {
                        //use instanceof to verify the references are indeed of the type in question
                        return softDrinkOne.getContactName().compareTo(softDrinkTwo.getContactName());
                    });
                }

                if (isActive){
                    if (saveRecordingModels.size() == 0) {
                        msg.setVisibility(View.VISIBLE);
                    } else {
                        msg.setVisibility(View.GONE);
//                        recyclerView.getRecycledViewPool().clear();
                        adapter.notifyDataSetChanged();
                    }
                    Log.d("DbSize",saveRecordingModels.size()+"");
                }
            }
        }
    }

    @SuppressLint("StaticFieldLeak")
    private class SearchRecordingFromDB extends AsyncTask<Void, Void, Void> {
        String  prefix;
        SearchRecordingFromDB(String    prefix) {
            this.prefix=prefix;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            LocalDatabase appDataBase = LocalDatabase.getInstance(AppConstant.CONTEXT);
            List<SaveRecordingModel>    list    ;
            switch (index){
                case    1:
                    list    =   appDataBase.saveRecordingDAO().getSearchFilteredRecordings(true,prefix);
                    break;
                case    2:
                    list    =   appDataBase.saveRecordingDAO().getSearchFilteredRecordings(false,prefix);
                    break;
                    default:
                        list    =   appDataBase.saveRecordingDAO().getSearchedRecordings(prefix);
                        break;
            }
            saveRecordingModels.clear();
            for (SaveRecordingModel model:list){
                File    file    =   new File(model.getFilePath());
                if (file.exists()   &&  !file.isDirectory()) {
                    model.setDuration(getDuration(model.getName()+".amr"));
                    saveRecordingModels.add(model);
                }else{
                    appDataBase.saveRecordingDAO().delete(model);
                }
            }
            appDataBase.close();
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            if (isActive){
                if (saveRecordingModels.size() == 0) {
                    msg.setVisibility(View.VISIBLE);
                } else {
                    msg.setVisibility(View.GONE);
//                    recyclerView.getRecycledViewPool().clear();
                    adapter.notifyDataSetChanged();
                }

                isSearching=false;
                Log.d("DbSize",saveRecordingModels.size()+"");
            }
        }
    }

    @Override
    public void onDestroyView() {
        isActive=false;
        super.onDestroyView();
    }

    @Override
    public void onDestroy() {
        myMoPubAdapter.destroy();
        super.onDestroy();
    }
}
