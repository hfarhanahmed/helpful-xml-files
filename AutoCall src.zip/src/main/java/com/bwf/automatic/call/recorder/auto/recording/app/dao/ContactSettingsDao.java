package com.bwf.automatic.call.recorder.auto.recording.app.dao;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import java.util.List;

import com.bwf.automatic.call.recorder.auto.recording.app.models.ContactSettings;

@Dao
public interface ContactSettingsDao {

    @Query("SELECT * FROM contactsettings")
    List<ContactSettings> getAllContactSettings();

    @Query("SELECT COUNT(*) FROM contactsettings")
    int getCount();

    @Query("SELECT * FROM contactsettings WHERE id LIKE :id LIMIT 1")
    ContactSettings findById(int id);

    @Query("SELECT * FROM contactsettings WHERE id LIKE :id LIMIT 1")
    ContactSettings findByIdbg(int id);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(ContactSettings contactSetting);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<ContactSettings> contactSettings);

    @Update(onConflict = OnConflictStrategy.REPLACE)
    void update(ContactSettings contactSetting);

    @Delete
    void delete(ContactSettings contactSetting);

    @Query("DELETE FROM contactsettings")
    public void deleteAll();

}
